# Stick Clash Arena V9 — Online Alpha

V9 adds the first real network duel mode while keeping all V8 offline modes and Creator features.

## Online Alpha
- 1v1 between two Android phones over the same Wi-Fi/LAN.
- One player taps **Create battle** and shares the IP shown on screen.
- The second player taps **Connect** and enters that IP.
- TCP peer-to-peer transport on port `27654`.
- Each player uses the ability currently selected on their own phone.
- The host chooses the arena.
- Host-authoritative state snapshots reduce desync while both clients predict movement locally.
- Online Alpha intentionally gives no coins yet so local-network matches cannot be used to farm currency.
- Creator combat advantages are not applied to online matches.

## Important limitation
This alpha does not yet include a public Internet relay/matchmaking server. It works on the same local network (or any network where the host device is directly reachable). A later version can add room codes, matchmaking, friends and Internet relay hosting.

## Existing V8 systems kept
- 15 permanent unlockable abilities.
- Solo Easy/Medium/Hard and local 2-player modes.
- Coins, shop, permanent purchases, graphics settings and joystick customization.
- Physics polish, hit stop, camera shake, particles, multiple arenas.
- Creator/Admin panel for the whitelisted owner installation.

Version: 0.9.0 (`versionCode 10`).
