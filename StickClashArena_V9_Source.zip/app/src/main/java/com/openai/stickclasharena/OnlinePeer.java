package com.openai.stickclasharena;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Tiny peer-to-peer transport for the V9 online alpha.
 * One phone hosts a TCP socket and the other joins it over the same Wi-Fi/LAN.
 * Gameplay packets are newline-delimited JSON strings produced by GameView.
 */
final class OnlinePeer {
    interface Listener {
        void onStatus(String status);
        void onConnected(boolean host);
        void onMessage(String message);
        void onDisconnected(String reason);
    }

    static final int DEFAULT_PORT = 27654;

    private final Listener listener;
    private volatile boolean closed = true;
    private volatile boolean connected = false;
    private ServerSocket serverSocket;
    private Socket socket;
    private BufferedWriter writer;
    private Thread worker;
    private Thread sender;
    private final LinkedBlockingQueue<String> outgoing = new LinkedBlockingQueue<>(256);

    OnlinePeer(Listener listener) {
        this.listener = listener;
    }

    boolean isConnected() { return connected; }

    synchronized void startHost(final int port) {
        close();
        closed = false;
        listener.onStatus("ЖДУ ИГРОКА");
        worker = new Thread(() -> {
            try {
                serverSocket = new ServerSocket();
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress(port));
                Socket accepted = serverSocket.accept();
                if (closed) { accepted.close(); return; }
                attach(accepted, true);
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-online-host");
        worker.start();
    }

    synchronized void join(final String host, final int port) {
        close();
        closed = false;
        listener.onStatus("ПОДКЛЮЧЕНИЕ К " + host);
        worker = new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(host, port), 8000);
                if (closed) { s.close(); return; }
                attach(s, false);
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-online-join");
        worker.start();
    }

    private void attach(Socket s, boolean host) throws Exception {
        socket = s;
        socket.setTcpNoDelay(true);
        socket.setKeepAlive(true);
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
        connected = true;
        outgoing.clear();
        sender = new Thread(() -> {
            try {
                while (!closed && connected) {
                    String message = outgoing.poll(1, TimeUnit.SECONDS);
                    if (message == null) continue;
                    synchronized (OnlinePeer.this) {
                        if (writer == null) continue;
                        writer.write(message); writer.write('\n'); writer.flush();
                    }
                }
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-online-send");
        sender.start();
        listener.onConnected(host);
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
        String line;
        while (!closed && (line = reader.readLine()) != null) {
            if (!line.isEmpty()) listener.onMessage(line);
        }
        if (!closed) listener.onDisconnected("СОЕДИНЕНИЕ ЗАКРЫТО");
        closeQuietly();
    }

    void send(String message) {
        if (!connected || message == null) return;
        if (!outgoing.offer(message)) {
            outgoing.poll();
            outgoing.offer(message);
        }
    }

    synchronized void close() {
        closed = true;
        connected = false;
        closeQuietly();
    }

    private synchronized void closeQuietly() {
        connected = false;
        try { if (writer != null) writer.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        writer = null;
        socket = null;
        serverSocket = null;
        outgoing.clear();
    }

    static String localIpv4Address() {
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                for (InetAddress address : Collections.list(nif.getInetAddresses())) {
                    if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                        String ip = address.getHostAddress();
                        if (ip != null && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) return ip;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "IP НЕ НАЙДЕН";
    }

    private static String shortReason(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return "ОШИБКА СЕТИ";
        m = m.replace('\n', ' ').replace('\r', ' ');
        return m.length() > 48 ? m.substring(0, 48) : m;
    }
}
