# Stick Clash Arena V8

Global polish update for the original Android stick-duel game.

## V8 highlights
- Creator code `61A7-FD73-A887` remains whitelisted and Creator activation persists.
- New Creator Admin screen opened from Settings -> Admin Panel.
- Admin tools: +1000 coins, permanently unlock all abilities, God Mode, turbo cooldown, x2 damage, freeze bot, reset admin combat toggles.
- Admin combat modifiers are disabled in local 2-player mode.
- Career stats: solo wins, losses and earned coins are persisted.
- Fixed-step ~60 Hz simulation with frame-time accumulator and catch-up cap for steadier physics on 60/90/120 Hz displays.
- Improved fighter collision response, landing squash, smoother drag, recoil, hit-stop and camera shake.
- Improved bot edge awareness on the split arena.
- Three graphics modes: Performance / Balanced / Ultra.
- Graphics quality changes star density, particle limits, projectile trails, fighter glow and city-window details.
- Reduced hot-path allocations by reusing drawing rectangles.
- Refined battle HUD with Creator marker and live ability cooldown state.
- Existing permanent weapon ownership, coins, colors, joystick settings, difficulties, arenas and one-round fights are preserved.

Package: `com.openai.stickclasharena`
Version: 0.8.0 (versionCode 9)
