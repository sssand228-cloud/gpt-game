# Stick Clash Arena V6

Version 0.6.0

## V6 Physics Duel update
- One fight is now exactly one round. The winner is decided immediately after the first KO/fall.
- Solo rewards stay Easy +5, Medium +7, Hard +15.
- Unlocks are permanent: stable ownership keys migrate old V4/V5 purchases and survive future enum/order changes.
- New local 2-player mode on one phone with two simultaneous joysticks.
- Four original arenas: Neon Roof, Split, Moon Station, Spring Floor.
- Arena physics differ: center gap/fall KO, low gravity, bounce floor.
- Stronger momentum/knockback feel and more dynamic stick-figure pose based on velocity.
- Existing 15 fantasy abilities, shop, coins, colors, and joystick settings are preserved.
- Original visuals and arena designs; no copied assets from other games.
