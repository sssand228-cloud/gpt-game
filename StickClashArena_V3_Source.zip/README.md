# Stick Clash Arena 0.3.0

Optimized Android 2D stick-fighter prototype. No ads, analytics, or Internet permission.

## Changes in 0.3.0
- Main joystick moved to the **right side**
- Weapon/ability switch button moved to the left
- Auto-fire and aim remain on the joystick
- Hold joystick upward for about 0.5 seconds to jump
- Static arena is pre-rendered to a bitmap instead of redrawn every frame
- Removed per-frame projectile/fighter/joystick gradient allocations
- Update loop capped near 60 FPS instead of running around 120 FPS
- Projectile and particle counts are capped to avoid slowdowns in busy fights
- Uses Android hardware-accelerated Canvas by default

Package: `com.openai.stickclasharena`
Minimum Android: 7.0 (API 24)
