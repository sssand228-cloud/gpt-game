package com.openai.stickclasharena;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends View implements Runnable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random(42);
    private final List<Shot> shots = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private static final int MAX_SHOTS = 48;
    private static final int MAX_PARTICLES = 120;

    private Bitmap arenaBitmap;
    private final RectF jumpArcRect = new RectF();

    private boolean running;
    private long lastNs;
    private static final long UPDATE_STEP_NS = 16_000_000L; // about 60 Hz

    private float W, H, groundY;
    private Fighter player, bot;
    private int playerScore = 0, botScore = 0;
    private boolean roundOver = false, matchOver = false;
    private float roundResetTimer = 0f;

    // One right joystick controls movement, aim and jump charge.
    private int joystickPointerId = -1;
    private float joyCx, joyCy, joyRadius, knobRadius;
    private float joyX = 0f, joyY = 0f;
    private float aimX = 1f, aimY = 0f;
    private float jumpCharge = 0f;
    private boolean jumpLatched = false;
    private final RectF weaponBtn = new RectF();

    private final float[] starX = new float[42];
    private final float[] starY = new float[42];
    private final float[] starR = new float[42];

    enum Ability {
        ENERGY_ORB("ENERGY ORB"),
        BOUNCE_DISC("BOUNCE DISC"),
        HEAVY_GLOVE("HEAVY GLOVE"),
        GRAVITY_BURST("GRAVITY BURST"),
        ARC_CORE("ARC CORE"),
        TRIPLE_SPARK("TRIPLE SPARK"),
        SHIELD_PULSE("SHIELD PULSE"),
        DASH_CORE("DASH CORE");
        final String title;
        Ability(String title) { this.title = title; }
    }

    static class Fighter {
        float x, y, vx, vy;
        float radius;
        float hp = 100f;
        float shield = 0f;
        float attackCd = 0f;
        float invuln = 0f;
        boolean grounded = false;
        int facing = 1;
        Ability ability = Ability.ENERGY_ORB;
        final boolean isBot;
        Fighter(boolean isBot) { this.isBot = isBot; }
    }

    static class Shot {
        float x, y, vx, vy, radius, damage, knockback, life;
        float trailX, trailY;
        int owner;
        int bounces;
        boolean gravity;
        Shot(float x, float y, float vx, float vy, float r, float d, float k, float life, int owner) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.radius=r; this.damage=d; this.knockback=k; this.life=life; this.owner=owner;
            this.trailX=x; this.trailY=y;
        }
    }

    static class Particle {
        float x, y, vx, vy, life, maxLife, size;
        int color;
        Particle(float x, float y, float vx, float vy, float life, float size, int color) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.life=life; this.maxLife=life; this.size=size; this.color=color;
        }
    }

    public GameView(Context context) {
        super(context);
        setKeepScreenOn(true);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setDither(true);
        paint.setStrokeJoin(Paint.Join.ROUND);
        setBackgroundColor(Color.rgb(8, 12, 24));
        for (int i=0;i<starX.length;i++) {
            starX[i] = rng.nextFloat();
            starY[i] = rng.nextFloat()*0.58f;
            starR[i] = 0.6f + rng.nextFloat()*1.8f;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        W = w; H = h; groundY = H * 0.78f;
        float min = Math.min(W,H);
        joyRadius = min * 0.115f;
        knobRadius = joyRadius * 0.42f;
        joyCx = W * 0.84f;
        joyCy = H * 0.80f;
        float bw = Math.max(150f, W*0.15f), bh = Math.max(54f, H*0.075f);
        weaponBtn.set(W*0.025f, H-bh-H*0.035f, W*0.025f+bw, H-H*0.035f);
        jumpArcRect.set(joyCx-joyRadius*1.12f, joyCy-joyRadius*1.12f, joyCx+joyRadius*1.12f, joyCy+joyRadius*1.12f);
        rebuildArenaBitmap(w, h);
        startRound();
    }

    private void startRound() {
        if (W <= 0 || H <= 0) return;
        float r = Math.max(26f, Math.min(W,H)*0.048f);
        player = new Fighter(false); bot = new Fighter(true);
        player.radius = bot.radius = r;
        player.x = W*0.24f; player.y = groundY-r*1.1f;
        bot.x = W*0.76f; bot.y = groundY-r*1.1f;
        player.facing = 1; bot.facing = -1;
        player.ability = Ability.ENERGY_ORB;
        bot.ability = Ability.TRIPLE_SPARK;
        shots.clear(); particles.clear();
        roundOver = false; roundResetTimer = 0f;
        jumpCharge=0f; jumpLatched=false;
    }

    public void resume() {
        if (running) return;
        running = true;
        lastNs = System.nanoTime();
        postOnAnimation(this);
    }

    public void pause() {
        running = false;
        removeCallbacks(this);
    }

    @Override public void run() {
        if (!running) return;
        long now = System.nanoTime();
        long elapsed = now - lastNs;
        if (elapsed >= UPDATE_STEP_NS) {
            float dt = Math.min(0.033f, elapsed / 1_000_000_000f);
            lastNs = now;
            update(dt);
            invalidate();
        }
        postOnAnimation(this);
    }

    private void update(float dt) {
        if (player == null || bot == null) return;
        updateParticles(dt);
        if (matchOver) return;
        if (roundOver) {
            roundResetTimer -= dt;
            if (roundResetTimer <= 0f) startRound();
            return;
        }

        updateCooldowns(player, dt); updateCooldowns(bot, dt);

        // Horizontal motion comes from the joystick X axis.
        float dead = 0.12f;
        float move = Math.abs(joyX) > dead ? joyX : 0f;
        float accel = W * 1.35f;
        if (move != 0f) {
            player.vx += move * accel * dt;
            if (Math.abs(joyX) > 0.18f) player.facing = joyX >= 0 ? 1 : -1;
        } else {
            player.vx *= Math.max(0f, 1f - 6.2f*dt);
        }

        // Aim follows the same stick. Auto fire happens while the stick is meaningfully displaced.
        float mag = (float)Math.sqrt(joyX*joyX + joyY*joyY);
        if (mag > 0.22f) {
            aimX = joyX / mag;
            aimY = joyY / mag;
            if (Math.abs(aimX) > 0.16f) player.facing = aimX >= 0 ? 1 : -1;
            if (player.attackCd <= 0f) attack(player, 0, aimX, aimY);
        }

        // Pull up and hold for 0.5 sec to jump. Requires release before charging again.
        boolean chargingJump = joyY < -0.68f && mag > 0.72f;
        if (chargingJump && player.grounded && !jumpLatched) {
            jumpCharge += dt;
            if (jumpCharge >= 0.50f) {
                player.vy = -H*0.88f;
                player.grounded = false;
                jumpCharge = 0f;
                jumpLatched = true;
                burst(player.x, player.y+player.radius, Color.rgb(100,210,255), 10, 0.55f);
            }
        } else if (!chargingJump) {
            jumpCharge = 0f;
            jumpLatched = false;
        }

        updateBot(dt);
        physics(player, dt); physics(bot, dt);
        resolveFighterCollision();
        updateShots(dt);

        if (player.hp <= 0 || bot.hp <= 0) endRound();
    }

    private void updateCooldowns(Fighter f, float dt) {
        f.attackCd = Math.max(0, f.attackCd-dt);
        f.shield = Math.max(0, f.shield-dt);
        f.invuln = Math.max(0, f.invuln-dt);
    }

    private void physics(Fighter f, float dt) {
        f.vy += H*2.15f*dt;
        f.vx = clamp(f.vx, -W*0.52f, W*0.52f);
        f.x += f.vx*dt; f.y += f.vy*dt;
        float r=f.radius;
        if (f.y+r*1.10f >= groundY) { f.y=groundY-r*1.10f; if (f.vy>0) f.vy=0; f.grounded=true; }
        else f.grounded=false;
        if (f.x-r < 0) { f.x=r; f.vx=Math.abs(f.vx)*0.25f; }
        if (f.x+r > W) { f.x=W-r; f.vx=-Math.abs(f.vx)*0.25f; }
    }

    private void resolveFighterCollision() {
        float dx=bot.x-player.x, dy=bot.y-player.y;
        float dist=(float)Math.sqrt(dx*dx+dy*dy);
        float min=player.radius+bot.radius;
        if (dist>0 && dist<min) {
            float nx=dx/dist, overlap=min-dist;
            player.x-=nx*overlap*0.5f; bot.x+=nx*overlap*0.5f;
            float impulse=(bot.vx-player.vx)*0.08f;
            player.vx+=impulse; bot.vx-=impulse;
        }
    }

    private void updateBot(float dt) {
        float dx=player.x-bot.x, dy=player.y-bot.y, adx=Math.abs(dx);
        bot.facing = dx>=0 ? 1 : -1;

        boolean danger=false;
        for (Shot s: shots) {
            if (s.owner==1) continue;
            float sx=s.x-bot.x, sy=s.y-bot.y;
            if (Math.abs(sy)<bot.radius*2.8f && Math.abs(sx)<W*0.22f && Math.signum(s.vx)==-Math.signum(sx)) { danger=true; break; }
        }
        if (danger && bot.grounded && rng.nextFloat()<0.16f) bot.vy=-H*0.82f;

        float desiredMin=W*0.18f, desiredMax=W*0.34f;
        if (adx>desiredMax) bot.vx += Math.signum(dx)*W*0.98f*dt;
        else if (adx<desiredMin) bot.vx -= Math.signum(dx)*W*0.82f*dt;
        else bot.vx *= Math.max(0f, 1f - 5.0f*dt);

        if (bot.attackCd<=0) {
            if (adx < bot.radius*3.0f) bot.ability = rng.nextBoolean()?Ability.HEAVY_GLOVE:Ability.GRAVITY_BURST;
            else if (danger) bot.ability = Ability.SHIELD_PULSE;
            else if (adx > W*0.33f) bot.ability = rng.nextBoolean()?Ability.TRIPLE_SPARK:Ability.ARC_CORE;
            else bot.ability = rng.nextInt(4)==0?Ability.DASH_CORE:Ability.ENERGY_ORB;
            if (rng.nextFloat()<0.72f) {
                float len=(float)Math.sqrt(dx*dx+dy*dy); if (len<1f) len=1f;
                attack(bot, 1, dx/len, dy/len);
            }
        }

        if (bot.grounded && adx<W*0.22f && rng.nextFloat()<0.012f) bot.vy=-H*0.75f;
    }

    private void attack(Fighter f, int owner, float ax, float ay) {
        if (f.attackCd>0 || roundOver) return;
        Fighter target = owner==0?bot:player;
        float len=(float)Math.sqrt(ax*ax+ay*ay); if (len<0.001f) { ax=f.facing; ay=0; len=1; }
        ax/=len; ay/=len;
        if (Math.abs(ax)>0.12f) f.facing=ax>=0?1:-1;
        float baseSpeed=W*0.64f;
        float spawnX=f.x+ax*f.radius*1.35f;
        float spawnY=f.y+ay*f.radius*0.9f-f.radius*0.12f;

        switch (f.ability) {
            case ENERGY_ORB: {
                addShot(new Shot(spawnX,spawnY,ax*baseSpeed,ay*baseSpeed,f.radius*0.33f,14,0.32f,2.2f,owner));
                f.attackCd=0.38f; break;
            }
            case BOUNCE_DISC: {
                Shot s=new Shot(spawnX,spawnY,ax*baseSpeed*0.78f,ay*baseSpeed*0.78f,f.radius*0.42f,12,0.42f,3.2f,owner);
                s.bounces=4; s.gravity=true; addShot(s); f.attackCd=0.55f; break;
            }
            case HEAVY_GLOVE: {
                float reach=f.radius*2.8f;
                float tx=target.x-f.x, ty=target.y-f.y;
                float tlen=(float)Math.sqrt(tx*tx+ty*ty); if(tlen<1)tlen=1;
                float dot=(tx/tlen)*ax+(ty/tlen)*ay;
                if (tlen<reach && dot>0.35f) damage(target,26,ax*W*0.42f,ay*H*0.20f-H*0.10f, owner==0?Color.rgb(110,205,255):Color.rgb(255,105,135));
                f.attackCd=0.72f; break;
            }
            case GRAVITY_BURST: {
                float reach=f.radius*4.2f;
                if (distance(f,target)<reach) {
                    float d=Math.signum(target.x-f.x); if (d==0)d=1;
                    damage(target,18,d*W*0.55f,-H*0.32f, owner==0?Color.rgb(110,205,255):Color.rgb(255,105,135));
                }
                burst(f.x,f.y, owner==0?Color.rgb(110,205,255):Color.rgb(255,105,135), 18, 0.8f);
                f.attackCd=0.95f; break;
            }
            case ARC_CORE: {
                Shot s=new Shot(spawnX,spawnY,ax*baseSpeed*0.90f,ay*baseSpeed*0.90f,f.radius*0.31f,17,0.38f,2.2f,owner);
                s.gravity=true; addShot(s); f.attackCd=0.66f; break;
            }
            case TRIPLE_SPARK: {
                float angle=(float)Math.atan2(ay,ax);
                for (int i=-1;i<=1;i++) {
                    float a=angle+i*0.13f;
                    float dx=(float)Math.cos(a), dy=(float)Math.sin(a);
                    addShot(new Shot(f.x+dx*f.radius*1.3f,f.y+dy*f.radius*0.9f,dx*baseSpeed*0.84f,dy*baseSpeed*0.84f,f.radius*0.22f,8,0.18f,1.8f,owner));
                }
                f.attackCd=0.62f; break;
            }
            case SHIELD_PULSE: {
                f.shield=1.45f; f.attackCd=1.25f;
                burst(f.x,f.y, owner==0?Color.rgb(110,205,255):Color.rgb(255,105,135), 14, 0.6f);
                break;
            }
            case DASH_CORE: {
                f.vx=ax*W*0.72f; f.vy+=ay*H*0.35f; f.invuln=0.18f;
                if (distance(f,target)<f.radius*3.2f) damage(target,16,ax*W*0.48f,ay*H*0.22f-H*0.08f, owner==0?Color.rgb(110,205,255):Color.rgb(255,105,135));
                f.attackCd=0.82f; break;
            }
        }
    }

    private void addShot(Shot shot) {
        if (shots.size() >= MAX_SHOTS) shots.remove(0);
        shots.add(shot);
    }

    private void updateShots(float dt) {
        Iterator<Shot> it=shots.iterator();
        while(it.hasNext()) {
            Shot s=it.next();
            s.life-=dt;
            s.trailX += (s.x-s.trailX)*0.35f;
            s.trailY += (s.y-s.trailY)*0.35f;
            if (s.gravity) s.vy += H*1.22f*dt;
            s.x+=s.vx*dt; s.y+=s.vy*dt;
            if (s.bounces>0) {
                boolean bounced=false;
                if (s.x-s.radius<0 || s.x+s.radius>W) { s.vx*=-0.82f; s.x=clamp(s.x,s.radius,W-s.radius); bounced=true; }
                if (s.y+s.radius>groundY) { s.vy=-Math.abs(s.vy)*0.72f; s.y=groundY-s.radius; bounced=true; }
                if (bounced) { s.bounces--; burst(s.x,s.y,s.owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135),5,0.32f); }
            }
            Fighter target=s.owner==0?bot:player;
            float dx=s.x-target.x, dy=s.y-target.y;
            if (dx*dx+dy*dy < (s.radius+target.radius)*(s.radius+target.radius)) {
                float speed=(float)Math.sqrt(s.vx*s.vx+s.vy*s.vy); if(speed<1)speed=1;
                damage(target,s.damage,(s.vx/speed)*W*s.knockback,(s.vy/speed)*H*0.18f-H*0.06f,s.owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135));
                it.remove(); continue;
            }
            if (s.life<=0 || s.x<-100 || s.x>W+100 || s.y<-150 || s.y>H+150) it.remove();
        }
    }

    private void damage(Fighter target, float amount, float kbX, float kbY, int fxColor) {
        if (target.invuln>0) return;
        float factor=target.shield>0?0.28f:1f;
        target.hp-=amount*factor;
        target.vx += kbX*factor;
        target.vy += kbY*factor;
        target.invuln=0.08f;
        burst(target.x,target.y,fxColor,12,0.55f);
    }

    private void burst(float x,float y,int color,int count,float speedScale) {
        int room = Math.max(0, MAX_PARTICLES - particles.size());
        count = Math.min(count, room);
        for(int i=0;i<count;i++) {
            float a=rng.nextFloat()*(float)Math.PI*2f;
            float sp=(0.25f+rng.nextFloat()*0.75f)*Math.min(W,H)*speedScale;
            particles.add(new Particle(x,y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp,0.22f+rng.nextFloat()*0.22f,2f+rng.nextFloat()*5f,color));
        }
    }

    private void updateParticles(float dt) {
        Iterator<Particle> it=particles.iterator();
        while(it.hasNext()) {
            Particle p=it.next(); p.life-=dt;
            float dragX=Math.max(0f,1f-7.0f*dt), dragY=Math.max(0f,1f-6.0f*dt);
            p.vx*=dragX; p.vy*=dragY;
            p.x+=p.vx*dt; p.y+=p.vy*dt;
            if(p.life<=0) it.remove();
        }
    }

    private void endRound() {
        roundOver=true; roundResetTimer=1.65f;
        if (player.hp<=0) botScore++; else playerScore++;
        if (playerScore>=3 || botScore>=3) matchOver=true;
    }

    private static float distance(Fighter a, Fighter b) {
        float dx=a.x-b.x, dy=a.y-b.y; return (float)Math.sqrt(dx*dx+dy*dy);
    }
    private static float clamp(float v,float lo,float hi){ return Math.max(lo,Math.min(hi,v)); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (W<=0||H<=0||player==null||bot==null) return;

        drawArena(c);
        drawFighter(c,player,Color.rgb(82,183,255),Color.rgb(170,230,255));
        drawFighter(c,bot,Color.rgb(255,82,115),Color.rgb(255,180,195));
        for(Shot s:shots) drawShot(c,s);
        drawParticles(c);
        drawHud(c);
        drawJoystick(c);
        drawWeaponButton(c);

        if (roundOver && !matchOver) {
            drawCenterText(c, player.hp<=0?"BOT WINS ROUND":"YOU WIN ROUND", H*0.43f, H*0.056f, Color.WHITE);
        }
        if (matchOver) {
            paint.setShader(null);
            paint.setColor(0xE610182B);
            c.drawRect(0,0,W,H,paint);
            drawCenterText(c, playerScore>botScore?"YOU WIN!":"BOT WINS", H*0.42f, H*0.09f, Color.WHITE);
            drawCenterText(c, "Tap anywhere to restart", H*0.54f, H*0.034f, Color.rgb(205,220,240));
        }
    }

    private void rebuildArenaBitmap(int width, int height) {
        if (width <= 0 || height <= 0) return;
        if (arenaBitmap != null && !arenaBitmap.isRecycled()) arenaBitmap.recycle();
        arenaBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        Canvas c = new Canvas(arenaBitmap);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0,0,0,H, new int[]{Color.rgb(7,12,28),Color.rgb(18,29,55),Color.rgb(31,39,63)}, null, Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,paint); paint.setShader(null);

        float moonX=W*0.78f, moonY=H*0.19f, moonR=Math.min(W,H)*0.075f;
        paint.setShader(new RadialGradient(moonX,moonY,moonR*2.8f,new int[]{0x667AD8FF,0x227AD8FF,0x007AD8FF},null,Shader.TileMode.CLAMP));
        c.drawCircle(moonX,moonY,moonR*2.8f,paint); paint.setShader(null);
        paint.setColor(Color.rgb(205,235,255)); c.drawCircle(moonX,moonY,moonR,paint);
        paint.setColor(0x332C537A); c.drawCircle(moonX-moonR*0.25f,moonY-moonR*0.15f,moonR*0.22f,paint);

        paint.setColor(0xCCFFFFFF);
        for(int i=0;i<starX.length;i++) c.drawCircle(starX[i]*W, starY[i]*H, starR[i]*Math.max(1f,H/720f), paint);

        paint.setColor(Color.rgb(18,27,48));
        for(int i=0;i<14;i++) {
            float bw=W/14f; float bh=H*(0.08f+(i%5)*0.018f);
            c.drawRect(i*bw,groundY-bh,i*bw+bw*0.82f,groundY,paint);
        }
        paint.setColor(0x553DA5E8);
        for(int i=0;i<28;i++) {
            float x=(i+0.3f)*W/28f; float y=groundY-H*(0.035f+(i%4)*0.015f);
            c.drawRect(x,y,x+W*0.006f,y+H*0.008f,paint);
        }

        paint.setShader(new LinearGradient(0,groundY,0,H,Color.rgb(38,52,76),Color.rgb(13,19,34),Shader.TileMode.CLAMP));
        c.drawRect(0,groundY,W,H,paint); paint.setShader(null);
        paint.setColor(Color.rgb(91,170,220)); c.drawRect(0,groundY,W,groundY+Math.max(4f,H*0.006f),paint);
        paint.setColor(0x4457C7FF);
        for(int i=0;i<10;i++) {
            float x=i*W/10f; c.drawRect(x+W*0.01f,groundY+H*0.02f,x+W*0.085f,groundY+H*0.025f,paint);
        }
        paint.setShader(null);
    }

    private void drawArena(Canvas c) {
        if (arenaBitmap != null && !arenaBitmap.isRecycled()) {
            c.drawBitmap(arenaBitmap, 0, 0, paint);
        } else {
            c.drawColor(Color.rgb(8, 12, 24));
        }
    }

    private void drawFighter(Canvas c,Fighter f,int color,int lightColor) {
        float r=f.radius;
        float bodyTop=f.y-r*0.23f, bodyBottom=f.y+r*0.62f;
        float headY=f.y-r*0.78f, headR=r*0.48f;

        // Soft glow without allocating a gradient every frame.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor((color & 0x00FFFFFF) | 0x22000000);
        c.drawCircle(f.x,f.y,r*1.75f,paint);
        paint.setColor((color & 0x00FFFFFF) | 0x33000000);
        c.drawCircle(f.x,f.y,r*1.28f,paint);

        // Body shadow/outline.
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(11f,r*0.34f)); paint.setColor(0xAA050810);
        c.drawLine(f.x,bodyTop,f.x,bodyBottom,paint);
        c.drawLine(f.x,f.y+r*0.02f,f.x-r*0.72f*f.facing,f.y+r*0.36f,paint);
        c.drawLine(f.x,f.y+r*0.02f,f.x+r*0.83f*f.facing,f.y-r*0.10f,paint);
        c.drawLine(f.x,bodyBottom,f.x-r*0.56f,f.y+r*1.10f,paint);
        c.drawLine(f.x,bodyBottom,f.x+r*0.56f,f.y+r*1.10f,paint);
        c.drawCircle(f.x,headY,headR,paint);

        paint.setStrokeWidth(Math.max(7f,r*0.24f)); paint.setColor(color);
        c.drawLine(f.x,bodyTop,f.x,bodyBottom,paint);
        c.drawLine(f.x,f.y+r*0.02f,f.x-r*0.72f*f.facing,f.y+r*0.36f,paint);
        c.drawLine(f.x,f.y+r*0.02f,f.x+r*0.83f*f.facing,f.y-r*0.10f,paint);
        c.drawLine(f.x,bodyBottom,f.x-r*0.56f,f.y+r*1.10f,paint);
        c.drawLine(f.x,bodyBottom,f.x+r*0.56f,f.y+r*1.10f,paint);
        c.drawCircle(f.x,headY,headR,paint);

        // Head glass / eyes.
        paint.setStyle(Paint.Style.FILL); paint.setColor(lightColor);
        c.drawCircle(f.x+f.facing*headR*0.34f,headY-headR*0.08f,headR*0.10f,paint);
        c.drawRoundRect(f.x-headR*0.12f,headY+headR*0.10f,f.x+f.facing*headR*0.46f,headY+headR*0.22f,headR*0.06f,headR*0.06f,paint);

        if (f.shield>0) {
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(4f,r*0.10f)); paint.setColor(lightColor);
            c.drawCircle(f.x,f.y,r*1.58f,paint);
            paint.setColor(lightColor & 0x66FFFFFF); paint.setStrokeWidth(Math.max(10f,r*0.24f)); c.drawCircle(f.x,f.y,r*1.58f,paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawShot(Canvas c,Shot s) {
        int core=s.owner==0?Color.rgb(105,220,255):Color.rgb(255,105,140);
        int glow=s.owner==0?0x8875D8FF:0x88FF6A92;
        float speed=(float)Math.sqrt(s.vx*s.vx+s.vy*s.vy); if(speed<1)speed=1;
        float nx=s.vx/speed, ny=s.vy/speed;

        paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(s.radius*1.3f); paint.setColor(glow);
        c.drawLine(s.x-nx*s.radius*2.8f,s.y-ny*s.radius*2.8f,s.x,s.y,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(glow); c.drawCircle(s.x,s.y,s.radius*1.75f,paint);
        paint.setColor(core); c.drawCircle(s.x,s.y,s.radius,paint);
        paint.setColor(Color.WHITE); c.drawCircle(s.x,s.y,s.radius*0.38f,paint);
    }

    private void drawParticles(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        for(Particle p:particles) {
            int a=(int)(255f*clamp(p.life/p.maxLife,0,1));
            paint.setColor((p.color & 0x00FFFFFF) | (a<<24));
            c.drawCircle(p.x,p.y,p.size*(0.5f+0.5f*p.life/p.maxLife),paint);
        }
    }

    private void drawHud(Canvas c) {
        float barW=W*0.30f, barH=Math.max(16f,H*0.030f), y=H*0.045f;
        drawHealthBar(c,W*0.035f,y,barW,barH,player.hp,Color.rgb(82,183,255),false);
        drawHealthBar(c,W*0.965f-barW,y,barW,barH,bot.hp,Color.rgb(255,82,115),true);

        paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(H*0.046f); paint.setColor(Color.WHITE);
        c.drawText(playerScore+"  :  "+botScore,W*0.5f,H*0.078f,paint);
        paint.setTextSize(H*0.022f); paint.setColor(Color.rgb(180,205,230));
        c.drawText("AUTO FIRE • RIGHT JOYSTICK TO AIM",W*0.5f,H*0.115f,paint);
    }

    private void drawHealthBar(Canvas c,float x,float y,float w,float h,float hp,int color,boolean reverse) {
        paint.setColor(0xAA111827); c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,paint);
        float fw=w*(clamp(hp,0,100)/100f);
        paint.setColor(color);
        if(reverse) c.drawRoundRect(x+w-fw,y,x+w,y+h,h/2,h/2,paint);
        else c.drawRoundRect(x,y,x+fw,y+h,h/2,h/2,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setColor(0x66FFFFFF); c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,paint); paint.setStyle(Paint.Style.FILL);
    }

    private void drawJoystick(Canvas c) {
        float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY);
        float kx=joyCx+joyX*joyRadius*0.72f;
        float ky=joyCy+joyY*joyRadius*0.72f;

        paint.setStyle(Paint.Style.FILL); paint.setColor(0x44233752); c.drawCircle(joyCx,joyCy,joyRadius,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(3f,H*0.004f)); paint.setColor(0x7799CFFF); c.drawCircle(joyCx,joyCy,joyRadius,paint);
        paint.setColor(0x448AD5FF); c.drawCircle(joyCx,joyCy,joyRadius*0.64f,paint);

        // Jump charge ring.
        if (jumpCharge>0f) {
            paint.setStrokeWidth(Math.max(7f,H*0.009f)); paint.setColor(Color.rgb(255,210,85));
            c.drawArc(jumpArcRect,-90,360f*clamp(jumpCharge/0.5f,0,1),false,paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x665BBFFF); c.drawCircle(kx,ky,knobRadius*1.35f,paint);
        paint.setColor(0xEEC2ECFF); c.drawCircle(kx,ky,knobRadius,paint);
        paint.setColor(Color.rgb(235,250,255)); c.drawCircle(kx,ky,knobRadius*0.50f,paint);

        // Aim arrow.
        if (mag>0.22f) {
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(4f,H*0.006f)); paint.setColor(0xCCFFFFFF);
            c.drawLine(joyCx,joyCy,joyCx+aimX*joyRadius*1.35f,joyCy+aimY*joyRadius*1.35f,paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawWeaponButton(Canvas c) {
        paint.setColor(0x8818263B); c.drawRoundRect(weaponBtn,24,24,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.5f); paint.setColor(0x8899D7FF); c.drawRoundRect(weaponBtn,24,24,paint); paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setColor(Color.WHITE);
        paint.setTextSize(Math.min(weaponBtn.height()*0.25f,22f*getResources().getDisplayMetrics().scaledDensity));
        c.drawText(player.ability.title,weaponBtn.centerX(),weaponBtn.centerY()-paint.getTextSize()*0.05f,paint);
        paint.setTextSize(paint.getTextSize()*0.62f); paint.setColor(Color.rgb(160,200,230));
        c.drawText("TAP TO SWITCH",weaponBtn.centerX(),weaponBtn.centerY()+weaponBtn.height()*0.28f,paint);
    }

    private void drawCenterText(Canvas c,String text,float y,float size,int color) {
        paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(size); paint.setColor(color); c.drawText(text,W/2f,y,paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (matchOver && e.getActionMasked()==MotionEvent.ACTION_DOWN) {
            playerScore=0; botScore=0; matchOver=false; startRound(); return true;
        }

        int action=e.getActionMasked();
        int index=e.getActionIndex();

        if (action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
            float x=e.getX(index), y=e.getY(index);
            if (weaponBtn.contains(x,y)) {
                nextAbility();
                return true;
            }
            if (joystickPointerId==-1 && x > W*0.52f && y > H*0.42f) {
                joystickPointerId=e.getPointerId(index);
                updateJoystick(x,y);
            }
        } else if (action==MotionEvent.ACTION_MOVE) {
            if (joystickPointerId!=-1) {
                int idx=e.findPointerIndex(joystickPointerId);
                if (idx>=0) updateJoystick(e.getX(idx),e.getY(idx));
            }
        } else if (action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_UP) {
            int id=e.getPointerId(index);
            if (id==joystickPointerId) resetJoystick();
        } else if (action==MotionEvent.ACTION_CANCEL) {
            resetJoystick();
        }
        return true;
    }

    private void updateJoystick(float x,float y) {
        float dx=x-joyCx, dy=y-joyCy;
        float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>joyRadius && len>0) { dx=dx/len*joyRadius; dy=dy/len*joyRadius; }
        joyX=clamp(dx/joyRadius,-1,1);
        joyY=clamp(dy/joyRadius,-1,1);
    }

    private void resetJoystick() {
        joystickPointerId=-1; joyX=0f; joyY=0f; jumpCharge=0f; jumpLatched=false;
    }

    private void nextAbility() {
        Ability[] a=Ability.values();
        player.ability=a[(player.ability.ordinal()+1)%a.length];
    }
}
