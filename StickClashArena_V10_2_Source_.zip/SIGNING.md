# Release signing

GitHub repository -> Settings -> Secrets and variables -> Actions -> New repository secret.

Создай четыре секрета:
- SCA_KEYSTORE_B64
- SCA_KEYSTORE_PASSWORD
- SCA_KEY_ALIAS
- SCA_KEY_PASSWORD

Точные значения находятся в отдельном файле `StickClashArena_V10_2_signing_secrets.txt`, который НЕ должен попадать в публичный репозиторий.

Workflow декодирует SCA_KEYSTORE_B64 во временный keystore на GitHub runner и подписывает app-release.apk. Сам ключ не хранится в репозитории.
