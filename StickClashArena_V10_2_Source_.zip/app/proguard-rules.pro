# Stick Clash Arena release rules
-keep class com.sand.stickclasharena.MainActivity { *; }
-keep class com.sand.stickclasharena.GameHostService { *; }
