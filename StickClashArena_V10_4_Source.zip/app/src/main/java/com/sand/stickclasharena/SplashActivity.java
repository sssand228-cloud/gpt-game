package com.sand.stickclasharena;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable launchRunnable = new Runnable() {
        @Override public void run() {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        FrameLayout root = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(12, 18, 32), Color.rgb(22, 38, 68), Color.rgb(12, 18, 32)}
        );
        root.setBackground(bg);

        View glowLeft = new View(this);
        GradientDrawable glowLeftBg = new GradientDrawable();
        glowLeftBg.setShape(GradientDrawable.OVAL);
        glowLeftBg.setColor(Color.argb(95, 0, 220, 255));
        glowLeft.setBackground(glowLeftBg);
        FrameLayout.LayoutParams leftParams = new FrameLayout.LayoutParams(dp(220), dp(220));
        leftParams.gravity = Gravity.START | Gravity.TOP;
        leftParams.leftMargin = dp(50);
        leftParams.topMargin = dp(35);
        root.addView(glowLeft, leftParams);

        View glowRight = new View(this);
        GradientDrawable glowRightBg = new GradientDrawable();
        glowRightBg.setShape(GradientDrawable.OVAL);
        glowRightBg.setColor(Color.argb(95, 255, 170, 0));
        glowRight.setBackground(glowRightBg);
        FrameLayout.LayoutParams rightParams = new FrameLayout.LayoutParams(dp(220), dp(220));
        rightParams.gravity = Gravity.END | Gravity.BOTTOM;
        rightParams.rightMargin = dp(50);
        rightParams.bottomMargin = dp(35);
        root.addView(glowRight, rightParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(32), dp(28), dp(32), dp(28));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(dp(26));
        panelBg.setColor(Color.argb(205, 10, 16, 28));
        panelBg.setStroke(dp(2), Color.argb(160, 90, 225, 255));
        panel.setBackground(panelBg);
        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );

        TextView title = new TextView(this);
        title.setText("STICK CLASH");
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        title.setGravity(Gravity.CENTER);
        panel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("ARENA");
        subtitle.setTextColor(Color.rgb(120, 235, 255));
        subtitle.setTypeface(Typeface.DEFAULT_BOLD);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(2), 0, dp(14));
        panel.addView(subtitle);

        TextView byline = new TextView(this);
        byline.setText("Telegram creator");
        byline.setTextColor(Color.rgb(186, 210, 232));
        byline.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        byline.setGravity(Gravity.CENTER);
        panel.addView(byline);

        TextView tg = new TextView(this);
        tg.setText("@asperinl");
        tg.setTextColor(Color.rgb(255, 215, 90));
        tg.setTypeface(Typeface.DEFAULT_BOLD);
        tg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tg.setGravity(Gravity.CENTER);
        tg.setPadding(0, dp(4), 0, dp(6));
        panel.addView(tg);

        TextView hint = new TextView(this);
        hint.setText("Loading...");
        hint.setTextColor(Color.rgb(180, 205, 232));
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        hint.setGravity(Gravity.CENTER);
        panel.addView(hint);

        root.addView(panel, panelParams);
        setContentView(root);

        handler.postDelayed(launchRunnable, 2200L);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(launchRunnable);
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
