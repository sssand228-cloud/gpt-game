package com.sand.stickclasharena;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.text.InputType;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.json.JSONArray;
import org.json.JSONObject;

public class GameView extends View implements Runnable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final List<Shot> shots = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private final List<BeamFx> beams = new ArrayList<>();
    private static final int MAX_SHOTS = 64;
    private static final int MAX_PARTICLES = 150;

    private final SharedPreferences prefs;

    // Creator Mode uses a random local device/install code instead of IMEI or serial numbers.
    // The owner sends this code once; a later build can whitelist it without collecting hardware IDs.
    private final String deviceCode;
    private boolean creatorMode;
    private static final String[] CREATOR_DEVICE_CODES = {
            "61A7-FD73-A887"
    };

    private Bitmap arenaBitmap;
    private float W, H, groundY;
    private boolean running;
    private long lastNs;
    private long accumulatorNs;
    private static final long UPDATE_STEP_NS = 16_000_000L;

    private enum Screen { HOME, ONLINE, ARMORY, SHOP, ACCESSORIES, SETTINGS, ADMIN, BATTLE }
    private Screen screen = Screen.HOME;

    private enum Difficulty {
        EASY("ЛЕГКО", 5),
        MEDIUM("СРЕДНЕ", 7),
        HARD("СЛОЖНО", 15);
        final String title;
        final int reward;
        Difficulty(String title, int reward) { this.title = title; this.reward = reward; }
    }

    private enum GameMode {
        SOLO("1 ИГРОК"),
        TWO_PLAYER("2 ИГРОКА"),
        ONLINE("ОНЛАЙН");
        final String title;
        GameMode(String title){ this.title=title; }
    }

    private enum ArenaType {
        ROOFTOP("НЕОНОВАЯ КРЫША", "классическая арена"),
        SPLIT("РАЗЛОМ", "провал в центре"),
        LOW_GRAV("ЛУННАЯ СТАНЦИЯ", "пониженная гравитация"),
        BOUNCE("ПРУЖИННЫЙ ПОЛ", "сильные отскоки");
        final String title, desc;
        ArenaType(String title,String desc){this.title=title;this.desc=desc;}
    }

    private enum Accessory {
        NONE("БЕЗ АКСЕССУАРА", "чистый стиль", 0),
        HEADBAND("ПОВЯЗКА", "спортивная лента", 0),
        VISOR("ВИЗОР", "неоновый боевой визор", 0),
        HEADPHONES("НАУШНИКИ", "арена в ритме", 0),
        CROWN("КОРОНА", "чемпион арены", 75),
        CAPE("ПЛАЩ", "геройский силуэт", 90),
        HORNS("РОГА", "демонический стиль", 110),
        HALO("НИМБ", "энергетическое кольцо", 140);
        final String title, desc;
        final int price;
        Accessory(String title,String desc,int price){this.title=title;this.desc=desc;this.price=price;}
    }

    enum Ability {
        ENERGY_ORB("ЭНЕРГОСФЕРА", "Быстрый энергетический шар", 0),
        BOUNCE_DISC("РИКОШЕТ-ДИСК", "Отскакивает от пола и стен", 0),
        HEAVY_GLOVE("ТЯЖЕЛЫЙ УДАР", "Мощная атака вблизи", 0),
        GRAVITY_BURST("ГРАВИ-ВЗРЫВ", "Отбрасывает врага вокруг тебя", 0),
        ARC_CORE("ДУГА-ЯДРО", "Тяжелый снаряд летит по дуге", 0),
        TRIPLE_SPARK("ТРОЙНАЯ ИСКРА", "Три быстрых снаряда веером", 25),
        SHIELD_PULSE("ИМПУЛЬС-ЩИТ", "Временно сильно снижает урон", 35),
        DASH_CORE("РЫВОК-ЯДРО", "Рывок вперед с ударом", 45),
        FROST_SHARD("ЛЕДЯНОЙ ОСКОЛОК", "Попадание замедляет врага", 60),
        LASER_BEAM("ЛАЗЕРНЫЙ ЛУЧ", "Мгновенный дальний луч", 75),
        MINE_CORE("МИНА-ЯДРО", "Оставляет мину на арене", 90),
        RETURN_BLADE("ВОЗВРАТНЫЙ КЛИНОК", "Летит вперед и возвращается", 110),
        SKY_DROP("НЕБЕСНЫЙ УДАР", "Снаряд падает сверху на цель", 130),
        VAMPIRE_BOLT("ПОГЛОТИТЕЛЬ", "Попадание лечит стрелка", 160),
        BLINK_STRIKE("ТЕЛЕПОРТ-УДАР", "Телепорт к врагу и удар", 200);

        final String title;
        final String desc;
        final int price;
        Ability(String title, String desc, int price) {
            this.title = title; this.desc = desc; this.price = price;
        }
    }

    static class Fighter {
        float x, y, vx, vy;
        float radius;
        float hp = 100f;
        float shield = 0f;
        float attackCd = 0f;
        float invuln = 0f;
        float slowTimer = 0f;
        float landingSquash = 0f;
        boolean grounded = false;
        int facing = 1;
        Ability ability = Ability.ENERGY_ORB;
        Accessory accessory = Accessory.NONE;
        final boolean isBot;
        Fighter(boolean isBot) { this.isBot = isBot; }
    }

    static class Shot {
        float x, y, vx, vy, radius, damage, knockback, life, maxLife;
        int owner;
        int bounces;
        boolean gravity;
        boolean frost;
        boolean healOnHit;
        boolean mine;
        boolean armed;
        float armTimer;
        boolean returning;
        boolean hasReturned;
        Ability source;
        Shot(float x, float y, float vx, float vy, float r, float d, float k, float life, int owner, Ability source) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.radius=r; this.damage=d; this.knockback=k;
            this.life=life; this.maxLife=life; this.owner=owner; this.source=source;
        }
    }

    static class Particle {
        float x, y, vx, vy, life, maxLife, size;
        int color;
        Particle(float x, float y, float vx, float vy, float life, float size, int color) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.life=life; this.maxLife=life; this.size=size; this.color=color;
        }
    }

    static class BeamFx {
        float x1, y1, x2, y2, life, maxLife, width;
        int color;
        Ability source;
        BeamFx(float x1,float y1,float x2,float y2,float life,float width,int color,Ability source){
            this.x1=x1;this.y1=y1;this.x2=x2;this.y2=y2;this.life=life;this.maxLife=life;this.width=width;this.color=color;this.source=source;
        }
    }

    private Fighter player, bot;
    private int playerScore = 0, botScore = 0;
    private boolean roundOver = false, matchOver = false;
    private float roundResetTimer = 0f;
    private boolean rewardGranted = false;
    private int lastReward = 0;
    private float botBrainTimer = 0f;
    private float hitStopTimer = 0f;
    private float cameraShakeTimer = 0f;
    private float cameraShakePower = 0f;
    private float hitFlashTimer = 0f;

    private int coins = 0;
    private final boolean[] unlocked = new boolean[Ability.values().length];
    private Ability selectedAbility = Ability.ENERGY_ORB;
    private Accessory selectedAccessory = Accessory.NONE;
    private final boolean[] accessoryOwned = new boolean[Accessory.values().length];
    private Difficulty difficulty = Difficulty.EASY;
    private GameMode gameMode = GameMode.SOLO;
    private ArenaType arenaType = ArenaType.ROOFTOP;

    // Persistent career stats and Creator-only debug/admin controls.
    private int totalWins = 0;
    private int totalLosses = 0;
    private int totalCoinsEarned = 0;
    private boolean adminGodMode = false;
    private boolean adminTurboCooldown = false;
    private boolean adminDoubleDamage = false;
    private boolean adminFreezeBot = false;

    // V10 phone-server beta: the host Android phone runs the authoritative match server.
    private final ConcurrentLinkedQueue<String> onlineEvents = new ConcurrentLinkedQueue<>();
    private OnlinePeer onlinePeer;
    private String onlineStatus = "НЕ ПОДКЛЮЧЕНО";
    private boolean onlineHosting = false;
    private int onlineLocalIndex = -1; // host = fighter 0, guest = fighter 1
    private int onlineAbility0 = 0, onlineAbility1 = 0;
    private int onlineAccessory0 = 0, onlineAccessory1 = 0;
    private float remoteJoyX = 0f, remoteJoyY = 0f;
    private float remoteAimX = 1f, remoteAimY = 0f;
    private float remoteJumpCharge = 0f;
    private boolean remoteJumpLatched = false;
    private float onlineInputTimer = 0f, onlineSnapshotTimer = 0f;
    private boolean onlineResultSent = false;
    private String onlineHostIp = "IP НЕ НАЙДЕН";
    private String onlineHostIpv6 = "НЕТ";
    private String onlineRoomCode = "------";

    private SoundPool soundPool;
    private final int[] weaponSoundIds = new int[Ability.values().length];

    // Visual customization. Indexes point into COLOR_PALETTE.
    private static final int[] COLOR_PALETTE = {
            0xFF52B7FF, 0xFFFF5273, 0xFF5DE0A0, 0xFFFFB24A,
            0xFF9C7CFF, 0xFFFFE06E, 0xFF58E5E8, 0xFFF3F7FF
    };
    private int playerColorIdx = 0;
    private int botColorIdx = 1;
    private int uiColorIdx = 0;
    private int joystickColorIdx = 0;
    private int projectileColorIdx = 6;
    private int arenaColorIdx = 4;

    // Joystick customization: 0 = left, 1 = right. Size/sensitivity: 0..2.
    private int joystickSide = 1;
    private int joystickSize = 1;
    private int joystickSensitivity = 1;
    private int joystickStyle = 0;
    // 0 performance, 1 balanced, 2 ultra.
    private int graphicsQuality = 1;

    // Joystick controls move + aim + jump charge.
    private int joystickPointerId = -1;
    private float joyCx, joyCy, joyRadius, knobRadius;
    private float joyX = 0f, joyY = 0f;
    private float aimX = 1f, aimY = 0f;
    private float jumpCharge = 0f;
    private boolean jumpLatched = false;
    private final RectF jumpArcRect = new RectF();

    // Local 2-player controls. In 2P mode P1 uses the left stick and P2 the right stick.
    private int joystick2PointerId = -1;
    private float joy2Cx, joy2Cy, joy2Radius, knob2Radius;
    private float joy2X = 0f, joy2Y = 0f;
    private float aim2X = -1f, aim2Y = 0f;
    private float jump2Charge = 0f;
    private boolean jump2Latched = false;
    private final RectF jump2ArcRect = new RectF();

    // Menu / overlay hitboxes.
    private final RectF playBtn = new RectF();
    private final RectF modeBtn = new RectF();
    private final RectF arenaBtn = new RectF();
    private final RectF armoryBtn = new RectF();
    private final RectF randomBtn = new RectF();
    private final RectF shopBtn = new RectF();
    private final RectF settingsBtn = new RectF();
    private final RectF onlineBtn = new RectF();
    private final RectF accessoriesBtn = new RectF();
    private final RectF onlineHostBtn = new RectF();
    private final RectF onlineJoinBtn = new RectF();
    private final RectF onlineCancelBtn = new RectF();
    private final RectF backBtn = new RectF();
    private final RectF againBtn = new RectF();
    private final RectF menuBtn = new RectF();
    private final RectF joySideBtn = new RectF();
    private final RectF joySizeBtn = new RectF();
    private final RectF joySensitivityBtn = new RectF();
    private final RectF joyStyleBtn = new RectF();
    private final RectF qualityBtn = new RectF();
    private final RectF resetSettingsBtn = new RectF();
    private final RectF creatorCodePanel = new RectF();
    private final RectF[] adminActionBtns = {new RectF(),new RectF(),new RectF(),new RectF(),new RectF(),new RectF(),new RectF()};
    private final RectF tmpRect = new RectF();
    private final RectF shapeRect = new RectF();
    private final RectF[] colorSettingRects = {new RectF(),new RectF(),new RectF(),new RectF(),new RectF(),new RectF(),new RectF()};
    private final RectF[] difficultyBtns = { new RectF(), new RectF(), new RectF() };
    private final RectF[] itemRects = new RectF[Ability.values().length];
    private final RectF[] accessoryRects = new RectF[Accessory.values().length];

    private final float[] starX = new float[64];
    private final float[] starY = new float[64];
    private final float[] starR = new float[64];

    public GameView(Context context) {
        super(context);
        setKeepScreenOn(true);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setDither(true);
        setBackgroundColor(Color.rgb(8,12,24));
        prefs = context.getSharedPreferences("stick_clash_v4", Context.MODE_PRIVATE);
        onlinePeer = new OnlinePeer(new OnlinePeer.Listener() {
            @Override public void onStatus(String status) { onlineEvents.add("@status:" + status); }
            @Override public void onConnected(boolean host) { onlineEvents.add("@connected:" + (host ? "1" : "0")); }
            @Override public void onMessage(String message) { onlineEvents.add("@msg:" + message); }
            @Override public void onDisconnected(String reason) { onlineEvents.add("@disconnected:" + reason); }
        });
        deviceCode = loadOrCreateDeviceCode();
        creatorMode = prefs.getBoolean("creator_mode_activated", false) || isCreatorDevice(deviceCode);
        loadProgress();
        initWeaponSounds();
        if (creatorMode) {
            prefs.edit().putBoolean("creator_mode_activated", true).apply();
            applyCreatorBenefits();
        }
        for (int i=0;i<itemRects.length;i++) itemRects[i] = new RectF();
        for (int i=0;i<accessoryRects.length;i++) accessoryRects[i] = new RectF();
        for (int i=0;i<starX.length;i++) {
            starX[i]=rng.nextFloat(); starY[i]=rng.nextFloat()*0.58f; starR[i]=0.6f+rng.nextFloat()*1.8f;
        }
    }

    private String loadOrCreateDeviceCode() {
        String code = prefs.getString("creator_device_code", null);
        if (code != null && code.matches("[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}")) return code;
        // V7.1 owner-build migration: on a fresh install, keep the owner's submitted code
        // so Creator Mode survives the one-time transition from older debug-signed APKs.
        code = "61A7-FD73-A887";
        prefs.edit().putString("creator_device_code", code).apply();
        return code;
    }

    private boolean isCreatorDevice(String code) {
        if (code == null) return false;
        for (String allowed : CREATOR_DEVICE_CODES) {
            if (code.equalsIgnoreCase(allowed)) return true;
        }
        return false;
    }

    private void applyCreatorBenefits() {
        coins = Math.max(coins, 9999);
    }

    private boolean isAbilityAvailable(int index) {
        return creatorMode || (index >= 0 && index < unlocked.length && unlocked[index]);
    }

    private void initWeaponSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
        int[] res = {
                R.raw.energy_orb, R.raw.bounce_disc, R.raw.heavy_glove, R.raw.gravity_burst, R.raw.arc_core,
                R.raw.triple_spark, R.raw.shield_pulse, R.raw.dash_core, R.raw.frost_shard, R.raw.laser_beam,
                R.raw.mine_core, R.raw.return_blade, R.raw.sky_drop, R.raw.vampire_bolt, R.raw.blink_strike
        };
        for (int i=0;i<weaponSoundIds.length&&i<res.length;i++) weaponSoundIds[i]=soundPool.load(getContext(),res[i],1);
    }

    private void playWeaponSound(Ability ability) {
        if(soundPool==null||ability==null)return;
        int idx=ability.ordinal();
        if(idx<0||idx>=weaponSoundIds.length||weaponSoundIds[idx]==0)return;
        float pitch=0.96f+rng.nextFloat()*0.08f;
        soundPool.play(weaponSoundIds[idx],0.62f,0.62f,1,0,pitch);
    }

    private boolean isAccessoryAvailable(int index) {
        return creatorMode || (index>=0 && index<accessoryOwned.length && accessoryOwned[index]);
    }

    private void loadProgress() {
        coins = prefs.getInt("coins", 0);
        Ability[] a = Ability.values();
        // Stable ownership keys make purchases survive future updates and enum reordering.
        for (int i=0;i<a.length;i++) {
            boolean legacy = prefs.getBoolean("unlock_"+i, i<5);
            unlocked[i] = i<5 || prefs.getBoolean("owned_"+a[i].name(), legacy);
        }
        Accessory[] acc = Accessory.values();
        for(int i=0;i<acc.length;i++){
            boolean free = acc[i].price==0;
            accessoryOwned[i] = free || prefs.getBoolean("acc_owned_"+acc[i].name(), free);
        }
        String accName=prefs.getString("selected_accessory",Accessory.NONE.name());
        try{selectedAccessory=Accessory.valueOf(accName);}catch(Exception ignored){selectedAccessory=Accessory.NONE;}
        if(!isAccessoryAvailable(selectedAccessory.ordinal()))selectedAccessory=Accessory.NONE;
        String selectedName = prefs.getString("selected_name", null);
        int sel = prefs.getInt("selected", 0);
        if(selectedName!=null){
            try{ sel=Ability.valueOf(selectedName).ordinal(); }catch(Exception ignored){}
        }
        if (sel < 0 || sel >= a.length || (!creatorMode && !unlocked[sel])) sel = 0;
        selectedAbility = a[sel];
        int d = prefs.getInt("difficulty", 0);
        if (d < 0 || d >= Difficulty.values().length) d = 0;
        difficulty = Difficulty.values()[d];
        int gm=clampInt(prefs.getInt("game_mode",0),0,GameMode.values().length-1);
        gameMode=GameMode.values()[gm];
        int ar=clampInt(prefs.getInt("arena_type",0),0,ArenaType.values().length-1);
        arenaType=ArenaType.values()[ar];

        playerColorIdx = safeColorIndex(prefs.getInt("color_player", 0));
        botColorIdx = safeColorIndex(prefs.getInt("color_bot", 1));
        uiColorIdx = safeColorIndex(prefs.getInt("color_ui", 0));
        joystickColorIdx = safeColorIndex(prefs.getInt("color_joystick", 0));
        projectileColorIdx = safeColorIndex(prefs.getInt("color_projectile", 6));
        arenaColorIdx = safeColorIndex(prefs.getInt("color_arena", 4));

        joystickSide = clampInt(prefs.getInt("joy_side", 1), 0, 1);
        joystickSize = clampInt(prefs.getInt("joy_size", 1), 0, 2);
        joystickSensitivity = clampInt(prefs.getInt("joy_sens", 1), 0, 2);
        joystickStyle = clampInt(prefs.getInt("joy_style", 0), 0, 2);
        graphicsQuality = clampInt(prefs.getInt("graphics_quality", 1), 0, 2);

        totalWins = Math.max(0,prefs.getInt("stats_wins",0));
        totalLosses = Math.max(0,prefs.getInt("stats_losses",0));
        totalCoinsEarned = Math.max(0,prefs.getInt("stats_coins_earned",0));
        adminGodMode = creatorMode && prefs.getBoolean("admin_god",false);
        adminTurboCooldown = creatorMode && prefs.getBoolean("admin_turbo",false);
        adminDoubleDamage = creatorMode && prefs.getBoolean("admin_damage2",false);
        adminFreezeBot = creatorMode && prefs.getBoolean("admin_freeze_bot",false);
    }

    private void saveProgress() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("coins", coins);
        e.putInt("selected", selectedAbility.ordinal());
        e.putString("selected_name", selectedAbility.name());
        e.putInt("difficulty", difficulty.ordinal());
        e.putInt("game_mode",gameMode.ordinal());
        e.putInt("arena_type",arenaType.ordinal());
        Ability[] ownedAbilities=Ability.values();
        for (int i=0;i<unlocked.length;i++) {
            e.putBoolean("unlock_"+i, unlocked[i]);
            e.putBoolean("owned_"+ownedAbilities[i].name(), unlocked[i]);
        }
        e.putString("selected_accessory",selectedAccessory.name());
        Accessory[] savedAccessories=Accessory.values();
        for(int i=0;i<accessoryOwned.length;i++)e.putBoolean("acc_owned_"+savedAccessories[i].name(),accessoryOwned[i]);
        e.putInt("color_player", playerColorIdx);
        e.putInt("color_bot", botColorIdx);
        e.putInt("color_ui", uiColorIdx);
        e.putInt("color_joystick", joystickColorIdx);
        e.putInt("color_projectile", projectileColorIdx);
        e.putInt("color_arena", arenaColorIdx);
        e.putInt("joy_side", joystickSide);
        e.putInt("joy_size", joystickSize);
        e.putInt("joy_sens", joystickSensitivity);
        e.putInt("joy_style", joystickStyle);
        e.putInt("graphics_quality", graphicsQuality);
        e.putInt("stats_wins", totalWins);
        e.putInt("stats_losses", totalLosses);
        e.putInt("stats_coins_earned", totalCoinsEarned);
        e.putBoolean("admin_god", adminGodMode);
        e.putBoolean("admin_turbo", adminTurboCooldown);
        e.putBoolean("admin_damage2", adminDoubleDamage);
        e.putBoolean("admin_freeze_bot", adminFreezeBot);
        e.apply();
    }

    @Override protected void onDetachedFromWindow(){
        super.onDetachedFromWindow();
        if(soundPool!=null){soundPool.release();soundPool=null;}
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        W=w; H=h; groundY=H*0.78f;
        applyJoystickLayout();
        layoutUi();
        rebuildArenaBitmap(w,h);
        invalidate();
    }

    private void layoutUi() {
        float center=W*0.5f;
        float bigW=W*0.42f, bigH=Math.max(H*0.112f,74f);
        playBtn.set(center-bigW*0.5f,H*0.815f,center+bigW*0.5f,H*0.815f+bigH);

        float cardW=W*0.255f, cardH=Math.max(H*0.108f,68f);
        float gap=W*0.025f;
        float menuLeft=(W-(cardW*3+gap*2))*0.5f;
        float row1=H*0.43f, row2=H*0.565f, row3=H*0.70f;
        modeBtn.set(menuLeft,row1,menuLeft+cardW,row1+cardH);
        arenaBtn.set(menuLeft+(cardW+gap),row1,menuLeft+(cardW+gap)+cardW,row1+cardH);
        armoryBtn.set(menuLeft+2*(cardW+gap),row1,menuLeft+2*(cardW+gap)+cardW,row1+cardH);
        shopBtn.set(menuLeft,row2,menuLeft+cardW,row2+cardH);
        accessoriesBtn.set(menuLeft+(cardW+gap),row2,menuLeft+(cardW+gap)+cardW,row2+cardH);
        onlineBtn.set(menuLeft+2*(cardW+gap),row2,menuLeft+2*(cardW+gap)+cardW,row2+cardH);
        randomBtn.set(menuLeft,row3,menuLeft+cardW,row3+cardH);
        settingsBtn.set(menuLeft+(cardW+gap),row3,menuLeft+(cardW+gap)+cardW,row3+cardH);

        onlineHostBtn.set(W*0.18f,H*0.50f,W*0.46f,H*0.63f);
        onlineJoinBtn.set(W*0.54f,H*0.50f,W*0.82f,H*0.63f);
        onlineCancelBtn.set(W*0.36f,H*0.70f,W*0.64f,H*0.81f);

        float diffW=W*0.20f, diffGap=W*0.025f, y=H*0.285f, diffH=H*0.105f;
        float total=diffW*3+diffGap*2;
        float diffX0=(W-total)*0.5f;
        for(int i=0;i<3;i++) difficultyBtns[i].set(diffX0+i*(diffW+diffGap),y,diffX0+i*(diffW+diffGap)+diffW,y+diffH);

        backBtn.set(W*0.025f,H*0.035f,W*0.15f,H*0.11f);
        againBtn.set(W*0.30f,H*0.61f,W*0.49f,H*0.71f);
        menuBtn.set(W*0.51f,H*0.61f,W*0.70f,H*0.71f);

        int cols=3, rows=5;
        float left=W*0.08f, right=W*0.92f, top=H*0.20f, bottom=H*0.91f;
        float gapX=W*0.018f, gapY=H*0.018f;
        float cellW=(right-left-gapX*(cols-1))/cols;
        float cellH=(bottom-top-gapY*(rows-1))/rows;
        for(int i=0;i<itemRects.length;i++) {
            int row=i/cols, col=i%cols;
            float x=left+col*(cellW+gapX), yy=top+row*(cellH+gapY);
            itemRects[i].set(x,yy,x+cellW,yy+cellH);
        }

        int accCols=4;
        float accLeft=W*0.08f,accRight=W*0.92f,accTop=H*0.25f,accBottom=H*0.82f;
        float accGapX=W*0.018f,accGapY=H*0.035f;
        float accW=(accRight-accLeft-accGapX*(accCols-1))/accCols;
        float accH=(accBottom-accTop-accGapY)/2f;
        for(int i=0;i<accessoryRects.length;i++){
            int row=i/accCols,col=i%accCols;float ax=accLeft+col*(accW+accGapX),ay=accTop+row*(accH+accGapY);
            accessoryRects[i].set(ax,ay,ax+accW,ay+accH);
        }

        joySideBtn.set(W*0.07f,H*0.245f,W*0.34f,H*0.318f);
        joySizeBtn.set(W*0.07f,H*0.335f,W*0.34f,H*0.408f);
        joySensitivityBtn.set(W*0.07f,H*0.425f,W*0.34f,H*0.498f);
        joyStyleBtn.set(W*0.07f,H*0.515f,W*0.34f,H*0.588f);
        qualityBtn.set(W*0.07f,H*0.605f,W*0.34f,H*0.678f);
        resetSettingsBtn.set(W*0.07f,H*0.695f,W*0.34f,H*0.768f);
        creatorCodePanel.set(W*0.07f,H*0.795f,W*0.34f,H*0.905f);

        float adminLeft=W*0.16f, adminRight=W*0.84f, adminGap=W*0.025f;
        float adminCellW=(adminRight-adminLeft-adminGap)*0.5f, adminCellH=H*0.115f;
        float adminTop=H*0.27f, adminGapY=H*0.025f;
        for(int i=0;i<6;i++){int row=i/2,col=i%2;float ax=adminLeft+col*(adminCellW+adminGap);float ay=adminTop+row*(adminCellH+adminGapY);adminActionBtns[i].set(ax,ay,ax+adminCellW,ay+adminCellH);}
        adminActionBtns[6].set(W*0.29f,H*0.72f,W*0.71f,H*0.825f);

        float sy=H*0.23f, sh=H*0.085f, sg=H*0.012f;
        for(int i=0;i<colorSettingRects.length;i++) {
            colorSettingRects[i].set(W*0.43f,sy+i*(sh+sg),W*0.91f,sy+i*(sh+sg)+sh);
        }
    }

    public void resume() {
        if (running) return;
        running=true; lastNs=System.nanoTime(); accumulatorNs=0L; postOnAnimation(this);
    }

    public void pause() {
        running=false; removeCallbacks(this);
    }

    @Override public void run() {
        if (!running) return;
        long now=System.nanoTime();
        processOnlineEvents();
        if (screen != Screen.BATTLE) {
            lastNs=now; accumulatorNs=0L; invalidate(); postDelayed(this,120); return;
        }
        long elapsed=Math.min(50_000_000L,Math.max(0L,now-lastNs));
        lastNs=now; accumulatorNs+=elapsed;
        int steps=0;
        while(accumulatorNs>=UPDATE_STEP_NS && steps<3){
            update(UPDATE_STEP_NS/1_000_000_000f);
            accumulatorNs-=UPDATE_STEP_NS; steps++;
        }
        if(steps>0)invalidate();
        postOnAnimation(this);
    }

    private void startBattle() {
        screen=Screen.BATTLE;
        playerScore=0; botScore=0; matchOver=false; rewardGranted=false; lastReward=0;
        startRound();
        lastNs=System.nanoTime(); accumulatorNs=0L;
        invalidate();
    }

    private void startRound() {
        if(W<=0||H<=0)return;
        float r=Math.max(26f,Math.min(W,H)*0.048f);
        player=new Fighter(false); bot=new Fighter(true);
        player.radius=bot.radius=r;
        player.x=W*0.24f; player.y=groundY-r*1.1f;
        bot.x=W*0.76f; bot.y=groundY-r*1.1f;
        player.facing=1; bot.facing=-1;
        if(gameMode==GameMode.ONLINE){
            player.ability=Ability.values()[clampInt(onlineAbility0,0,Ability.values().length-1)];
            bot.ability=Ability.values()[clampInt(onlineAbility1,0,Ability.values().length-1)];
            player.accessory=Accessory.values()[clampInt(onlineAccessory0,0,Accessory.values().length-1)];
            bot.accessory=Accessory.values()[clampInt(onlineAccessory1,0,Accessory.values().length-1)];
        }else{
            player.ability=selectedAbility;
            bot.ability=gameMode==GameMode.TWO_PLAYER?selectedAbility:randomBotAbility();
            player.accessory=selectedAccessory;
            bot.accessory=gameMode==GameMode.TWO_PLAYER?selectedAccessory:Accessory.NONE;
        }
        shots.clear(); particles.clear(); beams.clear();
        roundOver=false; roundResetTimer=0f; botBrainTimer=0f; onlineResultSent=false;
        remoteJoyX=remoteJoyY=0f; remoteJumpCharge=0f; remoteJumpLatched=false;
        jumpCharge=0f; jumpLatched=false; jump2Charge=0f; jump2Latched=false; resetJoystick(); resetJoystick2();
    }

    private Ability randomBotAbility() {
        int cap = difficulty==Difficulty.EASY ? 5 : difficulty==Difficulty.MEDIUM ? 10 : Ability.values().length;
        return Ability.values()[rng.nextInt(cap)];
    }

    private void update(float dt) {
        if(player==null||bot==null)return;
        updateParticles(dt); updateBeams(dt);
        cameraShakeTimer=Math.max(0f,cameraShakeTimer-dt);
        hitFlashTimer=Math.max(0f,hitFlashTimer-dt);
        player.landingSquash=Math.max(0f,player.landingSquash-dt*4.5f);
        bot.landingSquash=Math.max(0f,bot.landingSquash-dt*4.5f);
        if(matchOver)return;
        if(hitStopTimer>0f){hitStopTimer=Math.max(0f,hitStopTimer-dt);return;}

        updateCooldowns(player,dt); updateCooldowns(bot,dt);
        if(gameMode==GameMode.ONLINE){
            if(onlineLocalIndex==0){ updateHumanOne(dt); updateRemoteOnline(bot,1,dt); }
            else { updateRemoteOnline(player,0,dt); updateHumanOnlineSecond(dt); }
        }else{
            updateHumanOne(dt);
            if(gameMode==GameMode.TWO_PLAYER) updateHumanTwo(dt);
            else if(creatorMode&&adminFreezeBot){bot.vx*=0.82f;}
            else updateBot(dt);
        }

        physics(player,dt); physics(bot,dt);
        resolveFighterCollision(); updateShots(dt);
        if(gameMode==GameMode.ONLINE){
            onlineInputTimer+=dt; onlineSnapshotTimer+=dt;
            if(onlineInputTimer>=0.05f){onlineInputTimer=0f;sendOnlineInput();}
            if(onlineLocalIndex==0&&onlineSnapshotTimer>=0.10f){onlineSnapshotTimer=0f;sendOnlineSnapshot();}
            if(onlineLocalIndex==0&&(player.hp<=0||bot.hp<=0)){endRound();sendOnlineResult();}
        }else if(player.hp<=0||bot.hp<=0)endRound();
    }

    private void updateHumanOne(float dt){
        float slowFactor=player.slowTimer>0?0.58f:1f;
        float dead=0.12f;
        float move=Math.abs(joyX)>dead?joyX:0f;
        float accel=W*1.35f*slowFactor;
        if(move!=0f){
            player.vx+=move*accel*dt;
            if(Math.abs(joyX)>0.18f)player.facing=joyX>=0?1:-1;
        } else player.vx*=Math.max(0f,1f-6.2f*dt);

        float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY);
        if(mag>0.22f){
            aimX=joyX/mag; aimY=joyY/mag;
            if(Math.abs(aimX)>0.16f)player.facing=aimX>=0?1:-1;
            if(player.attackCd<=0f)attack(player,0,aimX,aimY);
        }

        boolean chargingJump=joyY<-0.68f&&mag>0.72f;
        if(chargingJump&&player.grounded&&!jumpLatched){
            jumpCharge+=dt;
            if(jumpCharge>=0.50f){
                player.vy=-jumpVelocity(); player.grounded=false; jumpCharge=0f; jumpLatched=true;
                burst(player.x,player.y+player.radius,Color.rgb(100,210,255),8,0.5f);
            }
        } else if(!chargingJump){ jumpCharge=0f; jumpLatched=false; }
    }

    private void updateHumanTwo(float dt){
        float slowFactor=bot.slowTimer>0?0.58f:1f;
        float dead=0.12f;
        float move=Math.abs(joy2X)>dead?joy2X:0f;
        float accel=W*1.35f*slowFactor;
        if(move!=0f){
            bot.vx+=move*accel*dt;
            if(Math.abs(joy2X)>0.18f)bot.facing=joy2X>=0?1:-1;
        } else bot.vx*=Math.max(0f,1f-6.2f*dt);

        float mag=(float)Math.sqrt(joy2X*joy2X+joy2Y*joy2Y);
        if(mag>0.22f){
            aim2X=joy2X/mag; aim2Y=joy2Y/mag;
            if(Math.abs(aim2X)>0.16f)bot.facing=aim2X>=0?1:-1;
            if(bot.attackCd<=0f)attack(bot,1,aim2X,aim2Y);
        }

        boolean chargingJump=joy2Y<-0.68f&&mag>0.72f;
        if(chargingJump&&bot.grounded&&!jump2Latched){
            jump2Charge+=dt;
            if(jump2Charge>=0.50f){
                bot.vy=-jumpVelocity(); bot.grounded=false; jump2Charge=0f; jump2Latched=true;
                burst(bot.x,bot.y+bot.radius,Color.rgb(255,120,150),8,0.5f);
            }
        } else if(!chargingJump){ jump2Charge=0f; jump2Latched=false; }
    }

    private void updateHumanOnlineSecond(float dt){
        Fighter f=bot;
        float slowFactor=f.slowTimer>0?0.58f:1f, dead=0.12f;
        float move=Math.abs(joyX)>dead?joyX:0f;
        float accel=W*1.35f*slowFactor;
        if(move!=0f){f.vx+=move*accel*dt;if(Math.abs(joyX)>0.18f)f.facing=joyX>=0?1:-1;}
        else f.vx*=Math.max(0f,1f-6.2f*dt);
        float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY);
        if(mag>0.22f){aimX=joyX/mag;aimY=joyY/mag;if(Math.abs(aimX)>0.16f)f.facing=aimX>=0?1:-1;if(f.attackCd<=0f)attack(f,1,aimX,aimY);}
        boolean chargingJump=joyY<-0.68f&&mag>0.72f;
        if(chargingJump&&f.grounded&&!jumpLatched){jumpCharge+=dt;if(jumpCharge>=0.50f){f.vy=-jumpVelocity();f.grounded=false;jumpCharge=0f;jumpLatched=true;burst(f.x,f.y+f.radius,colorAt(botColorIdx),8,0.5f);}}
        else if(!chargingJump){jumpCharge=0f;jumpLatched=false;}
    }

    private void updateRemoteOnline(Fighter f,int owner,float dt){
        float slowFactor=f.slowTimer>0?0.58f:1f, dead=0.12f;
        float move=Math.abs(remoteJoyX)>dead?remoteJoyX:0f;
        float accel=W*1.35f*slowFactor;
        if(move!=0f){f.vx+=move*accel*dt;if(Math.abs(remoteJoyX)>0.18f)f.facing=remoteJoyX>=0?1:-1;}
        else f.vx*=Math.max(0f,1f-6.2f*dt);
        float mag=(float)Math.sqrt(remoteJoyX*remoteJoyX+remoteJoyY*remoteJoyY);
        if(mag>0.22f){remoteAimX=remoteJoyX/mag;remoteAimY=remoteJoyY/mag;if(Math.abs(remoteAimX)>0.16f)f.facing=remoteAimX>=0?1:-1;if(f.attackCd<=0f)attack(f,owner,remoteAimX,remoteAimY);}
        boolean chargingJump=remoteJoyY<-0.68f&&mag>0.72f;
        if(chargingJump&&f.grounded&&!remoteJumpLatched){remoteJumpCharge+=dt;if(remoteJumpCharge>=0.50f){f.vy=-jumpVelocity();f.grounded=false;remoteJumpCharge=0f;remoteJumpLatched=true;}}
        else if(!chargingJump){remoteJumpCharge=0f;remoteJumpLatched=false;}
    }

    private float jumpVelocity(){
        return H*(arenaType==ArenaType.LOW_GRAV?0.70f:0.88f);
    }

    private void updateCooldowns(Fighter f,float dt){
        float attackDt = dt;
        // Creator combat advantages are intentionally disabled in local 2-player mode.
        if (creatorMode && gameMode==GameMode.SOLO && f==player) attackDt *= adminTurboCooldown?3.25f:1.20f;
        f.attackCd=Math.max(0,f.attackCd-attackDt); f.shield=Math.max(0,f.shield-dt);
        f.invuln=Math.max(0,f.invuln-dt); f.slowTimer=Math.max(0,f.slowTimer-dt);
    }

    private void physics(Fighter f,float dt){
        float gravityScale=arenaType==ArenaType.LOW_GRAV?0.52f:1f;
        boolean wasGrounded=f.grounded;
        f.vy+=H*2.12f*gravityScale*dt;
        float speedCap=W*(f.slowTimer>0?0.31f:0.50f);
        f.vx=clamp(f.vx,-speedCap,speedCap);
        f.x+=f.vx*dt; f.y+=f.vy*dt;
        float r=f.radius;
        float floor=floorAt(f.x);
        if(floor<=H+20f && f.y+r*1.10f>=floor && f.vy>=-H*0.08f){
            float impact=f.vy; f.y=floor-r*1.10f;
            if(arenaType==ArenaType.BOUNCE && impact>H*0.26f){
                f.vy=-impact*0.60f; f.grounded=false;
            }else{
                if(f.vy>0)f.vy=0; f.grounded=true;
                if(!wasGrounded&&impact>H*0.30f)f.landingSquash=1f;
            }
        }else f.grounded=false;
        float drag=f.grounded?Math.max(0f,1f-1.45f*dt):Math.max(0f,1f-0.34f*dt);
        f.vx*=drag;
        if(f.x-r<0){f.x=r;f.vx=Math.abs(f.vx)*0.24f;}
        if(f.x+r>W){f.x=W-r;f.vx=-Math.abs(f.vx)*0.24f;}
        if(f.y>H+r*3.0f)f.hp=0f;
    }

    private float floorAt(float x){
        if(arenaType==ArenaType.SPLIT && x>W*0.43f && x<W*0.57f) return H+240f;
        return groundY;
    }

    private void resolveFighterCollision(){
        float dx=bot.x-player.x,dy=bot.y-player.y,dist2=dx*dx+dy*dy,min=player.radius+bot.radius;
        if(dist2>0.0001f&&dist2<min*min){
            float dist=(float)Math.sqrt(dist2),nx=dx/dist,ny=dy/dist,ov=min-dist;
            player.x-=nx*ov*0.50f;player.y-=ny*ov*0.18f;
            bot.x+=nx*ov*0.50f;bot.y+=ny*ov*0.18f;
            float rvx=bot.vx-player.vx,rvy=bot.vy-player.vy;
            float closing=rvx*nx+rvy*ny;
            if(closing<0f){float impulse=-closing*0.18f;player.vx-=nx*impulse;bot.vx+=nx*impulse;player.vy-=ny*impulse*0.35f;bot.vy+=ny*impulse*0.35f;}
        }
    }

    private void updateBot(float dt){
        botBrainTimer-=dt;
        if(botBrainTimer>0)return;
        float reaction=difficulty==Difficulty.EASY?0.28f:difficulty==Difficulty.MEDIUM?0.13f:0.055f;
        botBrainTimer=reaction*(0.8f+rng.nextFloat()*0.4f);

        float dx=player.x-bot.x,dy=player.y-bot.y,adx=Math.abs(dx);
        bot.facing=dx>=0?1:-1;
        boolean danger=false;
        for(Shot s:shots){
            if(s.owner==1)continue;
            float sx=s.x-bot.x,sy=s.y-bot.y;
            if(Math.abs(sy)<bot.radius*2.8f&&Math.abs(sx)<W*0.24f){danger=true;break;}
        }

        float dodgeChance=difficulty==Difficulty.EASY?0.10f:difficulty==Difficulty.MEDIUM?0.36f:0.78f;
        if(danger&&bot.grounded&&rng.nextFloat()<dodgeChance)bot.vy=-H*(difficulty==Difficulty.HARD?0.88f:0.78f);

        float movePower=difficulty==Difficulty.EASY?0.65f:difficulty==Difficulty.MEDIUM?0.92f:1.18f;
        float desiredMin=W*(difficulty==Difficulty.HARD?0.16f:0.19f), desiredMax=W*0.34f;
        if(arenaType==ArenaType.SPLIT){float nextX=bot.x+Math.signum(dx)*bot.radius*2.4f;if(floorAt(nextX)>H+20f){bot.vx-=Math.signum(dx)*W*0.22f;if(bot.grounded&&difficulty!=Difficulty.EASY)bot.vy=-H*0.72f;}}
        float slow=bot.slowTimer>0?0.58f:1f;
        if(adx>desiredMax)bot.vx+=Math.signum(dx)*W*movePower*slow*reaction;
        else if(adx<desiredMin)bot.vx-=Math.signum(dx)*W*movePower*0.85f*slow*reaction;
        else bot.vx*=0.72f;

        if(bot.attackCd<=0f){
            if(rng.nextFloat()<(difficulty==Difficulty.EASY?0.50f:difficulty==Difficulty.MEDIUM?0.80f:0.98f)){
                if(difficulty==Difficulty.HARD&&danger&&rng.nextFloat()<0.30f)bot.ability=Ability.SHIELD_PULSE;
                else if(rng.nextFloat()<0.22f)bot.ability=randomBotAbility();
                float len=(float)Math.sqrt(dx*dx+dy*dy);if(len<1)len=1;
                float ax=dx/len,ay=dy/len;
                float err=difficulty==Difficulty.EASY?0.20f:difficulty==Difficulty.MEDIUM?0.075f:0.022f;
                float angle=(float)Math.atan2(ay,ax)+(rng.nextFloat()*2f-1f)*err;
                attack(bot,1,(float)Math.cos(angle),(float)Math.sin(angle));
            }
        }
        if(bot.grounded&&adx<W*0.22f&&rng.nextFloat()<(difficulty==Difficulty.HARD?0.16f:0.05f))bot.vy=-H*0.75f;
    }

    private void attack(Fighter f,int owner,float ax,float ay){
        if(f.attackCd>0||roundOver)return;
        playWeaponSound(f.ability);
        Fighter target=owner==0?bot:player;
        float len=(float)Math.sqrt(ax*ax+ay*ay);if(len<0.001f){ax=f.facing;ay=0;len=1;}ax/=len;ay/=len;
        if(Math.abs(ax)>0.12f)f.facing=ax>=0?1:-1;
        float baseSpeed=W*0.64f, sx=f.x+ax*f.radius*1.35f, sy=f.y+ay*f.radius*0.9f-f.radius*0.12f;
        int fx=abilityColor(f.ability,owner);

        switch(f.ability){
            case ENERGY_ORB:{
                addShot(new Shot(sx,sy,ax*baseSpeed,ay*baseSpeed,f.radius*0.31f,11,0.28f,2.25f,owner,f.ability));
                f.attackCd=0.42f;break;
            }
            case BOUNCE_DISC:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.80f,ay*baseSpeed*0.80f,f.radius*0.39f,10,0.36f,3.2f,owner,f.ability);
                s.bounces=4;s.gravity=true;addShot(s);f.attackCd=0.50f;break;
            }
            case HEAVY_GLOVE:{
                float reach=f.radius*2.75f;float tx=target.x-f.x,ty=target.y-f.y,tlen=(float)Math.sqrt(tx*tx+ty*ty);if(tlen<1)tlen=1;
                float dot=(tx/tlen)*ax+(ty/tlen)*ay;
                if(tlen<reach&&dot>0.35f)damage(target,21,ax*W*0.40f,ay*H*0.18f-H*0.09f,fx);
                beams.add(new BeamFx(f.x,f.y,f.x+ax*reach,f.y+ay*reach,0.11f,f.radius*0.22f,fx,f.ability));
                f.attackCd=0.80f;break;
            }
            case GRAVITY_BURST:{
                if(distance(f,target)<f.radius*4.2f){float d=Math.signum(target.x-f.x);if(d==0)d=1;damage(target,15,d*W*0.52f,-H*0.30f,fx);}
                burst(f.x,f.y,fx,18,0.75f);f.attackCd=1.00f;break;
            }
            case ARC_CORE:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.92f,ay*baseSpeed*0.92f,f.radius*0.30f,15,0.34f,2.3f,owner,f.ability);
                s.gravity=true;addShot(s);f.attackCd=0.58f;break;
            }
            case TRIPLE_SPARK:{
                float angle=(float)Math.atan2(ay,ax);
                for(int i=-1;i<=1;i++){float a=angle+i*0.14f,dx=(float)Math.cos(a),dy=(float)Math.sin(a);addShot(new Shot(f.x+dx*f.radius*1.3f,f.y+dy*f.radius*0.9f,dx*baseSpeed*0.86f,dy*baseSpeed*0.86f,f.radius*0.20f,6.5f,0.16f,1.9f,owner,f.ability));}
                f.attackCd=0.72f;break;
            }
            case SHIELD_PULSE:{
                f.shield=1.35f;f.attackCd=1.35f;burst(f.x,f.y,fx,14,0.55f);break;
            }
            case DASH_CORE:{
                f.vx=ax*W*0.70f;f.vy+=ay*H*0.32f;f.invuln=0.18f;
                if(distance(f,target)<f.radius*3.1f)damage(target,15,ax*W*0.46f,ay*H*0.20f-H*0.08f,fx);
                beams.add(new BeamFx(f.x-ax*f.radius*2f,f.y-ay*f.radius,f.x,f.y,0.15f,f.radius*0.18f,fx,f.ability));
                f.attackCd=0.86f;break;
            }
            case FROST_SHARD:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.74f,ay*baseSpeed*0.74f,f.radius*0.29f,10,0.18f,2.5f,owner,f.ability);
                s.frost=true;addShot(s);f.attackCd=0.62f;break;
            }
            case LASER_BEAM:{
                float tx=target.x-f.x,ty=target.y-f.y,tlen=(float)Math.sqrt(tx*tx+ty*ty);if(tlen<1)tlen=1;
                float dot=(tx/tlen)*ax+(ty/tlen)*ay;
                float beamLen=W*0.78f;
                beams.add(new BeamFx(sx,sy,sx+ax*beamLen,sy+ay*beamLen,0.13f,f.radius*0.16f,fx,f.ability));
                if(dot>0.94f&&tlen<beamLen)damage(target,17,ax*W*0.23f,ay*H*0.09f,fx);
                burst(sx,sy,fx,6,0.30f);f.attackCd=0.78f;break;
            }
            case MINE_CORE:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.42f,ay*baseSpeed*0.42f-H*0.08f,f.radius*0.40f,20,0.54f,5.6f,owner,f.ability);
                s.gravity=true;s.mine=true;s.armTimer=0.52f;addShot(s);f.attackCd=1.10f;break;
            }
            case RETURN_BLADE:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.78f,ay*baseSpeed*0.78f,f.radius*0.35f,12,0.27f,2.8f,owner,f.ability);
                s.returning=true;addShot(s);f.attackCd=0.65f;break;
            }
            case SKY_DROP:{
                float dropX=clamp(target.x+ax*target.radius*0.35f,target.radius,W-target.radius);
                Shot s=new Shot(dropX,-f.radius*2f,0,H*0.86f,f.radius*0.37f,19,0.42f,2.2f,owner,f.ability);
                addShot(s);f.attackCd=0.95f;break;
            }
            case VAMPIRE_BOLT:{
                Shot s=new Shot(sx,sy,ax*baseSpeed*0.68f,ay*baseSpeed*0.68f,f.radius*0.29f,10,0.18f,2.5f,owner,f.ability);
                s.healOnHit=true;addShot(s);f.attackCd=0.65f;break;
            }
            case BLINK_STRIKE:{
                float oldX=f.x,oldY=f.y;float dir=Math.abs(ax)>0.15f?Math.signum(ax):f.facing;
                f.x=clamp(target.x-dir*f.radius*1.6f,f.radius,W-f.radius);f.y=target.y;f.invuln=0.22f;
                beams.add(new BeamFx(oldX,oldY,f.x,f.y,0.16f,f.radius*0.18f,fx,f.ability));
                if(distance(f,target)<f.radius*2.4f)damage(target,17,dir*W*0.43f,-H*0.11f,fx);
                burst(oldX,oldY,fx,8,0.40f);burst(f.x,f.y,fx,10,0.50f);f.attackCd=1.00f;break;
            }
        }
        if(f.ability!=Ability.SHIELD_PULSE&&f.ability!=Ability.BLINK_STRIKE){f.vx-=ax*W*0.012f;}
    }

    private void addShot(Shot shot){if(shots.size()>=MAX_SHOTS)shots.remove(0);shots.add(shot);}

    private void updateShots(float dt){
        Iterator<Shot> it=shots.iterator();
        while(it.hasNext()){
            Shot s=it.next();s.life-=dt;
            if(s.returning&&!s.hasReturned&&s.life<s.maxLife*0.48f){s.vx*=-1f;s.vy*=-1f;s.hasReturned=true;}
            if(s.mine){
                s.armTimer-=dt;if(s.armTimer<=0)s.armed=true;
                if(!s.armed&&s.gravity)s.vy+=H*1.22f*dt;
                if(s.y+s.radius>=groundY){s.y=groundY-s.radius;s.vx*=0.45f;s.vy=0;s.gravity=false;}
            } else if(s.gravity)s.vy+=H*1.22f*dt;
            s.x+=s.vx*dt;s.y+=s.vy*dt;

            if(s.bounces>0){
                boolean bounced=false;
                if(s.x-s.radius<0||s.x+s.radius>W){s.vx*=-0.82f;s.x=clamp(s.x,s.radius,W-s.radius);bounced=true;}
                if(s.y+s.radius>groundY){s.vy=-Math.abs(s.vy)*0.72f;s.y=groundY-s.radius;bounced=true;}
                if(bounced){s.bounces--;burst(s.x,s.y,abilityColor(s.source,s.owner),4,0.28f);}
            }

            Fighter target=s.owner==0?bot:player;
            float dx=s.x-target.x,dy=s.y-target.y;
            float hitR=s.radius+target.radius;
            boolean hit=dx*dx+dy*dy<hitR*hitR;
            if(s.mine&&s.armed){
                float trigger=target.radius*2.7f+s.radius;
                hit=dx*dx+dy*dy<trigger*trigger;
            }
            if(hit){
                float speed=(float)Math.sqrt(s.vx*s.vx+s.vy*s.vy);if(speed<1)speed=1;
                float nx=s.vx/speed,ny=s.vy/speed;if(s.mine){nx=Math.signum(target.x-s.x);ny=-0.6f;}
                int fx=abilityColor(s.source,s.owner);
                damage(target,s.damage,nx*W*s.knockback,ny*H*0.18f-H*0.06f,fx);
                if(s.frost)target.slowTimer=Math.max(target.slowTimer,1.65f);
                if(s.healOnHit){Fighter shooter=s.owner==0?player:bot;shooter.hp=Math.min(100f,shooter.hp+7f);}
                if(s.mine)burst(s.x,s.y,fx,18,0.85f);
                it.remove();continue;
            }
            if(s.life<=0||s.x<-140||s.x>W+140||s.y<-220||s.y>H+180)it.remove();
        }
    }

    private void damage(Fighter target,float amount,float kbX,float kbY,int fxColor){
        if(target.invuln>0)return;
        float factor=target.shield>0?0.28f:1f;
        if(creatorMode&&gameMode==GameMode.SOLO){
            if(target==player){factor*=0.82f;if(adminGodMode)amount=0f;}
            else if(target==bot&&adminDoubleDamage)amount*=2f;
        }
        target.hp-=amount*factor;
        float launch=0.88f+(100f-clamp(target.hp,0f,100f))*0.0068f;
        float kbFactor=adminGodMode&&target==player?0.45f:factor;
        target.vx+=kbX*kbFactor*launch;target.vy+=kbY*kbFactor*launch;target.invuln=0.075f;
        hitStopTimer=Math.max(hitStopTimer,amount>=18f?0.045f:0.022f);
        cameraShakeTimer=Math.max(cameraShakeTimer,amount>=18f?0.16f:0.09f);
        cameraShakePower=Math.max(cameraShakePower,Math.min(H*0.012f,amount*H*0.00045f));
        hitFlashTimer=Math.max(hitFlashTimer,0.07f);
        burst(target.x,target.y,fxColor,graphicsQuality==0?6:graphicsQuality==1?10:14,0.5f);
    }

    private void burst(float x,float y,int color,int count,float speedScale){
        int limit=graphicsQuality==0?55:graphicsQuality==1?100:MAX_PARTICLES;
        int room=Math.max(0,limit-particles.size());count=Math.min(count,room);
        for(int i=0;i<count;i++){float a=rng.nextFloat()*(float)Math.PI*2f;float sp=(0.25f+rng.nextFloat()*0.75f)*Math.min(W,H)*speedScale;particles.add(new Particle(x,y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp,0.20f+rng.nextFloat()*0.22f,2f+rng.nextFloat()*4.5f,color));}
    }

    private void updateParticles(float dt){
        Iterator<Particle>it=particles.iterator();
        while(it.hasNext()){
            Particle p=it.next();p.life-=dt;p.vx*=Math.max(0f,1f-7f*dt);p.vy*=Math.max(0f,1f-6f*dt);p.x+=p.vx*dt;p.y+=p.vy*dt;
            if(p.life<=0)it.remove();
        }
    }

    private void updateBeams(float dt){
        Iterator<BeamFx> it=beams.iterator();
        while(it.hasNext()){BeamFx b=it.next();b.life-=dt;if(b.life<=0)it.remove();}
    }

    private void startOnlineHost(){
        closeOnline(false);
        onlineHostIp=OnlinePeer.localIpv4Address();
        onlineHostIpv6=OnlinePeer.globalIpv6Address();
        onlineRoomCode=OnlinePeer.newRoomCode();
        onlineStatus="СЕРВЕР ЗАПУЩЕН • ЖДУ ИГРОКА";
        onlineHosting=true;
        onlinePeer.startHost(OnlinePeer.DEFAULT_PORT,onlineRoomCode);
        GameHostService.start(getContext(),"Комната "+onlineRoomCode+" • порт "+OnlinePeer.DEFAULT_PORT);
        invalidate();
    }

    private void showOnlineJoinDialog(){
        Context ctx=getContext();
        if(!(ctx instanceof Activity)){onlineStatus="НЕ УДАЛОСЬ ОТКРЫТЬ ПОДКЛЮЧЕНИЕ";return;}
        new AlertDialog.Builder(ctx)
                .setTitle("Подключение к онлайн-бою")
                .setMessage("Можно подключиться без IP через поиск комнат в одной Wi-Fi сети или ввести адрес вручную для интернета/туннеля.")
                .setPositiveButton("НАЙТИ В WI-FI",(d,w)->discoverOnlineRooms())
                .setNeutralButton("ВРУЧНУЮ",(d,w)->showManualOnlineJoinDialog())
                .setNegativeButton("ОТМЕНА",null)
                .show();
    }

    private void showManualOnlineJoinDialog(){
        Context ctx=getContext();
        if(!(ctx instanceof Activity)){onlineStatus="НЕ УДАЛОСЬ ОТКРЫТЬ ПОДКЛЮЧЕНИЕ";return;}

        LinearLayout box=new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(18f*getResources().getDisplayMetrics().density);
        box.setPadding(pad,0,pad,0);

        final EditText hostInput=new EditText(ctx);
        hostInput.setSingleLine(true);
        hostInput.setHint("IP, IPv6 или домен сервера");
        hostInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        box.addView(hostInput);

        final EditText codeInput=new EditText(ctx);
        codeInput.setSingleLine(true);
        codeInput.setHint("Код комнаты, например 482731");
        codeInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        box.addView(codeInput);

        new AlertDialog.Builder(ctx)
                .setTitle("Подключиться вручную")
                .setMessage("Для игры через интернет укажи домен туннеля/сервер, а для LAN можно использовать обычный IP.")
                .setView(box)
                .setPositiveButton("ПОДКЛЮЧИТЬСЯ",(d,w)->{
                    String host=hostInput.getText().toString().trim();
                    String code=codeInput.getText().toString().trim();
                    if(host.isEmpty()){onlineStatus="ВВЕДИ АДРЕС СЕРВЕРА";invalidate();return;}
                    if(code.isEmpty()){onlineStatus="ВВЕДИ КОД КОМНАТЫ";invalidate();return;}
                    joinOnlineHost(host, code);
                })
                .setNegativeButton("ОТМЕНА",null).show();
    }

    private void discoverOnlineRooms(){
        Context ctx=getContext();
        if(!(ctx instanceof Activity)){onlineStatus="НЕ УДАЛОСЬ НАЙТИ КОМНАТЫ";return;}
        Activity act=(Activity)ctx;
        onlineStatus="ПОИСК КОМНАТ В WI-FI...";
        invalidate();
        new Thread(() -> {
            final java.util.List<OnlinePeer.DiscoveredRoom> rooms = OnlinePeer.discoverLan(1400);
            new Handler(Looper.getMainLooper()).post(() -> showDiscoveredRooms(act, rooms));
        }, "sca-discover-ui").start();
    }

    private void showDiscoveredRooms(Activity act, java.util.List<OnlinePeer.DiscoveredRoom> rooms){
        if(rooms==null||rooms.isEmpty()){
            onlineStatus="КОМНАТЫ НЕ НАЙДЕНЫ • МОЖНО ПОДКЛЮЧИТЬСЯ ВРУЧНУЮ";
            invalidate();
            new AlertDialog.Builder(act)
                    .setTitle("Комнаты не найдены")
                    .setMessage("В этой Wi-Fi сети комнаты не найдены. Можно попробовать ещё раз или подключиться вручную.")
                    .setPositiveButton("ВРУЧНУЮ", (d,w) -> showManualOnlineJoinDialog())
                    .setNegativeButton("ОК", null)
                    .show();
            return;
        }
        String[] items = new String[rooms.size()];
        for(int i=0;i<rooms.size();i++) items[i]=rooms.get(i).toString();
        onlineStatus="НАЙДЕНО КОМНАТ: "+rooms.size();
        invalidate();
        new AlertDialog.Builder(act)
                .setTitle("Найденные комнаты")
                .setItems(items, (d,which) -> {
                    OnlinePeer.DiscoveredRoom room = rooms.get(which);
                    joinOnlineHost(room.host, room.code);
                })
                .setNeutralButton("ВРУЧНУЮ", (d,w) -> showManualOnlineJoinDialog())
                .setNegativeButton("ОТМЕНА", null)
                .show();
    }

    private void joinOnlineHost(String host, String code){
        closeOnline(false);onlineHosting=false;onlineStatus="ПОДКЛЮЧЕНИЕ К "+host;
        onlinePeer.join(host,OnlinePeer.DEFAULT_PORT,code);invalidate();
    }

    private void closeOnline(boolean returnHome){
        if(onlinePeer!=null)onlinePeer.close();
        if(onlineHosting) GameHostService.stop(getContext());
        onlineStatus="НЕ ПОДКЛЮЧЕНО";onlineHosting=false;onlineLocalIndex=-1;
        onlineRoomCode="------";
        remoteJoyX=remoteJoyY=0f;onlineInputTimer=onlineSnapshotTimer=0f;
        onlineEvents.clear();
        if(returnHome){gameMode=GameMode.SOLO;screen=Screen.HOME;applyJoystickLayout();}
    }

    private void processOnlineEvents(){
        String ev;int guard=0;
        while((ev=onlineEvents.poll())!=null&&guard++<80){
            if(ev.startsWith("@status:")){onlineStatus=ev.substring(8);continue;}
            if(ev.startsWith("@connected:")){
                onlineLocalIndex=ev.endsWith("1")?0:1;
                onlineStatus="СОЕДИНЕНО • ОБМЕН ДАННЫМИ";
                sendOnlineHello();continue;
            }
            if(ev.startsWith("@disconnected:")){
                onlineStatus="ОТКЛЮЧЕНО • "+ev.substring(14);
                if(onlineHosting){GameHostService.stop(getContext());onlineHosting=false;}
                if(screen==Screen.BATTLE&&gameMode==GameMode.ONLINE){matchOver=true;roundOver=true;playerScore=botScore=0;}
                continue;
            }
            if(ev.startsWith("@msg:"))handleOnlineMessage(ev.substring(5));
        }
    }

    private void sendOnlineHello(){
        try{
            JSONObject j=new JSONObject();j.put("t","hello");j.put("ability",selectedAbility.ordinal());j.put("accessory",selectedAccessory.ordinal());j.put("arena",arenaType.ordinal());
            onlinePeer.send(j.toString());
        }catch(Exception ignored){}
    }

    private void handleOnlineMessage(String raw){
        try{
            JSONObject j=new JSONObject(raw);String t=j.optString("t","");
            if("hello".equals(t)){
                int remoteAbility=clampInt(j.optInt("ability",0),0,Ability.values().length-1);
                int remoteAccessory=clampInt(j.optInt("accessory",0),0,Accessory.values().length-1);
                if(onlineLocalIndex==0){
                    onlineAbility0=selectedAbility.ordinal();onlineAbility1=remoteAbility;
                    onlineAccessory0=selectedAccessory.ordinal();onlineAccessory1=remoteAccessory;
                    JSONObject setup=new JSONObject();setup.put("t","setup");setup.put("arena",arenaType.ordinal());setup.put("a0",onlineAbility0);setup.put("a1",onlineAbility1);setup.put("c0",onlineAccessory0);setup.put("c1",onlineAccessory1);
                    onlinePeer.send(setup.toString());
                    startOnlineBattle();
                }
            }else if("setup".equals(t)){
                arenaType=ArenaType.values()[clampInt(j.optInt("arena",0),0,ArenaType.values().length-1)];
                onlineAbility0=clampInt(j.optInt("a0",0),0,Ability.values().length-1);
                onlineAbility1=clampInt(j.optInt("a1",0),0,Ability.values().length-1);
                onlineAccessory0=clampInt(j.optInt("c0",0),0,Accessory.values().length-1);
                onlineAccessory1=clampInt(j.optInt("c1",0),0,Accessory.values().length-1);
                startOnlineBattle();
            }else if("input".equals(t)){
                remoteJoyX=clamp((float)j.optDouble("x",0),-1f,1f);remoteJoyY=clamp((float)j.optDouble("y",0),-1f,1f);
            }else if("state".equals(t)&&onlineLocalIndex==1){
                applyOnlineSnapshot(j);
            }else if("result".equals(t)&&onlineLocalIndex==1){
                if(player!=null&&bot!=null){player.hp=(float)j.optDouble("p0",player.hp);bot.hp=(float)j.optDouble("p1",bot.hp);endRound();}
            }
        }catch(Exception e){onlineStatus="ПАКЕТ СЕТИ ПОВРЕЖДЕН";}
    }

    private void startOnlineBattle(){
        if(W<=0||H<=0)return;
        gameMode=GameMode.ONLINE;screen=Screen.BATTLE;playerScore=botScore=0;matchOver=false;rewardGranted=true;lastReward=0;
        onlineInputTimer=onlineSnapshotTimer=0f;onlineResultSent=false;rebuildArenaBitmap((int)W,(int)H);applyJoystickLayout();startRound();
        lastNs=System.nanoTime();accumulatorNs=0L;onlineStatus="ОНЛАЙН БОЙ";invalidate();
    }

    private void sendOnlineInput(){
        if(onlinePeer==null||!onlinePeer.isConnected())return;
        try{JSONObject j=new JSONObject();j.put("t","input");j.put("x",joyX);j.put("y",joyY);onlinePeer.send(j.toString());}catch(Exception ignored){}
    }

    private JSONObject fighterToJson(Fighter f)throws Exception{
        JSONObject j=new JSONObject();j.put("x",f.x);j.put("y",f.y);j.put("vx",f.vx);j.put("vy",f.vy);j.put("hp",f.hp);j.put("cd",f.attackCd);
        j.put("sh",f.shield);j.put("iv",f.invuln);j.put("sl",f.slowTimer);j.put("g",f.grounded?1:0);j.put("f",f.facing);return j;
    }

    private void applyFighterJson(Fighter f,JSONObject j){
        float tx=(float)j.optDouble("x",f.x),ty=(float)j.optDouble("y",f.y);
        f.x=f.x+(tx-f.x)*0.62f;f.y=f.y+(ty-f.y)*0.62f;f.vx=(float)j.optDouble("vx",f.vx);f.vy=(float)j.optDouble("vy",f.vy);
        f.hp=(float)j.optDouble("hp",f.hp);f.attackCd=(float)j.optDouble("cd",f.attackCd);f.shield=(float)j.optDouble("sh",f.shield);
        f.invuln=(float)j.optDouble("iv",f.invuln);f.slowTimer=(float)j.optDouble("sl",f.slowTimer);f.grounded=j.optInt("g",f.grounded?1:0)==1;f.facing=j.optInt("f",f.facing);
    }

    private JSONObject shotToJson(Shot s)throws Exception{
        JSONObject j=new JSONObject();j.put("x",s.x);j.put("y",s.y);j.put("vx",s.vx);j.put("vy",s.vy);j.put("r",s.radius);j.put("d",s.damage);j.put("k",s.knockback);
        j.put("l",s.life);j.put("m",s.maxLife);j.put("o",s.owner);j.put("b",s.bounces);j.put("gr",s.gravity?1:0);j.put("fr",s.frost?1:0);j.put("he",s.healOnHit?1:0);
        j.put("mi",s.mine?1:0);j.put("ar",s.armed?1:0);j.put("at",s.armTimer);j.put("re",s.returning?1:0);j.put("hr",s.hasReturned?1:0);j.put("so",s.source==null?0:s.source.ordinal());return j;
    }

    private Shot jsonToShot(JSONObject j){
        Ability src=Ability.values()[clampInt(j.optInt("so",0),0,Ability.values().length-1)];
        Shot s=new Shot((float)j.optDouble("x",0),(float)j.optDouble("y",0),(float)j.optDouble("vx",0),(float)j.optDouble("vy",0),(float)j.optDouble("r",8),(float)j.optDouble("d",5),(float)j.optDouble("k",0),(float)j.optDouble("l",1),j.optInt("o",0),src);
        s.maxLife=(float)j.optDouble("m",s.life);s.bounces=j.optInt("b",0);s.gravity=j.optInt("gr",0)==1;s.frost=j.optInt("fr",0)==1;s.healOnHit=j.optInt("he",0)==1;
        s.mine=j.optInt("mi",0)==1;s.armed=j.optInt("ar",0)==1;s.armTimer=(float)j.optDouble("at",0);s.returning=j.optInt("re",0)==1;s.hasReturned=j.optInt("hr",0)==1;return s;
    }

    private void sendOnlineSnapshot(){
        if(onlinePeer==null||!onlinePeer.isConnected()||player==null||bot==null)return;
        try{
            JSONObject j=new JSONObject();j.put("t","state");j.put("p0",fighterToJson(player));j.put("p1",fighterToJson(bot));JSONArray a=new JSONArray();
            int count=Math.min(shots.size(),40);for(int i=0;i<count;i++)a.put(shotToJson(shots.get(i)));j.put("shots",a);onlinePeer.send(j.toString());
        }catch(Exception ignored){}
    }

    private void applyOnlineSnapshot(JSONObject j){
        if(player==null||bot==null)return;
        JSONObject p0=j.optJSONObject("p0"),p1=j.optJSONObject("p1");if(p0!=null)applyFighterJson(player,p0);if(p1!=null)applyFighterJson(bot,p1);
        JSONArray a=j.optJSONArray("shots");if(a!=null){shots.clear();for(int i=0;i<a.length()&&i<MAX_SHOTS;i++){JSONObject sj=a.optJSONObject(i);if(sj!=null)shots.add(jsonToShot(sj));}}
    }

    private void sendOnlineResult(){
        if(onlineResultSent||onlinePeer==null||!onlinePeer.isConnected())return;onlineResultSent=true;
        try{JSONObject j=new JSONObject();j.put("t","result");j.put("p0",player.hp);j.put("p1",bot.hp);onlinePeer.send(j.toString());}catch(Exception ignored){}
    }

    private void endRound(){
        if(matchOver)return;
        roundOver=true;matchOver=true;
        playerScore=player.hp>0?1:0;
        botScore=bot.hp>0?1:0;
        if(gameMode==GameMode.SOLO&&!rewardGranted){
            if(playerScore>botScore){lastReward=difficulty.reward*(creatorMode?2:1);coins+=lastReward;totalWins++;totalCoinsEarned+=lastReward;}
            else {lastReward=0;totalLosses++;}
            rewardGranted=true;saveProgress();
        }else lastReward=0;
    }

    private static float distance(Fighter a,Fighter b){float dx=a.x-b.x,dy=a.y-b.y;return(float)Math.sqrt(dx*dx+dy*dy);}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private static int clampInt(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}

    private int safeColorIndex(int i){
        int n=COLOR_PALETTE.length;
        if(n==0)return 0;
        i%=n;if(i<0)i+=n;return i;
    }

    private int colorAt(int index){return COLOR_PALETTE[safeColorIndex(index)];}

    private static int withAlpha(int color,int alpha){
        return (color&0x00FFFFFF)|(clampInt(alpha,0,255)<<24);
    }

    private static int mixColor(int a,int b,float t){
        t=clamp(t,0f,1f);
        int aa=Color.alpha(a),ar=Color.red(a),ag=Color.green(a),ab=Color.blue(a);
        int ba=Color.alpha(b),br=Color.red(b),bg=Color.green(b),bb=Color.blue(b);
        return Color.argb((int)(aa+(ba-aa)*t),(int)(ar+(br-ar)*t),(int)(ag+(bg-ag)*t),(int)(ab+(bb-ab)*t));
    }

    private static int lighten(int color,float amount){return mixColor(color,Color.WHITE,amount);}
    private static int darken(int color,float amount){return mixColor(color,Color.BLACK,amount);}

    private void applyJoystickLayout(){
        if(W<=0||H<=0)return;
        float min=Math.min(W,H);
        float factor=joystickSize==0?0.86f:joystickSize==1?1.0f:1.17f;
        joyRadius=min*0.115f*factor;
        knobRadius=joyRadius*0.42f;
        joy2Radius=joyRadius; knob2Radius=knobRadius;
        if(gameMode==GameMode.TWO_PLAYER){
            joyCx=W*0.16f; joy2Cx=W*0.84f;
        }else{
            joyCx=joystickSide==0?W*0.16f:W*0.84f; joy2Cx=W*0.84f;
        }
        joyCy=H*0.80f; joy2Cy=H*0.80f;
        jumpArcRect.set(joyCx-joyRadius*1.12f,joyCy-joyRadius*1.12f,joyCx+joyRadius*1.12f,joyCy+joyRadius*1.12f);
        jump2ArcRect.set(joy2Cx-joy2Radius*1.12f,joy2Cy-joy2Radius*1.12f,joy2Cx+joy2Radius*1.12f,joy2Cy+joy2Radius*1.12f);
        resetJoystick(); resetJoystick2();
    }

    private void cycleColorSetting(int setting,int dir){
        if(setting==0){
            int n=safeColorIndex(uiColorIdx+dir);
            playerColorIdx=botColorIdx=uiColorIdx=joystickColorIdx=projectileColorIdx=arenaColorIdx=n;
        }else if(setting==1)playerColorIdx=safeColorIndex(playerColorIdx+dir);
        else if(setting==2)botColorIdx=safeColorIndex(botColorIdx+dir);
        else if(setting==3)uiColorIdx=safeColorIndex(uiColorIdx+dir);
        else if(setting==4)joystickColorIdx=safeColorIndex(joystickColorIdx+dir);
        else if(setting==5)projectileColorIdx=safeColorIndex(projectileColorIdx+dir);
        else if(setting==6)arenaColorIdx=safeColorIndex(arenaColorIdx+dir);
    }

    private void resetVisualSettings(){
        playerColorIdx=0;botColorIdx=1;uiColorIdx=0;joystickColorIdx=0;projectileColorIdx=6;arenaColorIdx=4;
        joystickSide=1;joystickSize=1;joystickSensitivity=1;joystickStyle=0;graphicsQuality=1;
        applyJoystickLayout();
    }

    private int abilityColor(Ability a,int owner){
        int base;
        switch(a){
            case ENERGY_ORB:base=Color.rgb(80,200,255);break;
            case BOUNCE_DISC:base=Color.rgb(255,205,70);break;
            case HEAVY_GLOVE:base=Color.rgb(255,120,70);break;
            case GRAVITY_BURST:base=Color.rgb(170,105,255);break;
            case ARC_CORE:base=Color.rgb(255,165,70);break;
            case TRIPLE_SPARK:base=Color.rgb(220,120,255);break;
            case SHIELD_PULSE:base=Color.rgb(85,225,235);break;
            case DASH_CORE:base=Color.rgb(105,240,145);break;
            case FROST_SHARD:base=Color.rgb(165,240,255);break;
            case LASER_BEAM:base=Color.rgb(255,90,110);break;
            case MINE_CORE:base=Color.rgb(255,190,65);break;
            case RETURN_BLADE:base=Color.rgb(110,235,200);break;
            case SKY_DROP:base=Color.rgb(255,230,120);break;
            case VAMPIRE_BOLT:base=Color.rgb(215,90,175);break;
            case BLINK_STRIKE:base=Color.rgb(145,105,255);break;
            default:base=Color.WHITE;
        }
        if(owner==0)return mixColor(base,colorAt(projectileColorIdx),0.52f);
        return mixColor(base,colorAt(botColorIdx),0.32f);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); if(W<=0||H<=0)return;
        if(screen==Screen.BATTLE){
            c.save();
            if(cameraShakeTimer>0f){double t=System.nanoTime()*0.000000045;float fade=clamp(cameraShakeTimer/0.16f,0f,1f);c.translate((float)Math.sin(t)*cameraShakePower*fade,(float)Math.cos(t*1.37)*cameraShakePower*0.55f*fade);}
            drawArena(c);drawBattle(c);c.restore();
            if(hitFlashTimer>0f){paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(Color.WHITE,(int)(45f*clamp(hitFlashTimer/0.07f,0f,1f))));c.drawRect(0,0,W,H,paint);}
            return;
        }
        drawArena(c);
        if(screen==Screen.HOME)drawHome(c);
        else if(screen==Screen.ONLINE)drawOnline(c);
        else if(screen==Screen.ARMORY)drawArmory(c,false);
        else if(screen==Screen.SHOP)drawArmory(c,true);
        else if(screen==Screen.ACCESSORIES)drawAccessories(c);
        else if(screen==Screen.SETTINGS)drawSettings(c);
        else if(screen==Screen.ADMIN)drawAdmin(c);
    }

    private void drawHome(Canvas c){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.03f,H*0.03f,W*0.97f,H*0.95f,mixColor(0xF1081121,ui,0.10f),34f);

        // header inspired by arcade duel menus, but with original layout and art
        drawPanel(c,W*0.06f,H*0.055f,W*0.94f,H*0.23f,mixColor(0xE2162742,ui,0.24f),28f);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(2f,H*0.004f)); paint.setColor(withAlpha(lighten(ui,0.45f),160));
        c.drawRoundRect(W*0.06f,H*0.055f,W*0.94f,H*0.23f,28f,28f,paint); paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setColor(Color.WHITE);
        paint.setTextSize(H*0.060f); c.drawText("STICK CLASH",W*0.50f,H*0.120f,paint);
        paint.setTextSize(H*0.034f); paint.setColor(lighten(ui,0.50f)); c.drawText("ARENA",W*0.50f,H*0.165f,paint);
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(H*0.018f); paint.setColor(Color.rgb(182,208,232));
        c.drawText("ARCADE MENU • QUICK DUEL • STYLE",W*0.50f,H*0.202f,paint);

        // duel preview block
        float previewTop=H*0.255f, previewBottom=H*0.385f;
        drawPanel(c,W*0.08f,previewTop,W*0.92f,previewBottom,mixColor(0xC615223A,ui,0.18f),24f);
        drawWeaponIcon(c,selectedAbility,W*0.17f,H*0.32f,H*0.040f,abilityColor(selectedAbility,0));
        drawAccessoryIcon(c,selectedAccessory,W*0.83f,H*0.32f,H*0.040f,lighten(colorAt(playerColorIdx),0.42f));
        paint.setTextAlign(Paint.Align.LEFT); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(H*0.024f); paint.setColor(Color.WHITE);
        c.drawText(gameMode.title,W*0.24f,H*0.305f,paint);
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(H*0.018f); paint.setColor(Color.rgb(190,215,235));
        c.drawText("Арена: "+arenaType.title,W*0.24f,H*0.335f,paint);
        c.drawText("Оружие: "+selectedAbility.title,W*0.24f,H*0.363f,paint);
        paint.setTextAlign(Paint.Align.RIGHT); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setColor(Color.rgb(255,215,90)); paint.setTextSize(H*0.022f);
        c.drawText("Монеты: "+coins,W*0.78f,H*0.305f,paint);
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(H*0.017f); paint.setColor(lighten(ui,0.36f));
        c.drawText("Стиль: "+selectedAccessory.title,W*0.78f,H*0.335f,paint);
        if(creatorMode){paint.setColor(Color.rgb(255,215,90)); paint.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("★ CREATOR",W*0.78f,H*0.363f,paint);}

        if(gameMode==GameMode.SOLO){
            drawCenterText(c,"ВЫБЕРИ СЛОЖНОСТЬ",H*0.414f,H*0.020f,Color.rgb(205,220,238));
            Difficulty[] ds=Difficulty.values();
            for(int i=0;i<3;i++){
                boolean selected=ds[i]==difficulty;
                drawButton(c,difficultyBtns[i],ds[i].title,"+"+(ds[i].reward*(creatorMode?2:1))+" монет",selected?mixColor(Color.rgb(35,103,124),ui,0.34f):Color.rgb(29,45,69));
            }
        }else{
            drawCenterText(c,"ЛОКАЛЬНАЯ ДУЭЛЬ • 1 РАУНД",H*0.414f,H*0.024f,Color.rgb(220,232,245));
        }

        drawMenuCard(c,modeBtn,"РЕЖИМ",gameMode.title,mixColor(Color.rgb(31,71,104),ui,0.30f),"mode");
        drawMenuCard(c,arenaBtn,"АРЕНА",arenaType.title,mixColor(Color.rgb(50,58,105),ui,0.28f),"arena");
        drawMenuCard(c,armoryBtn,"ОРУЖИЕ",selectedAbility.title,mixColor(Color.rgb(35,76,108),ui,0.30f),"weapon");
        drawMenuCard(c,shopBtn,"МАГАЗИН","оружие и покупки",mixColor(Color.rgb(99,67,37),ui,0.18f),"shop");
        drawMenuCard(c,accessoriesBtn,"СТИЛЬ",selectedAccessory.title,mixColor(Color.rgb(94,47,100),ui,0.24f),"style");
        drawMenuCard(c,onlineBtn,"ОНЛАЙН","комнаты и сервер",mixColor(Color.rgb(28,94,143),ui,0.34f),"online");
        drawMenuCard(c,randomBtn,"СЛУЧАЙНО","выбрать оружие",mixColor(Color.rgb(78,53,118),ui,0.24f),"random");
        drawMenuCard(c,settingsBtn,"НАСТРОЙКИ","графика и управление",mixColor(Color.rgb(40,55,76),ui,0.34f),"settings");

        String sub=(gameMode==GameMode.SOLO?difficulty.title:gameMode.title)+" • "+arenaType.title;
        drawMenuCard(c,playBtn,"ИГРАТЬ",sub,mixColor(Color.rgb(24,145,94),ui,0.24f),"play");
    }

    private void drawOnline(Canvas c){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.08f,H*0.07f,W*0.92f,H*0.90f,mixColor(0xF00D1728,ui,0.11f),30f);
        drawButton(c,backBtn,"НАЗАД","",mixColor(Color.rgb(38,55,80),ui,0.18f));
        drawCenterText(c,"ОНЛАЙН • PHONE SERVER",H*0.18f,H*0.057f,Color.WHITE);
        drawCenterText(c,"Этот телефон может быть сервером матча",H*0.235f,H*0.023f,lighten(ui,0.35f));
        drawCenterText(c,"LAN работает сразу • интернет требует доступный адрес или туннель",H*0.278f,H*0.018f,Color.rgb(190,215,235));
        drawPanel(c,W*0.16f,H*0.315f,W*0.84f,H*0.475f,0xCC13213A,22f);
        drawCenterText(c,onlineStatus,H*0.352f,H*0.024f,Color.WHITE);
        drawCenterText(c,"IPv4: "+onlineHostIp+":"+OnlinePeer.DEFAULT_PORT,H*0.390f,H*0.018f,Color.rgb(115,220,255));
        drawCenterText(c,"IPv6: "+onlineHostIpv6,H*0.420f,H*0.016f,Color.rgb(150,205,255));
        drawCenterText(c,"КОД КОМНАТЫ: "+onlineRoomCode,H*0.455f,H*0.025f,Color.rgb(255,215,90));
        drawButton(c,onlineHostBtn,"ЗАПУСТИТЬ СЕРВЕР","создать комнату на этом телефоне",Color.rgb(35,118,91));
        drawButton(c,onlineJoinBtn,"ПОДКЛЮЧИТЬСЯ","автопоиск в Wi-Fi или вручную",Color.rgb(43,89,145));
        drawButton(c,onlineCancelBtn,"ОСТАНОВИТЬ","закрыть сервер/соединение",Color.rgb(92,50,62));
        drawCenterText(c,"Выбранная способность каждого игрока сохраняется",H*0.865f,H*0.018f,Color.rgb(175,195,218));
    }

    private void drawArmory(Canvas c,boolean shop){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.045f,H*0.035f,W*0.955f,H*0.96f,mixColor(0xF00D1728,ui,0.10f),28f);
        drawButton(c,backBtn,"НАЗАД","",mixColor(Color.rgb(38,55,80),ui,0.18f));
        drawCoinPill(c,W*0.80f,H*0.065f);
        drawCenterText(c,shop?"МАГАЗИН":"ВЫБОР СПОСОБНОСТИ",H*0.12f,H*0.052f,Color.WHITE);
        drawCenterText(c,shop?"15 фантастических способностей • открытия сохраняются":"Эффект, темп и механика отличаются у каждой",H*0.165f,H*0.021f,lighten(ui,0.35f));

        Ability[] a=Ability.values();
        for(int i=0;i<a.length;i++){
            RectF r=itemRects[i];boolean owned=unlocked[i];boolean open=isAbilityAvailable(i);boolean selected=a[i]==selectedAbility;
            int signature=abilityColor(a[i],0);
            int bg=selected?mixColor(Color.rgb(26,82,112),signature,0.34f):(open?Color.rgb(27,45,68):Color.rgb(43,38,50));
            drawPanel(c,r.left,r.top,r.right,r.bottom,bg,18f);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(selected?4f:2f);paint.setColor(selected?lighten(signature,0.35f):(open?withAlpha(signature,110):0x665B5364));c.drawRoundRect(r,18f,18f,paint);paint.setStyle(Paint.Style.FILL);

            float iconX=r.left+r.width()*0.15f, iconY=r.centerY(), iconS=Math.min(r.height()*0.27f,r.width()*0.09f);
            drawWeaponIcon(c,a[i],iconX,iconY,iconS,open?signature:Color.rgb(115,115,125));

            float tx=r.left+r.width()*0.59f;
            paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(open?Color.WHITE:Color.rgb(190,190,200));paint.setTextSize(Math.min(H*0.022f,r.height()*0.18f));
            c.drawText(a[i].title,tx,r.top+r.height()*0.28f,paint);
            paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(Math.min(H*0.0155f,r.height()*0.125f));paint.setColor(Color.rgb(165,192,215));
            c.drawText(shorten(a[i].desc,29),tx,r.top+r.height()*0.47f,paint);
            paint.setTextSize(Math.min(H*0.0145f,r.height()*0.115f));paint.setColor(lighten(signature,0.28f));
            c.drawText(weaponStat(a[i]),tx,r.top+r.height()*0.64f,paint);
            paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(Math.min(H*0.0185f,r.height()*0.145f));
            if(open){paint.setColor(selected?lighten(signature,0.40f):(creatorMode&&!owned?Color.rgb(255,215,90):Color.rgb(120,220,170)));c.drawText(selected?"ВЫБРАНО":(creatorMode&&!owned?"CREATOR":"ОТКРЫТО"),tx,r.top+r.height()*0.84f,paint);}
            else{paint.setColor(Color.rgb(255,211,90));c.drawText(a[i].price+" МОНЕТ",tx,r.top+r.height()*0.84f,paint);}
        }
    }


    private void drawAccessories(Canvas c){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.045f,H*0.035f,W*0.955f,H*0.95f,mixColor(0xF00D1728,ui,0.11f),28f);
        drawButton(c,backBtn,"НАЗАД","",mixColor(Color.rgb(38,55,80),ui,0.20f));
        drawCoinPill(c,W*0.80f,H*0.065f);
        drawCenterText(c,"СТИЛЬ ПЕРСОНАЖА",H*0.12f,H*0.052f,Color.WHITE);
        drawCenterText(c,"Аксессуары не влияют на урон — только внешний вид",H*0.165f,H*0.020f,lighten(ui,0.36f));
        Accessory[] all=Accessory.values();
        for(int i=0;i<all.length;i++){
            Accessory a=all[i];RectF r=accessoryRects[i];boolean open=isAccessoryAvailable(i);boolean selected=a==selectedAccessory;
            int accent=COLOR_PALETTE[(i+2)%COLOR_PALETTE.length];
            int bg=selected?mixColor(Color.rgb(43,38,82),accent,0.35f):(open?Color.rgb(27,43,63):Color.rgb(48,39,48));
            drawPanel(c,r.left,r.top,r.right,r.bottom,bg,20f);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(selected?4f:2f);paint.setColor(selected?lighten(accent,0.35f):(open?withAlpha(accent,120):0x665F5365));c.drawRoundRect(r,20f,20f,paint);paint.setStyle(Paint.Style.FILL);
            drawAccessoryIcon(c,a,r.centerX(),r.top+r.height()*0.34f,Math.min(r.width(),r.height())*0.20f,open?accent:Color.rgb(120,120,130));
            paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.020f);paint.setColor(open?Color.WHITE:Color.rgb(190,190,198));c.drawText(a.title,r.centerX(),r.top+r.height()*0.64f,paint);
            paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(H*0.014f);paint.setColor(Color.rgb(165,188,210));c.drawText(a.desc,r.centerX(),r.top+r.height()*0.76f,paint);
            paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.017f);
            if(open){paint.setColor(selected?lighten(accent,0.42f):(creatorMode&&!accessoryOwned[i]?Color.rgb(255,215,90):Color.rgb(120,220,170)));c.drawText(selected?"ВЫБРАНО":(creatorMode&&!accessoryOwned[i]?"CREATOR":"ОТКРЫТО"),r.centerX(),r.top+r.height()*0.91f,paint);}
            else{paint.setColor(Color.rgb(255,211,90));c.drawText(a.price+" МОНЕТ",r.centerX(),r.top+r.height()*0.91f,paint);}
        }
    }

    private void drawSettings(Canvas c){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.045f,H*0.035f,W*0.955f,H*0.95f,mixColor(0xF00D1728,ui,0.11f),28f);
        drawButton(c,backBtn,"НАЗАД","",mixColor(Color.rgb(38,55,80),ui,0.20f));
        drawCenterText(c,"НАСТРОЙКИ",H*0.12f,H*0.055f,Color.WHITE);
        drawCenterText(c,"Управление • графика • цвета • Creator Admin",H*0.165f,H*0.021f,lighten(ui,0.38f));

        drawCenterTextAt(c,"УПРАВЛЕНИЕ",W*0.205f,H*0.215f,H*0.027f,Color.WHITE);
        drawButton(c,joySideBtn,"СТОРОНА",joystickSide==0?"СЛЕВА":"СПРАВА",mixColor(Color.rgb(42,65,92),colorAt(joystickColorIdx),0.25f));
        drawButton(c,joySizeBtn,"РАЗМЕР",joystickSize==0?"МАЛЕНЬКИЙ":joystickSize==1?"СРЕДНИЙ":"БОЛЬШОЙ",mixColor(Color.rgb(42,65,92),colorAt(joystickColorIdx),0.25f));
        drawButton(c,joySensitivityBtn,"ЧУВСТВИТЕЛЬНОСТЬ",joystickSensitivity==0?"НИЗКАЯ":joystickSensitivity==1?"ОБЫЧНАЯ":"ВЫСОКАЯ",mixColor(Color.rgb(42,65,92),colorAt(joystickColorIdx),0.25f));
        drawButton(c,joyStyleBtn,"ВИД ДЖОЙСТИКА",joystickStyle==0?"КЛАССИКА":joystickStyle==1?"КОЛЬЦО":"НЕОН",mixColor(Color.rgb(42,65,92),colorAt(joystickColorIdx),0.25f));
        drawButton(c,qualityBtn,"ГРАФИКА",graphicsQuality==0?"ПРОИЗВОДИТЕЛЬНОСТЬ":graphicsQuality==1?"БАЛАНС":"УЛЬТРА",mixColor(Color.rgb(46,62,82),ui,0.24f));
        drawButton(c,resetSettingsBtn,"СБРОСИТЬ","стандартные настройки",Color.rgb(76,48,58));
        drawButton(c,creatorCodePanel,creatorMode?"АДМИН-ПАНЕЛЬ ✓":"КОД УСТРОЙСТВА",creatorMode?"нажми • "+deviceCode:deviceCode,creatorMode?Color.rgb(118,91,34):Color.rgb(47,62,86));

        drawCenterTextAt(c,"ЦВЕТА",W*0.67f,H*0.195f,H*0.027f,Color.WHITE);
        String[] labels={"ВСЁ СРАЗУ","ИГРОК","БОТ","ИНТЕРФЕЙС","ДЖОЙСТИК","СНАРЯДЫ","АРЕНА"};
        int[] idx={uiColorIdx,playerColorIdx,botColorIdx,uiColorIdx,joystickColorIdx,projectileColorIdx,arenaColorIdx};
        for(int i=0;i<colorSettingRects.length;i++) drawColorSettingRow(c,colorSettingRects[i],labels[i],idx[i],i==0);
        drawCenterTextAt(c,"левая половина ←   •   правая половина →",W*0.67f,H*0.925f,H*0.017f,Color.rgb(165,190,215));
    }

    private void drawAdmin(Canvas c){
        int ui=colorAt(uiColorIdx);
        drawPanel(c,W*0.045f,H*0.035f,W*0.955f,H*0.94f,mixColor(0xF20A1220,Color.rgb(255,194,70),0.08f),30f);
        drawButton(c,backBtn,"НАЗАД","настройки",mixColor(Color.rgb(38,55,80),ui,0.20f));
        drawCenterText(c,"CREATOR ADMIN",H*0.12f,H*0.056f,Color.rgb(255,220,110));
        drawCenterText(c,"только для твоего Creator-кода • тестовые функции",H*0.165f,H*0.020f,Color.rgb(205,215,230));
        drawCenterText(c,"Код: "+deviceCode+"   •   W "+totalWins+" / L "+totalLosses+"   •   заработано "+totalCoinsEarned,H*0.215f,H*0.020f,Color.WHITE);
        drawButton(c,adminActionBtns[0],"+1000 МОНЕТ","баланс: "+coins,Color.rgb(97,76,30));
        drawButton(c,adminActionBtns[1],"ОТКРЫТЬ ВСЁ","навсегда",Color.rgb(45,100,76));
        drawButton(c,adminActionBtns[2],"GOD MODE",adminGodMode?"ВКЛЮЧЕН":"выключен",adminGodMode?Color.rgb(45,115,82):Color.rgb(55,66,84));
        drawButton(c,adminActionBtns[3],"TURBO COOLDOWN",adminTurboCooldown?"x3.25 ВКЛ":"обычный",adminTurboCooldown?Color.rgb(50,95,125):Color.rgb(55,66,84));
        drawButton(c,adminActionBtns[4],"УРОН x2",adminDoubleDamage?"ВКЛЮЧЕН":"обычный",adminDoubleDamage?Color.rgb(128,58,58):Color.rgb(55,66,84));
        drawButton(c,adminActionBtns[5],"ЗАМОРОЗИТЬ БОТА",adminFreezeBot?"ВКЛЮЧЕНО":"выключено",adminFreezeBot?Color.rgb(66,95,128):Color.rgb(55,66,84));
        drawButton(c,adminActionBtns[6],"СБРОС ADMIN","оставить Creator Mode",Color.rgb(92,48,58));
        drawCenterText(c,"Боевые admin-бонусы отключены в режиме 2 игроков",H*0.885f,H*0.020f,Color.rgb(180,198,220));
    }

    private void drawColorSettingRow(Canvas c,RectF r,String label,int colorIndex,boolean global){
        int col=colorAt(colorIndex);
        drawPanel(c,r.left,r.top,r.right,r.bottom,mixColor(Color.rgb(28,44,66),col,global?0.18f:0.10f),18f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2f);paint.setColor(withAlpha(col,150));c.drawRoundRect(r,18f,18f,paint);
        paint.setStyle(Paint.Style.FILL);
        float sw=r.height()*0.26f;
        paint.setColor(col);c.drawCircle(r.right-r.height()*0.62f,r.centerY(),sw,paint);
        paint.setColor(withAlpha(Color.WHITE,180));paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(r.height()*0.27f);
        c.drawText("‹",r.left+r.height()*0.42f,r.centerY()+paint.getTextSize()*0.34f,paint);
        c.drawText("›",r.right-r.height()*0.18f,r.centerY()+paint.getTextSize()*0.34f,paint);
        paint.setTextAlign(Paint.Align.LEFT);paint.setColor(Color.WHITE);paint.setTextSize(r.height()*0.23f);
        c.drawText(label,r.left+r.height()*0.82f,r.centerY()+paint.getTextSize()*0.33f,paint);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    private void drawCenterTextAt(Canvas c,String text,float x,float y,float size,int color){
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(size);paint.setColor(color);c.drawText(text,x,y,paint);
    }

    private String weaponStat(Ability a){
        switch(a){
            case ENERGY_ORB:return "урон 11 • кд 0.42с";
            case BOUNCE_DISC:return "урон 10 • 4 рикошета";
            case HEAVY_GLOVE:return "урон 21 • ближний бой";
            case GRAVITY_BURST:return "урон 15 • сильный толчок";
            case ARC_CORE:return "урон 15 • полёт по дуге";
            case TRIPLE_SPARK:return "3×6.5 • кд 0.72с";
            case SHIELD_PULSE:return "щит 72% • 1.35с";
            case DASH_CORE:return "урон 15 • рывок";
            case FROST_SHARD:return "урон 10 • замедление";
            case LASER_BEAM:return "урон 17 • мгновенный луч";
            case MINE_CORE:return "урон 20 • ловушка";
            case RETURN_BLADE:return "урон 12 • возврат";
            case SKY_DROP:return "урон 19 • удар сверху";
            case VAMPIRE_BOLT:return "урон 10 • +7 HP";
            case BLINK_STRIKE:return "урон 17 • телепорт";
        }
        return "";
    }

    private void drawWeaponModel(Canvas c,Fighter f,int color){
        float r=f.radius;
        c.save();
        c.translate(f.x+f.facing*r*0.86f,f.y-r*0.08f);
        c.scale(f.facing,1f);
        drawWeaponIcon(c,f.ability,0,0,r*0.34f,color);
        c.restore();
    }

    private void drawWeaponIcon(Canvas c,Ability a,float cx,float cy,float s,int color){
        paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        c.save();c.translate(cx,cy);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.22f));paint.setColor(0xCC07101C);
        c.drawLine(-s*1.05f,0,s*0.15f,0,paint);
        paint.setStyle(Paint.Style.FILL);
        switch(a){
            case ENERGY_ORB:{
                paint.setColor(darken(color,0.28f));c.drawRoundRect(-s*0.85f,-s*0.20f,s*0.10f,s*0.20f,s*0.16f,s*0.16f,paint);
                paint.setColor(withAlpha(color,90));c.drawCircle(s*0.48f,0,s*0.62f,paint);paint.setColor(color);c.drawCircle(s*0.48f,0,s*0.38f,paint);break;
            }
            case BOUNCE_DISC:{
                paint.setColor(darken(color,0.22f));c.drawRoundRect(-s*0.95f,-s*0.16f,-s*0.05f,s*0.16f,s*0.12f,s*0.12f,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.18f));paint.setColor(color);shapeRect.set(s*0.03f,-s*0.42f,s*1.05f,s*0.42f);c.drawOval(shapeRect,paint);break;
            }
            case HEAVY_GLOVE:{
                paint.setColor(darken(color,0.20f));c.drawRoundRect(-s*0.90f,-s*0.16f,-s*0.05f,s*0.16f,s*0.12f,s*0.12f,paint);
                paint.setColor(color);c.drawRoundRect(-s*0.05f,-s*0.52f,s*0.92f,s*0.52f,s*0.22f,s*0.22f,paint);break;
            }
            case GRAVITY_BURST:{
                paint.setColor(darken(color,0.25f));c.drawRoundRect(-s*0.90f,-s*0.15f,-s*0.15f,s*0.15f,s*0.10f,s*0.10f,paint);
                paint.setColor(color);c.drawCircle(s*0.30f,0,s*0.42f,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.10f));paint.setColor(lighten(color,0.38f));shapeRect.set(-s*0.18f,-s*0.65f,s*0.78f,s*0.65f);c.drawOval(shapeRect,paint);break;
            }
            case ARC_CORE:{
                paint.setColor(darken(color,0.24f));c.drawRoundRect(-s*0.95f,-s*0.18f,s*0.15f,s*0.18f,s*0.10f,s*0.10f,paint);
                Path p=new Path();p.moveTo(s*1.00f,0);p.lineTo(s*0.25f,-s*0.48f);p.lineTo(s*0.05f,0);p.lineTo(s*0.25f,s*0.48f);p.close();paint.setColor(color);c.drawPath(p,paint);break;
            }
            case TRIPLE_SPARK:{
                paint.setColor(darken(color,0.30f));c.drawRoundRect(-s*0.95f,-s*0.17f,s*0.05f,s*0.17f,s*0.10f,s*0.10f,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.16f));paint.setColor(color);
                c.drawLine(s*0.05f,0,s*0.95f,0,paint);c.drawLine(s*0.02f,-s*0.25f,s*0.82f,-s*0.48f,paint);c.drawLine(s*0.02f,s*0.25f,s*0.82f,s*0.48f,paint);break;
            }
            case SHIELD_PULSE:{
                paint.setColor(darken(color,0.28f));c.drawRoundRect(-s*0.95f,-s*0.17f,-s*0.10f,s*0.17f,s*0.10f,s*0.10f,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.16f));paint.setColor(color);c.drawCircle(s*0.38f,0,s*0.52f,paint);c.drawLine(s*0.38f,-s*0.48f,s*0.38f,s*0.48f,paint);break;
            }
            case DASH_CORE:{
                paint.setColor(darken(color,0.24f));c.drawRoundRect(-s*0.95f,-s*0.15f,-s*0.25f,s*0.15f,s*0.10f,s*0.10f,paint);
                Path p=new Path();p.moveTo(-s*0.22f,-s*0.14f);p.lineTo(s*1.15f,0);p.lineTo(-s*0.22f,s*0.14f);p.close();paint.setColor(color);c.drawPath(p,paint);break;
            }
            case FROST_SHARD:{
                paint.setColor(darken(color,0.24f));c.drawRoundRect(-s*0.95f,-s*0.15f,-s*0.25f,s*0.15f,s*0.10f,s*0.10f,paint);
                Path ice=new Path();ice.moveTo(s*1.02f,0);ice.lineTo(s*0.24f,-s*0.55f);ice.lineTo(-s*0.08f,0);ice.lineTo(s*0.24f,s*0.55f);ice.close();paint.setColor(color);c.drawPath(ice,paint);break;
            }
            case LASER_BEAM:{
                paint.setColor(darken(color,0.28f));c.drawRoundRect(-s*1.00f,-s*0.20f,s*0.55f,s*0.20f,s*0.10f,s*0.10f,paint);
                paint.setColor(color);c.drawRoundRect(s*0.35f,-s*0.10f,s*1.18f,s*0.10f,s*0.08f,s*0.08f,paint);paint.setColor(Color.WHITE);c.drawCircle(s*1.12f,0,s*0.11f,paint);break;
            }
            case MINE_CORE:{
                paint.setColor(darken(color,0.28f));c.drawRoundRect(-s*0.95f,-s*0.18f,-s*0.10f,s*0.18f,s*0.10f,s*0.10f,paint);
                paint.setColor(color);c.drawCircle(s*0.35f,0,s*0.42f,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,s*0.12f));for(int i=0;i<6;i++){float ang=(float)(i*Math.PI/3);c.drawLine(s*0.35f+(float)Math.cos(ang)*s*0.35f,(float)Math.sin(ang)*s*0.35f,s*0.35f+(float)Math.cos(ang)*s*0.62f,(float)Math.sin(ang)*s*0.62f,paint);}break;
            }
            case RETURN_BLADE:{
                paint.setColor(darken(color,0.30f));c.drawRoundRect(-s*0.95f,-s*0.15f,-s*0.20f,s*0.15f,s*0.10f,s*0.10f,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,s*0.19f));paint.setColor(color);c.drawLine(-s*0.10f,-s*0.48f,s*0.65f,0,paint);c.drawLine(s*0.65f,0,-s*0.10f,s*0.48f,paint);break;
            }
            case SKY_DROP:{
                paint.setColor(darken(color,0.26f));c.drawRoundRect(-s*0.90f,-s*0.14f,-s*0.15f,s*0.14f,s*0.08f,s*0.08f,paint);
                paint.setColor(color);c.drawRoundRect(-s*0.10f,-s*0.13f,s*0.78f,s*0.13f,s*0.08f,s*0.08f,paint);Path p=new Path();p.moveTo(s*1.15f,0);p.lineTo(s*0.72f,-s*0.30f);p.lineTo(s*0.72f,s*0.30f);p.close();c.drawPath(p,paint);break;
            }
            case VAMPIRE_BOLT:{
                paint.setColor(darken(color,0.30f));c.drawRoundRect(-s*0.95f,-s*0.15f,-s*0.15f,s*0.15f,s*0.10f,s*0.10f,paint);
                paint.setColor(color);Path drop=new Path();drop.moveTo(s*0.92f,0);drop.cubicTo(s*0.42f,-s*0.60f,-s*0.06f,-s*0.30f,-s*0.06f,0);drop.cubicTo(-s*0.06f,s*0.30f,s*0.42f,s*0.60f,s*0.92f,0);drop.close();c.drawPath(drop,paint);break;
            }
            case BLINK_STRIKE:{
                paint.setColor(darken(color,0.30f));c.drawRoundRect(-s*0.95f,-s*0.14f,-s*0.22f,s*0.14f,s*0.08f,s*0.08f,paint);
                paint.setColor(color);Path p=new Path();p.moveTo(-s*0.18f,0);p.lineTo(s*0.94f,-s*0.34f);p.lineTo(s*0.58f,0);p.lineTo(s*0.94f,s*0.34f);p.close();c.drawPath(p,paint);break;
            }
        }
        c.restore();paint.setStyle(Paint.Style.FILL);
    }

    private String shorten(String s,int max){return s.length()<=max?s:s.substring(0,max-1)+"…";}

    private void drawBattle(Canvas c){
        if(player==null||bot==null)return;
        int pc=colorAt(playerColorIdx), bc=colorAt(botColorIdx);
        drawFighter(c,player,pc,lighten(pc,0.55f));
        drawFighter(c,bot,bc,lighten(bc,0.55f));
        for(Shot s:shots)drawShot(c,s);
        drawBeams(c);
        drawParticles(c);drawHud(c);drawJoystick(c);drawWeaponLabel(c);
        if(matchOver)drawMatchOver(c);
    }

    private void drawMatchOver(Canvas c){
        paint.setColor(0xE710182B);c.drawRect(0,0,W,H,paint);
        boolean p1Win=playerScore>botScore;
        boolean localWin=gameMode==GameMode.ONLINE?(onlineLocalIndex==0?p1Win:!p1Win):p1Win;
        String title;
        if(playerScore==botScore) title="НИЧЬЯ";
        else if(gameMode==GameMode.TWO_PLAYER) title=p1Win?"ИГРОК 1 ПОБЕДИЛ":"ИГРОК 2 ПОБЕДИЛ";
        else title=localWin?"ПОБЕДА!":"ПОРАЖЕНИЕ";
        drawCenterText(c,title,H*0.31f,H*0.080f,localWin?Color.rgb(115,235,180):Color.rgb(255,150,170));
        if(gameMode==GameMode.SOLO){
            drawCenterText(c,p1Win?"Награда: +"+lastReward+" монет":"Один бой = один раунд",H*0.42f,H*0.034f,Color.WHITE);
            drawCenterText(c,"Баланс: "+coins+" монет",H*0.49f,H*0.028f,Color.rgb(255,215,95));
        }else if(gameMode==GameMode.ONLINE){
            drawCenterText(c,"Онлайн Alpha • наград пока нет",H*0.43f,H*0.032f,Color.WHITE);
            drawCenterText(c,"Новый матч запускается через онлайн-меню",H*0.49f,H*0.024f,Color.rgb(190,215,235));
        }else{
            drawCenterText(c,"Локальная дуэль • наград нет",H*0.43f,H*0.032f,Color.WHITE);
            drawCenterText(c,arenaType.title,H*0.49f,H*0.026f,Color.rgb(190,215,235));
        }
        if(gameMode!=GameMode.ONLINE)drawButton(c,againBtn,"ЕЩЕ РАЗ","1 раунд",Color.rgb(34,125,92));
        drawButton(c,menuBtn,"В МЕНЮ",gameMode==GameMode.ONLINE?"закрыть соединение":"режим • арена • магазин",Color.rgb(45,70,105));
    }

    private void drawCoinPill(Canvas c,float cx,float cy){
        float w=W*0.15f,h=H*0.065f,l=cx-w*0.5f,t=cy-h*0.5f,r=cx+w*0.5f,b=cy+h*0.5f;
        drawPanel(c,l,t,r,b,0xDD2A2516,h*0.5f);
        paint.setColor(Color.rgb(255,210,70));c.drawCircle(l+h*0.55f,cy,h*0.22f,paint);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.027f);paint.setColor(Color.WHITE);c.drawText(String.valueOf(coins),cx+h*0.12f,cy+paint.getTextSize()*0.34f,paint);
    }

    private void drawMenuCard(Canvas c,RectF r,String title,String sub,int color,String icon){
        drawPanel(c,r.left,r.top,r.right,r.bottom,color,24f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.5f);paint.setColor(0x66FFFFFF);c.drawRoundRect(r,24f,24f,paint);paint.setStyle(Paint.Style.FILL);
        float iconX=r.left+r.width()*0.16f, iconY=r.centerY(), iconS=Math.min(r.width(),r.height())*0.20f;
        drawUiIcon(c,icon,iconX,iconY,iconS,Color.WHITE);
        paint.setTextAlign(Paint.Align.LEFT);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(Color.WHITE);paint.setTextSize(Math.min(H*0.026f,r.height()*0.25f));
        c.drawText(title,r.left+r.width()*0.30f,r.top+r.height()*0.43f,paint);
        paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(Math.min(H*0.0175f,r.height()*0.17f));paint.setColor(Color.rgb(190,215,235));
        c.drawText(shorten(sub,26),r.left+r.width()*0.30f,r.top+r.height()*0.68f,paint);
    }

    private void drawUiIcon(Canvas c,String icon,float cx,float cy,float s,int color){
        c.save(); c.translate(cx,cy); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); paint.setColor(color); paint.setStrokeWidth(Math.max(2f,s*0.16f));
        if("play".equals(icon)){
            Path p=new Path(); p.moveTo(-s*0.35f,-s*0.50f); p.lineTo(s*0.55f,0); p.lineTo(-s*0.35f,s*0.50f); p.close(); paint.setStyle(Paint.Style.FILL); c.drawPath(p,paint);
        } else if("mode".equals(icon)){
            c.drawCircle(-s*0.38f,0,s*0.18f,paint); c.drawCircle(s*0.38f,0,s*0.18f,paint); c.drawLine(-s*0.10f,-s*0.28f,s*0.10f,-s*0.28f,paint); c.drawLine(-s*0.10f,s*0.28f,s*0.10f,s*0.28f,paint);
        } else if("arena".equals(icon)){
            c.drawLine(-s*0.70f,s*0.18f,s*0.70f,s*0.18f,paint); c.drawLine(-s*0.40f,s*0.18f,-s*0.15f,-s*0.20f,paint); c.drawLine(s*0.15f,-s*0.20f,s*0.40f,s*0.18f,paint);
        } else if("weapon".equals(icon)){
            paint.setStyle(Paint.Style.FILL); c.drawRect(-s*0.55f,-s*0.10f,s*0.20f,s*0.10f,paint); Path p=new Path(); p.moveTo(s*0.20f,-s*0.16f); p.lineTo(s*0.70f,0); p.lineTo(s*0.20f,s*0.16f); p.close(); c.drawPath(p,paint);
        } else if("shop".equals(icon)){
            paint.setStyle(Paint.Style.STROKE); c.drawRect(-s*0.50f,-s*0.10f,s*0.50f,s*0.48f,paint); c.drawLine(-s*0.32f,-s*0.10f,-s*0.15f,-s*0.40f,paint); c.drawLine(s*0.32f,-s*0.10f,s*0.15f,-s*0.40f,paint); c.drawLine(-s*0.15f,-s*0.40f,s*0.15f,-s*0.40f,paint);
        } else if("style".equals(icon)){
            paint.setStyle(Paint.Style.FILL); c.drawCircle(0,-s*0.25f,s*0.18f,paint); paint.setStyle(Paint.Style.STROKE); c.drawArc(-s*0.48f,-s*0.05f,s*0.48f,s*0.68f,200,140,false,paint);
        } else if("online".equals(icon)){
            c.drawCircle(0,0,s*0.52f,paint); c.drawArc(-s*0.58f,-s*0.35f,s*0.58f,s*0.35f,0,180,false,paint); c.drawArc(-s*0.58f,-s*0.35f,s*0.58f,s*0.35f,180,180,false,paint); c.drawLine(0,-s*0.52f,0,s*0.52f,paint);
        } else if("random".equals(icon)){
            c.drawLine(-s*0.60f,-s*0.25f,s*0.20f,-s*0.25f,paint); c.drawLine(-s*0.60f,s*0.25f,s*0.20f,s*0.25f,paint); Path p=new Path(); p.moveTo(s*0.20f,-s*0.46f); p.lineTo(s*0.62f,-s*0.25f); p.lineTo(s*0.20f,-s*0.04f); p.close(); paint.setStyle(Paint.Style.FILL); c.drawPath(p,paint); Path p2=new Path(); p2.moveTo(s*0.20f,s*0.04f); p2.lineTo(s*0.62f,s*0.25f); p2.lineTo(s*0.20f,s*0.46f); c.drawPath(p2,paint);
        } else if("settings".equals(icon)){
            c.drawCircle(0,0,s*0.20f,paint); for(int i=0;i<8;i++){ double a=i*Math.PI/4.0; float x1=(float)Math.cos(a)*s*0.34f, y1=(float)Math.sin(a)*s*0.34f; float x2=(float)Math.cos(a)*s*0.56f, y2=(float)Math.sin(a)*s*0.56f; c.drawLine(x1,y1,x2,y2,paint);} 
        }
        paint.setStyle(Paint.Style.FILL); c.restore();
    }

    private void drawButton(Canvas c,RectF r,String title,String sub,int color){
        drawPanel(c,r.left,r.top,r.right,r.bottom,color,22f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2f);paint.setColor(0x66FFFFFF);c.drawRoundRect(r,22f,22f,paint);paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(Color.WHITE);paint.setTextSize(Math.min(H*0.030f,r.height()*0.31f));
        float base=r.centerY()+(sub.isEmpty()?paint.getTextSize()*0.32f:-r.height()*0.05f);c.drawText(title,r.centerX(),base,paint);
        if(!sub.isEmpty()){paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(Math.min(H*0.019f,r.height()*0.19f));paint.setColor(Color.rgb(190,215,235));c.drawText(shorten(sub,32),r.centerX(),r.centerY()+r.height()*0.28f,paint);}
    }

    private void drawPanel(Canvas c,float l,float t,float r,float b,int color,float radius){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRoundRect(l,t,r,b,radius,radius,paint);}

    private void rebuildArenaBitmap(int width,int height){
        if(width<=0||height<=0)return;
        if(arenaBitmap!=null&&!arenaBitmap.isRecycled())arenaBitmap.recycle();
        arenaBitmap=Bitmap.createBitmap(width,height,Bitmap.Config.RGB_565);Canvas c=new Canvas(arenaBitmap);

        int accent=colorAt(arenaColorIdx);
        int skyTop=mixColor(Color.rgb(6,10,24),accent,0.08f);
        int skyMid=mixColor(Color.rgb(17,27,50),accent,0.15f);
        int skyBottom=mixColor(Color.rgb(28,37,58),accent,0.20f);
        if(arenaType==ArenaType.LOW_GRAV){skyTop=mixColor(Color.rgb(4,5,18),accent,0.16f);skyBottom=mixColor(Color.rgb(15,20,46),accent,0.27f);}
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0,0,0,H,new int[]{skyTop,skyMid,skyBottom},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,paint);paint.setShader(null);

        float moonX=W*0.78f,moonY=H*0.19f,moonR=Math.min(W,H)*(arenaType==ArenaType.LOW_GRAV?0.095f:0.075f);
        int moon=lighten(accent,0.62f);
        paint.setShader(new RadialGradient(moonX,moonY,moonR*2.8f,new int[]{withAlpha(moon,90),withAlpha(moon,35),withAlpha(moon,0)},null,Shader.TileMode.CLAMP));
        c.drawCircle(moonX,moonY,moonR*2.8f,paint);paint.setShader(null);
        paint.setColor(lighten(moon,0.20f));c.drawCircle(moonX,moonY,moonR,paint);

        paint.setColor(0xCCFFFFFF);
        int starCount=graphicsQuality==0?24:graphicsQuality==1?42:starX.length;
        for(int i=0;i<starCount;i++)c.drawCircle(starX[i]*W,starY[i]*H,starR[i]*Math.max(1f,H/720f),paint);

        int city=darken(mixColor(Color.rgb(18,27,48),accent,0.18f),0.08f);
        paint.setColor(city);
        for(int i=0;i<14;i++){
            float bw=W/14f,bh=H*(0.08f+(i%5)*0.018f),bx=i*bw;
            c.drawRect(bx,groundY-bh,bx+bw*0.82f,groundY,paint);
            if(graphicsQuality>0){paint.setColor(withAlpha(lighten(accent,0.48f),graphicsQuality==2?125:75));for(int row=0;row<3;row++){float wy=groundY-bh+H*0.018f+row*H*0.022f;if(wy<groundY-H*0.008f)c.drawRect(bx+bw*0.18f,wy,bx+bw*0.28f,wy+H*0.008f,paint);}paint.setColor(city);}
        }

        int floorTop=mixColor(Color.rgb(38,52,76),accent,0.22f);
        int floorBottom=mixColor(Color.rgb(13,19,34),accent,0.10f);
        paint.setShader(new LinearGradient(0,groundY,0,H,floorTop,floorBottom,Shader.TileMode.CLAMP));
        if(arenaType==ArenaType.SPLIT){
            c.drawRect(0,groundY,W*0.43f,H,paint);c.drawRect(W*0.57f,groundY,W,H,paint);
        }else c.drawRect(0,groundY,W,H,paint);
        paint.setShader(null);
        paint.setColor(lighten(accent,0.15f));
        if(arenaType==ArenaType.SPLIT){
            c.drawRect(0,groundY,W*0.43f,groundY+Math.max(4f,H*0.006f),paint);
            c.drawRect(W*0.57f,groundY,W,groundY+Math.max(4f,H*0.006f),paint);
            paint.setColor(withAlpha(Color.rgb(255,90,110),180));
            c.drawRect(W*0.43f,groundY,W*0.435f,H,paint);c.drawRect(W*0.565f,groundY,W*0.57f,H,paint);
        }else{
            c.drawRect(0,groundY,W,groundY+Math.max(4f,H*0.006f),paint);
        }
        if(arenaType==ArenaType.BOUNCE){
            paint.setColor(withAlpha(lighten(accent,0.45f),150));
            for(int i=0;i<12;i++){float x=i*W/12f;c.drawRect(x,groundY+H*0.018f,x+W/24f,groundY+H*0.032f,paint);}
        }
    }

    private void drawArena(Canvas c){if(arenaBitmap!=null&&!arenaBitmap.isRecycled())c.drawBitmap(arenaBitmap,0,0,paint);else c.drawColor(Color.rgb(8,12,24));}

    private void drawAccessoryIcon(Canvas c,Accessory a,float cx,float cy,float s,int color){
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeWidth(Math.max(3f,s*0.16f));paint.setColor(color);
        switch(a){
            case NONE: c.drawCircle(cx,cy,s*0.52f,paint);c.drawLine(cx-s*0.35f,cy+s*0.35f,cx+s*0.35f,cy-s*0.35f,paint);break;
            case HEADBAND: c.drawArc(cx-s,cy-s*0.55f,cx+s,cy+s*0.45f,195,150,false,paint);c.drawLine(cx+s*0.70f,cy-s*0.18f,cx+s*1.25f,cy-s*0.55f,paint);break;
            case VISOR: paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(color,210));c.drawRoundRect(cx-s,cy-s*0.25f,cx+s,cy+s*0.25f,s*0.20f,s*0.20f,paint);paint.setColor(Color.WHITE);c.drawRoundRect(cx-s*0.55f,cy-s*0.08f,cx+s*0.55f,cy+s*0.08f,s*0.06f,s*0.06f,paint);break;
            case HEADPHONES: paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,s*0.18f));paint.setColor(color);c.drawArc(cx-s,cy-s,cx+s,cy+s,190,160,false,paint);c.drawRoundRect(cx-s*1.0f,cy-s*0.15f,cx-s*0.62f,cy+s*0.55f,s*0.12f,s*0.12f,paint);c.drawRoundRect(cx+s*0.62f,cy-s*0.15f,cx+s,cy+s*0.55f,s*0.12f,s*0.12f,paint);break;
            case CROWN:{paint.setStyle(Paint.Style.FILL);paint.setColor(color);Path pth=new Path();pth.moveTo(cx-s,cy+s*0.45f);pth.lineTo(cx-s*0.75f,cy-s*0.70f);pth.lineTo(cx-s*0.18f,cy-s*0.10f);pth.lineTo(cx,cy-s*0.95f);pth.lineTo(cx+s*0.20f,cy-s*0.10f);pth.lineTo(cx+s*0.78f,cy-s*0.70f);pth.lineTo(cx+s,cy+s*0.45f);pth.close();c.drawPath(pth,paint);break;}
            case CAPE:{paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(color,220));Path pth=new Path();pth.moveTo(cx-s*0.55f,cy-s*0.8f);pth.lineTo(cx+s*0.7f,cy-s*0.45f);pth.lineTo(cx+s*0.95f,cy+s*0.95f);pth.lineTo(cx-s*0.3f,cy+s*0.5f);pth.close();c.drawPath(pth,paint);break;}
            case HORNS: paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,s*0.18f));paint.setColor(color);c.drawArc(cx-s*1.15f,cy-s,cx-s*0.05f,cy+s*0.55f,190,105,false,paint);c.drawArc(cx+s*0.05f,cy-s,cx+s*1.15f,cy+s*0.55f,245,105,false,paint);break;
            case HALO: paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,s*0.14f));paint.setColor(color);c.drawOval(cx-s*1.05f,cy-s*0.45f,cx+s*1.05f,cy+s*0.30f,paint);break;
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawFighterAccessory(Canvas c,Fighter f,float headY,float headR){
        Accessory a=f.accessory;if(a==null||a==Accessory.NONE)return;
        int color=f.isBot?lighten(colorAt(botColorIdx),0.35f):lighten(colorAt(playerColorIdx),0.35f);
        float x=f.x,y=headY;
        switch(a){
            case HEADBAND: drawAccessoryIcon(c,a,x,y-headR*0.10f,headR*0.85f,color);break;
            case VISOR: drawAccessoryIcon(c,a,x+f.facing*headR*0.10f,y,headR*0.70f,color);break;
            case HEADPHONES: drawAccessoryIcon(c,a,x,y,headR*0.82f,color);break;
            case CROWN: drawAccessoryIcon(c,a,x,y-headR*1.25f,headR*0.72f,Color.rgb(255,215,80));break;
            case CAPE:{paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(color,205));Path pth=new Path();float dir=-f.facing;pth.moveTo(f.x-dir*f.radius*0.08f,f.y-f.radius*0.10f);pth.lineTo(f.x+dir*f.radius*1.05f,f.y+f.radius*0.25f);pth.lineTo(f.x+dir*f.radius*1.28f,f.y+f.radius*1.05f);pth.lineTo(f.x+dir*f.radius*0.15f,f.y+f.radius*0.62f);pth.close();c.drawPath(pth,paint);break;}
            case HORNS: drawAccessoryIcon(c,a,x,y-headR*0.75f,headR*0.74f,color);break;
            case HALO: drawAccessoryIcon(c,a,x,y-headR*1.45f,headR*0.78f,Color.rgb(255,238,135));break;
            default: break;
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawFighter(Canvas c,Fighter f,int color,int lightColor){
        float r=f.radius,bodyTop=f.y-r*0.23f,bodyBottom=f.y+r*0.62f,headY=f.y-r*0.78f,headR=r*0.48f;
        if(f.grounded){paint.setStyle(Paint.Style.FILL);paint.setColor(0x38000000);tmpRect.set(f.x-r*0.95f,groundY+r*0.88f,f.x+r*0.95f,groundY+r*1.10f);c.drawOval(tmpRect,paint);}
        c.save();
        if(f.landingSquash>0f){float sq=f.landingSquash;c.translate(f.x,f.y+r*1.05f);c.scale(1f+0.10f*sq,1f-0.08f*sq);c.translate(-f.x,-(f.y+r*1.05f));}
        if(graphicsQuality>0){paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(color,graphicsQuality==2?48:30));c.drawCircle(f.x,f.y,r*(graphicsQuality==2?1.90f:1.65f),paint);}
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(11f,r*0.34f));paint.setColor(0xAA050810);drawStick(c,f,bodyTop,bodyBottom,headY,headR);
        paint.setStrokeWidth(Math.max(7f,r*0.24f));paint.setColor(color);drawStick(c,f,bodyTop,bodyBottom,headY,headR);
        paint.setStyle(Paint.Style.FILL);paint.setColor(lightColor);c.drawCircle(f.x+f.facing*headR*0.34f,headY-headR*0.08f,headR*0.10f,paint);
        drawFighterAccessory(c,f,headY,headR);

        drawWeaponModel(c,f,abilityColor(f.ability,f.isBot?1:0));

        if(f.shield>0){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,r*0.10f));paint.setColor(lightColor);
            c.drawCircle(f.x,f.y,r*1.58f,paint);
            paint.setStrokeWidth(Math.max(2f,r*0.055f));paint.setColor(withAlpha(lightColor,115));c.drawCircle(f.x,f.y,r*1.78f,paint);
        }
        if(f.slowTimer>0){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,r*0.08f));paint.setColor(Color.rgb(150,235,255));c.drawCircle(f.x,f.y,r*1.35f,paint);
        }
        paint.setStyle(Paint.Style.FILL);
        c.restore();
    }

    private void drawStick(Canvas c,Fighter f,float bodyTop,float bodyBottom,float headY,float headR){
        float r=f.radius;
        float sway=clamp(f.vx/(W*0.52f),-1f,1f)*r*0.24f;
        float air=clamp(f.vy/(H*0.85f),-1f,1f)*r*0.18f;
        float shoulderX=f.x+sway*0.35f, hipX=f.x-sway*0.25f;
        c.drawLine(shoulderX,bodyTop,hipX,bodyBottom,paint);
        c.drawLine(shoulderX,f.y+r*0.02f,shoulderX-r*(0.70f+air*0.002f)*f.facing,f.y+r*0.36f+air,paint);
        c.drawLine(shoulderX,f.y+r*0.02f,shoulderX+r*0.86f*f.facing,f.y-r*0.10f-air*0.5f,paint);
        c.drawLine(hipX,bodyBottom,hipX-r*0.56f-sway*0.35f,f.y+r*1.10f,paint);
        c.drawLine(hipX,bodyBottom,hipX+r*0.56f-sway*0.35f,f.y+r*1.10f,paint);
        c.drawCircle(f.x+sway*0.28f,headY+air*0.20f,headR,paint);
    }

    private void drawShot(Canvas c,Shot s){
        int core=abilityColor(s.source,s.owner);
        float speed=(float)Math.sqrt(s.vx*s.vx+s.vy*s.vy);
        float nx=speed>1?s.vx/speed:1f, ny=speed>1?s.vy/speed:0f;

        if(graphicsQuality>0){
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f,s.radius*(graphicsQuality==2?0.42f:0.35f)));
            paint.setColor(withAlpha(core,graphicsQuality==2?120:82));
            c.drawLine(s.x-nx*s.radius*(graphicsQuality==2?2.9f:2.2f),s.y-ny*s.radius*(graphicsQuality==2?2.9f:2.2f),s.x,s.y,paint);
        }

        c.save();
        c.translate(s.x,s.y);
        float deg=(float)Math.toDegrees(Math.atan2(s.vy,s.vx));
        c.rotate(deg);
        paint.setStyle(Paint.Style.FILL);

        switch(s.source){
            case ENERGY_ORB:{
                paint.setColor(withAlpha(core,75));c.drawCircle(0,0,s.radius*1.75f,paint);
                paint.setColor(core);c.drawCircle(0,0,s.radius,paint);
                paint.setColor(Color.WHITE);c.drawCircle(-s.radius*0.15f,-s.radius*0.15f,s.radius*0.28f,paint);
                break;
            }
            case BOUNCE_DISC:{
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,s.radius*0.24f));paint.setColor(core);
                shapeRect.set(-s.radius*1.25f,-s.radius*0.48f,s.radius*1.25f,s.radius*0.48f);c.drawOval(shapeRect,paint);
                paint.setStrokeWidth(Math.max(2f,s.radius*0.12f));paint.setColor(Color.WHITE);
                shapeRect.set(-s.radius*0.62f,-s.radius*0.23f,s.radius*0.62f,s.radius*0.23f);c.drawOval(shapeRect,paint);
                break;
            }
            case ARC_CORE:{
                Path d=new Path();d.moveTo(s.radius*1.1f,0);d.lineTo(0,-s.radius*0.9f);d.lineTo(-s.radius*1.1f,0);d.lineTo(0,s.radius*0.9f);d.close();
                paint.setColor(withAlpha(core,90));c.drawCircle(0,0,s.radius*1.45f,paint);
                paint.setColor(core);c.drawPath(d,paint);paint.setColor(Color.WHITE);c.drawCircle(0,0,s.radius*0.22f,paint);
                break;
            }
            case TRIPLE_SPARK:{
                Path t=new Path();t.moveTo(s.radius*1.2f,0);t.lineTo(-s.radius*0.55f,-s.radius*0.65f);t.lineTo(-s.radius*0.25f,0);t.lineTo(-s.radius*0.55f,s.radius*0.65f);t.close();
                paint.setColor(core);c.drawPath(t,paint);paint.setColor(Color.WHITE);c.drawCircle(0,0,s.radius*0.18f,paint);break;
            }
            case FROST_SHARD:{
                Path ice=new Path();ice.moveTo(s.radius*1.35f,0);ice.lineTo(0,-s.radius*0.72f);ice.lineTo(-s.radius*1.05f,0);ice.lineTo(0,s.radius*0.72f);ice.close();
                paint.setColor(core);c.drawPath(ice,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.5f);paint.setColor(Color.WHITE);c.drawLine(-s.radius*0.35f,0,s.radius*0.65f,0,paint);break;
            }
            case MINE_CORE:{
                paint.setColor(core);c.drawCircle(0,0,s.radius*0.72f,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2.5f,s.radius*0.16f));paint.setColor(lighten(core,0.30f));
                for(int i=0;i<8;i++){float a=(float)(i*Math.PI/4);c.drawLine((float)Math.cos(a)*s.radius*0.70f,(float)Math.sin(a)*s.radius*0.70f,(float)Math.cos(a)*s.radius*1.25f,(float)Math.sin(a)*s.radius*1.25f,paint);}
                if(s.armed){paint.setColor(Color.WHITE);c.drawCircle(0,0,s.radius*1.48f,paint);}
                break;
            }
            case RETURN_BLADE:{
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,s.radius*0.32f));paint.setColor(core);
                c.drawLine(-s.radius*0.95f,-s.radius*0.62f,0,0,paint);c.drawLine(0,0,-s.radius*0.95f,s.radius*0.62f,paint);
                paint.setStrokeWidth(Math.max(2f,s.radius*0.11f));paint.setColor(Color.WHITE);c.drawCircle(0,0,s.radius*0.25f,paint);break;
            }
            case SKY_DROP:{
                paint.setColor(core);c.drawRoundRect(-s.radius*0.28f,-s.radius*1.25f,s.radius*0.28f,s.radius*0.75f,s.radius*0.20f,s.radius*0.20f,paint);
                Path tip=new Path();tip.moveTo(s.radius*0.28f,s.radius*0.55f);tip.lineTo(0,s.radius*1.45f);tip.lineTo(-s.radius*0.28f,s.radius*0.55f);tip.close();c.drawPath(tip,paint);
                break;
            }
            case VAMPIRE_BOLT:{
                paint.setColor(core);shapeRect.set(-s.radius*1.0f,-s.radius*0.58f,s.radius*1.15f,s.radius*0.58f);c.drawOval(shapeRect,paint);
                paint.setColor(Color.WHITE);c.drawCircle(s.radius*0.30f,-s.radius*0.12f,s.radius*0.18f,paint);break;
            }
            default:{
                paint.setColor(withAlpha(core,75));c.drawCircle(0,0,s.radius*1.6f,paint);paint.setColor(core);c.drawCircle(0,0,s.radius,paint);break;
            }
        }
        c.restore();

        if(s.mine&&s.armed){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3f);paint.setColor(withAlpha(lighten(core,0.35f),180));
            c.drawCircle(s.x,s.y,s.radius*1.55f,paint);paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawParticles(Canvas c){
        paint.setStyle(Paint.Style.FILL);int i=0;
        for(Particle p:particles){
            if(graphicsQuality==0 && (i++&1)==1)continue;
            int a=(int)(255f*clamp(p.life/p.maxLife,0,1));paint.setColor(withAlpha(p.color,a));
            float size=p.size*(0.5f+0.5f*p.life/p.maxLife);c.drawCircle(p.x,p.y,size,paint);
            if(graphicsQuality==2&&a>90){paint.setColor(withAlpha(p.color,a/4));c.drawCircle(p.x,p.y,size*1.9f,paint);}
        }
    }

    private void drawBeams(Canvas c){
        for(BeamFx b:beams){
            float t=clamp(b.life/b.maxLife,0,1);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f,b.width*(0.45f+0.55f*t)));
            paint.setColor(withAlpha(b.color,(int)(205*t)));
            c.drawLine(b.x1,b.y1,b.x2,b.y2,paint);
            paint.setStrokeWidth(Math.max(1f,b.width*0.32f));paint.setColor(withAlpha(Color.WHITE,(int)(220*t)));
            c.drawLine(b.x1,b.y1,b.x2,b.y2,paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawHud(Canvas c){
        float barW=W*0.30f,barH=Math.max(16f,H*0.030f),y=H*0.045f;
        drawHealthBar(c,W*0.035f,y,barW,barH,player.hp,colorAt(playerColorIdx),false);
        drawHealthBar(c,W*0.965f-barW,y,barW,barH,bot.hp,colorAt(botColorIdx),true);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.030f);paint.setColor(Color.WHITE);c.drawText("1 РАУНД",W*0.5f,H*0.067f,paint);
        paint.setTextSize(H*0.018f);paint.setColor(lighten(colorAt(uiColorIdx),0.42f));
        String sub=gameMode==GameMode.SOLO?difficulty.title+" • +"+difficulty.reward+" монет":gameMode==GameMode.ONLINE?("ОНЛАЙН • P"+(onlineLocalIndex+1)):gameMode.title;
        c.drawText(sub+" • "+arenaType.title,W*0.5f,H*0.102f,paint);
        if(creatorMode&&gameMode==GameMode.SOLO){paint.setTextAlign(Paint.Align.LEFT);paint.setTextSize(H*0.016f);paint.setColor(Color.rgb(255,215,90));c.drawText("CREATOR",W*0.035f,H*0.118f,paint);}
    }

    private void drawHealthBar(Canvas c,float x,float y,float w,float h,float hp,int color,boolean reverse){paint.setColor(0xAA111827);c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,paint);float fw=w*(clamp(hp,0,100)/100f);paint.setColor(color);if(reverse)c.drawRoundRect(x+w-fw,y,x+w,y+h,h/2,h/2,paint);else c.drawRoundRect(x,y,x+fw,y+h,h/2,h/2,paint);}

    private void drawWeaponLabel(Canvas c){
        if(gameMode==GameMode.TWO_PLAYER)return;
        Fighter localFighter=(gameMode==GameMode.ONLINE&&onlineLocalIndex==1)?bot:player;
        int localOwner=(gameMode==GameMode.ONLINE&&onlineLocalIndex==1)?1:0;
        boolean joyLeft=joystickSide==0;
        float l=joyLeft?W*0.66f:W*0.025f;
        float r=joyLeft?W*0.975f:W*0.34f;
        tmpRect.set(l,H*0.84f,r,H*0.94f);
        int sig=abilityColor(localFighter.ability,localOwner);
        drawPanel(c,tmpRect.left,tmpRect.top,tmpRect.right,tmpRect.bottom,mixColor(0xAA132139,sig,0.18f),20f);
        drawWeaponIcon(c,localFighter.ability,tmpRect.left+tmpRect.height()*0.50f,tmpRect.centerY(),tmpRect.height()*0.22f,sig);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(Color.WHITE);paint.setTextSize(H*0.022f);
        c.drawText(localFighter.ability.title,tmpRect.centerX()+tmpRect.height()*0.18f,tmpRect.centerY()-H*0.006f,paint);
        paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(H*0.0155f);paint.setColor(lighten(sig,0.36f));
        int cd10=(int)Math.ceil(localFighter.attackCd*10f);String cooldownText=localFighter.attackCd<=0f?"ГОТОВО":"КД "+(cd10/10)+"."+(cd10%10)+"с";
        c.drawText(cooldownText,tmpRect.centerX()+tmpRect.height()*0.18f,tmpRect.centerY()+H*0.024f,paint);
        float ready=localFighter.attackCd<=0f?1f:0f;paint.setColor(withAlpha(sig,180));c.drawRoundRect(tmpRect.left+tmpRect.height()*0.15f,tmpRect.bottom-H*0.009f,tmpRect.right-tmpRect.height()*0.15f,tmpRect.bottom-H*0.004f,H*0.004f,H*0.004f,paint);
        if(ready>0f){paint.setColor(Color.WHITE);c.drawCircle(tmpRect.right-tmpRect.height()*0.18f,tmpRect.top+tmpRect.height()*0.25f,H*0.006f,paint);}
    }

    private void drawJoystick(Canvas c){
        if(gameMode==GameMode.TWO_PLAYER){
            drawJoystickAt(c,joyCx,joyCy,joyRadius,knobRadius,joyX,joyY,aimX,aimY,jumpCharge,jumpArcRect,colorAt(joystickColorIdx));
            drawJoystickAt(c,joy2Cx,joy2Cy,joy2Radius,knob2Radius,joy2X,joy2Y,aim2X,aim2Y,jump2Charge,jump2ArcRect,colorAt(botColorIdx));
        }else{
            drawJoystickAt(c,joyCx,joyCy,joyRadius,knobRadius,joyX,joyY,aimX,aimY,jumpCharge,jumpArcRect,colorAt(joystickColorIdx));
        }
    }

    private void drawJoystickAt(Canvas c,float cx,float cy,float radius,float knob,float jx,float jy,float ax,float ay,float charge,RectF arc,int jc){
        float mag=(float)Math.sqrt(jx*jx+jy*jy),kx=cx+jx*radius*0.72f,ky=cy+jy*radius*0.72f;
        if(joystickStyle==0){
            paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(darken(jc,0.55f),78));c.drawCircle(cx,cy,radius,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,H*0.004f));paint.setColor(withAlpha(lighten(jc,0.30f),155));c.drawCircle(cx,cy,radius,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(jc,105));c.drawCircle(kx,ky,knob*1.35f,paint);
            paint.setColor(withAlpha(lighten(jc,0.28f),238));c.drawCircle(kx,ky,knob,paint);
            paint.setColor(Color.WHITE);c.drawCircle(kx,ky,knob*0.46f,paint);
        }else if(joystickStyle==1){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(5f,H*0.007f));paint.setColor(withAlpha(jc,170));c.drawCircle(cx,cy,radius,paint);
            paint.setStrokeWidth(Math.max(3f,H*0.004f));paint.setColor(withAlpha(lighten(jc,0.42f),210));c.drawCircle(kx,ky,knob,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(jc,80));c.drawCircle(kx,ky,knob*0.72f,paint);
        }else{
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(8f,H*0.010f));paint.setColor(withAlpha(jc,55));c.drawCircle(cx,cy,radius*1.02f,paint);
            paint.setStrokeWidth(Math.max(3f,H*0.004f));paint.setColor(withAlpha(lighten(jc,0.35f),220));c.drawCircle(cx,cy,radius,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(jc,75));c.drawCircle(kx,ky,knob*1.55f,paint);
            paint.setColor(lighten(jc,0.25f));c.drawCircle(kx,ky,knob*0.94f,paint);
            paint.setColor(Color.WHITE);c.drawCircle(kx,ky,knob*0.31f,paint);
        }
        if(charge>0f){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(7f,H*0.009f));paint.setColor(Color.rgb(255,210,85));
            c.drawArc(arc,-90,360f*clamp(charge/0.5f,0,1),false,paint);
        }
        if(mag>0.22f){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,H*0.006f));paint.setColor(withAlpha(Color.WHITE,210));
            c.drawLine(cx,cy,cx+ax*radius*1.35f,cy+ay*radius*1.35f,paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawCenterText(Canvas c,String text,float y,float size,int color){paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(size);paint.setColor(color);c.drawText(text,W/2f,y,paint);}

    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked(),index=e.getActionIndex();float x=e.getX(index),y=e.getY(index);

        if(screen==Screen.HOME&&action==MotionEvent.ACTION_DOWN){
            if(gameMode==GameMode.SOLO){
                for(int i=0;i<3;i++)if(difficultyBtns[i].contains(x,y)){difficulty=Difficulty.values()[i];saveProgress();invalidate();return true;}
            }
            if(modeBtn.contains(x,y)){gameMode=gameMode==GameMode.SOLO?GameMode.TWO_PLAYER:GameMode.SOLO;applyJoystickLayout();saveProgress();invalidate();return true;}
            if(arenaBtn.contains(x,y)){arenaType=ArenaType.values()[(arenaType.ordinal()+1)%ArenaType.values().length];saveProgress();rebuildArenaBitmap((int)W,(int)H);invalidate();return true;}
            if(armoryBtn.contains(x,y)){screen=Screen.ARMORY;invalidate();return true;}
            if(shopBtn.contains(x,y)){screen=Screen.SHOP;invalidate();return true;}
            if(accessoriesBtn.contains(x,y)){screen=Screen.ACCESSORIES;invalidate();return true;}
            if(settingsBtn.contains(x,y)){screen=Screen.SETTINGS;invalidate();return true;}
            if(onlineBtn.contains(x,y)){screen=Screen.ONLINE;onlineStatus="НЕ ПОДКЛЮЧЕНО";onlineHostIp=OnlinePeer.localIpv4Address();onlineHostIpv6=OnlinePeer.globalIpv6Address();invalidate();return true;}
            if(randomBtn.contains(x,y)){chooseRandomUnlocked();invalidate();return true;}
            if(playBtn.contains(x,y)){startBattle();return true;}
            return true;
        }

        if(screen==Screen.ONLINE&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){closeOnline(true);invalidate();return true;}
            if(onlineHostBtn.contains(x,y)){startOnlineHost();return true;}
            if(onlineJoinBtn.contains(x,y)){showOnlineJoinDialog();return true;}
            if(onlineCancelBtn.contains(x,y)){closeOnline(false);invalidate();return true;}
            return true;
        }

        if((screen==Screen.ARMORY||screen==Screen.SHOP)&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){screen=Screen.HOME;invalidate();return true;}
            Ability[] a=Ability.values();
            for(int i=0;i<a.length;i++)if(itemRects[i].contains(x,y)){
                if(isAbilityAvailable(i)){selectedAbility=a[i];saveProgress();if(screen==Screen.ARMORY){screen=Screen.HOME;}invalidate();return true;}
                if(screen==Screen.SHOP&&coins>=a[i].price){coins-=a[i].price;unlocked[i]=true;selectedAbility=a[i];saveProgress();invalidate();return true;}
                return true;
            }
            return true;
        }

        if(screen==Screen.ACCESSORIES&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){screen=Screen.HOME;invalidate();return true;}
            Accessory[] all=Accessory.values();
            for(int i=0;i<all.length;i++)if(accessoryRects[i].contains(x,y)){
                if(isAccessoryAvailable(i)){selectedAccessory=all[i];saveProgress();screen=Screen.HOME;invalidate();return true;}
                if(coins>=all[i].price){coins-=all[i].price;accessoryOwned[i]=true;selectedAccessory=all[i];saveProgress();invalidate();return true;}
                return true;
            }
            return true;
        }

        if(screen==Screen.SETTINGS&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){screen=Screen.HOME;invalidate();return true;}
            if(joySideBtn.contains(x,y)){joystickSide=1-joystickSide;applyJoystickLayout();saveProgress();invalidate();return true;}
            if(joySizeBtn.contains(x,y)){joystickSize=(joystickSize+1)%3;applyJoystickLayout();saveProgress();invalidate();return true;}
            if(joySensitivityBtn.contains(x,y)){joystickSensitivity=(joystickSensitivity+1)%3;saveProgress();invalidate();return true;}
            if(joyStyleBtn.contains(x,y)){joystickStyle=(joystickStyle+1)%3;saveProgress();invalidate();return true;}
            if(qualityBtn.contains(x,y)){graphicsQuality=(graphicsQuality+1)%3;saveProgress();rebuildArenaBitmap((int)W,(int)H);invalidate();return true;}
            if(resetSettingsBtn.contains(x,y)){resetVisualSettings();saveProgress();rebuildArenaBitmap((int)W,(int)H);invalidate();return true;}
            if(creatorMode&&creatorCodePanel.contains(x,y)){screen=Screen.ADMIN;invalidate();return true;}
            for(int i=0;i<colorSettingRects.length;i++)if(colorSettingRects[i].contains(x,y)){
                int dir=x<colorSettingRects[i].centerX()?-1:1;
                cycleColorSetting(i,dir);
                saveProgress();
                if(i==0||i==6)rebuildArenaBitmap((int)W,(int)H);
                invalidate();return true;
            }
            return true;
        }

        if(screen==Screen.ADMIN&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){screen=Screen.SETTINGS;invalidate();return true;}
            if(!creatorMode){screen=Screen.HOME;invalidate();return true;}
            if(adminActionBtns[0].contains(x,y)){coins+=1000;saveProgress();invalidate();return true;}
            if(adminActionBtns[1].contains(x,y)){for(int i=0;i<unlocked.length;i++)unlocked[i]=true;for(int i=0;i<accessoryOwned.length;i++)accessoryOwned[i]=true;saveProgress();invalidate();return true;}
            if(adminActionBtns[2].contains(x,y)){adminGodMode=!adminGodMode;saveProgress();invalidate();return true;}
            if(adminActionBtns[3].contains(x,y)){adminTurboCooldown=!adminTurboCooldown;saveProgress();invalidate();return true;}
            if(adminActionBtns[4].contains(x,y)){adminDoubleDamage=!adminDoubleDamage;saveProgress();invalidate();return true;}
            if(adminActionBtns[5].contains(x,y)){adminFreezeBot=!adminFreezeBot;saveProgress();invalidate();return true;}
            if(adminActionBtns[6].contains(x,y)){adminGodMode=false;adminTurboCooldown=false;adminDoubleDamage=false;adminFreezeBot=false;saveProgress();invalidate();return true;}
            return true;
        }

        if(screen!=Screen.BATTLE)return true;
        if(matchOver&&action==MotionEvent.ACTION_DOWN){
            if(gameMode!=GameMode.ONLINE&&againBtn.contains(x,y)){playerScore=0;botScore=0;matchOver=false;rewardGranted=false;lastReward=0;startRound();invalidate();return true;}
            if(menuBtn.contains(x,y)){if(gameMode==GameMode.ONLINE)closeOnline(true);else screen=Screen.HOME;resetJoystick();invalidate();return true;}
            return true;
        }

        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            int id=e.getPointerId(index);
            if(gameMode==GameMode.TWO_PLAYER){
                if(x<W*0.50f && joystickPointerId==-1 && y>H*0.40f){joystickPointerId=id;updateJoystick(x,y);}
                else if(x>=W*0.50f && joystick2PointerId==-1 && y>H*0.40f){joystick2PointerId=id;updateJoystick2(x,y);}
            }else{
                boolean inSide=joystickSide==0?x<W*0.48f:x>W*0.52f;
                if(joystickPointerId==-1&&inSide&&y>H*0.42f){joystickPointerId=id;updateJoystick(x,y);}
            }
        }else if(action==MotionEvent.ACTION_MOVE){
            if(joystickPointerId!=-1){int idx=e.findPointerIndex(joystickPointerId);if(idx>=0)updateJoystick(e.getX(idx),e.getY(idx));}
            if(gameMode==GameMode.TWO_PLAYER&&joystick2PointerId!=-1){int idx=e.findPointerIndex(joystick2PointerId);if(idx>=0)updateJoystick2(e.getX(idx),e.getY(idx));}
        }else if(action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_UP){
            int id=e.getPointerId(index);if(id==joystickPointerId)resetJoystick();if(id==joystick2PointerId)resetJoystick2();
        }else if(action==MotionEvent.ACTION_CANCEL){resetJoystick();resetJoystick2();}
        return true;
    }

    private void chooseRandomUnlocked(){
        List<Ability> pool=new ArrayList<>();Ability[] a=Ability.values();for(int i=0;i<a.length;i++)if(isAbilityAvailable(i))pool.add(a[i]);
        if(!pool.isEmpty()){selectedAbility=pool.get(rng.nextInt(pool.size()));saveProgress();}
    }

    private void updateJoystick(float x,float y){
        float dx=x-joyCx,dy=y-joyCy,len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>joyRadius&&len>0){dx=dx/len*joyRadius;dy=dy/len*joyRadius;}
        float sensitivity=joystickSensitivity==0?0.84f:joystickSensitivity==1?1.0f:1.16f;
        joyX=clamp(dx/joyRadius*sensitivity,-1,1);joyY=clamp(dy/joyRadius*sensitivity,-1,1);
    }
    private void updateJoystick2(float x,float y){
        float dx=x-joy2Cx,dy=y-joy2Cy,len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>joy2Radius&&len>0){dx=dx/len*joy2Radius;dy=dy/len*joy2Radius;}
        float sensitivity=joystickSensitivity==0?0.84f:joystickSensitivity==1?1.0f:1.16f;
        joy2X=clamp(dx/joy2Radius*sensitivity,-1,1);joy2Y=clamp(dy/joy2Radius*sensitivity,-1,1);
    }
    private void resetJoystick(){joystickPointerId=-1;joyX=0f;joyY=0f;jumpCharge=0f;jumpLatched=false;}
    private void resetJoystick2(){joystick2PointerId=-1;joy2X=0f;joy2Y=0f;jump2Charge=0f;jump2Latched=false;}
}
