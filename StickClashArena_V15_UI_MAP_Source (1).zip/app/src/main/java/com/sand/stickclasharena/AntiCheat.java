package com.sand.stickclasharena;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;

/**
 * Client-side anti-tamper helpers for Stick Clash Arena.
 * Android Keystore HMAC makes casual SharedPreferences editing detectable.
 * This is defense-in-depth; serious competitive protection still needs an
 * authoritative remote game server.
 */
final class AntiCheat {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String SAVE_KEY_ALIAS = "sca_progress_hmac_v1";
    private static final String HMAC = "HmacSHA256";
    private static final String FALLBACK_PEPPER = "SCA_V14_PROGRESS_GUARD_2026";

    private AntiCheat() {}

    static String signProgress(Context context, String payload) {
        if (payload == null) payload = "";
        try {
            return signWithKeystore(payload);
        } catch (Exception ignored) {
            return signFallback(context, payload);
        }
    }

    static boolean verifyProgress(Context context, String payload, String signature) {
        if (payload == null) payload = "";
        if (signature == null || signature.isEmpty()) return false;
        try {
            String expected;
            if (signature.startsWith("K1:")) expected = signWithKeystore(payload);
            else if (signature.startsWith("F1:")) expected = signFallback(context, payload);
            else return false;
            return constantTimeEquals(expected, signature);
        } catch (Exception ignored) {
            // If a Keystore-backed signature exists but the Keystore is temporarily
            // unavailable, do not treat that temporary platform failure as tampering.
            return signature.startsWith("K1:");
        }
    }

    private static String signWithKeystore(String payload) throws Exception {
        SecretKey key = getOrCreateSaveKey();
        Mac mac = Mac.getInstance(HMAC);
        mac.init(key);
        byte[] out = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
        return "K1:" + Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private static String signFallback(Context context, String payload) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String packageName = context == null ? "unknown" : context.getPackageName();
            byte[] out = md.digest((FALLBACK_PEPPER + "|" + packageName + "|" + payload)
                    .getBytes(StandardCharsets.UTF_8));
            return "F1:" + Base64.encodeToString(out, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private static SecretKey getOrCreateSaveKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE);
        keyStore.load(null);
        KeyStore.Entry existing = keyStore.getEntry(SAVE_KEY_ALIAS, null);
        if (existing instanceof KeyStore.SecretKeyEntry) {
            return ((KeyStore.SecretKeyEntry) existing).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, KEYSTORE);
        generator.init(new KeyGenParameterSpec.Builder(
                SAVE_KEY_ALIAS,
                KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build());
        return generator.generateKey();
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        byte[] aa = a.getBytes(StandardCharsets.UTF_8);
        byte[] bb = b.getBytes(StandardCharsets.UTF_8);
        if (aa.length != bb.length) return false;
        int diff = 0;
        for (int i = 0; i < aa.length; i++) diff |= aa[i] ^ bb[i];
        return diff == 0;
    }
}
