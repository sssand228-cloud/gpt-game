# V14 SECURE OVERDRIVE

- Android Keystore HMAC для защиты прогресса.
- Миграция сохранений V13 -> V14.
- Автовосстановление экономики при повреждении/подмене подписанного сохранения.
- Online protocol 14.
- Session token для каждого онлайн-боя.
- Sequence guard для input/state пакетов.
- Host-authoritative online сохранён и усилен.
- Валидация fighter/shot/state/result пакетов.
- Защита от NaN/Infinity и невозможных параметров.
- Ограничение размера и частоты сетевых сообщений.
- Несколько нарушений -> разрыв соединения.
- Anti-Cheat статус в настройках и online-экране.
