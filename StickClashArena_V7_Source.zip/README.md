# Stick Clash Arena V7

Version 0.7.0

## V7 Creator System
- Adds a safe local Creator device/install code in Settings. It does not use IMEI or the phone serial number.
- The first V7 launch generates a code like XXXX-XXXX-XXXX and stores it in the game's local preferences.
- Creator Mode is activated only when that code is added to the whitelist in a later build.
- Creator privileges when active:
  - all 15 abilities can be selected without buying them;
  - balance is raised to at least 9999 coins on launch;
  - solo victory rewards are doubled;
  - solo attack cooldowns recover 20% faster;
  - solo incoming damage is reduced by 18%;
  - a gold CREATOR badge appears in the menu.
- Combat advantages are disabled in local 2-player mode so 2P stays fair.
- Permanent weapon ownership from V4/V5/V6 is preserved.
- One fight is still exactly one round.
- Existing shop, bot difficulties, arenas, colors and joystick settings remain.

After installing V7, open Settings and send the displayed device code to whitelist that installation in V7.1.
