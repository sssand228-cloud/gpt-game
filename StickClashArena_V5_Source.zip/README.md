# Stick Clash Arena V5

Version 0.5.0

## V5 changes
- 15 weapons now have distinct held models and distinct projectile/effect visuals.
- Weapon damage and cooldown values were rebalanced so the arsenal stays roughly competitive while preserving unique mechanics.
- New Settings screen.
- Change all colors at once or change player, bot, UI, joystick, projectiles, and arena colors separately.
- Joystick can be moved left/right, resized, sensitivity changed, and switched between 3 visual styles.
- Existing V4 coins, unlocked weapons, selected weapon, and difficulty are preserved through the same SharedPreferences store.
- Optimized cached arena rendering from V4 is retained.
