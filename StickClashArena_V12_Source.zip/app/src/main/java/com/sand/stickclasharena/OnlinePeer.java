package com.sand.stickclasharena;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * V10 phone-host transport.
 * The host Android phone is authoritative and listens on one TCP port.
 * A short per-session room code is required before gameplay packets are accepted.
 * The endpoint can be a LAN IP, a public IPv6 address, or a tunnel hostname.
 */
final class OnlinePeer {
    interface Listener {
        void onStatus(String status);
        void onConnected(boolean host);
        void onMessage(String message);
        void onDisconnected(String reason);
    }

    static final class DiscoveredRoom {
        final String host;
        final String code;
        final String title;
        DiscoveredRoom(String host, String code, String title) {
            this.host = host; this.code = code; this.title = title;
        }
        @Override public String toString() {
            return title + "\n" + host + " • код " + code;
        }
    }

    static final int DEFAULT_PORT = 27654;
    static final int DISCOVERY_PORT = 27655;
    static final int RELAY_PORT = 27656;
    private static final int MAX_LINE = 8192;
    private static final int HANDSHAKE_TIMEOUT_MS = 12000;
    private static final int GAME_TIMEOUT_MS = 45000;
    private static final int MAX_MESSAGES_PER_SECOND = 200;
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final Listener listener;
    private volatile boolean closed = true;
    private volatile boolean connected = false;
    private ServerSocket serverSocket;
    private Socket socket;
    private DatagramSocket discoverySocket;
    private BufferedWriter writer;
    private Thread worker;
    private Thread sender;
    private Thread discoveryWorker;
    private final LinkedBlockingQueue<String> outgoing = new LinkedBlockingQueue<>(256);

    OnlinePeer(Listener listener) {
        this.listener = listener;
    }

    boolean isConnected() { return connected; }

    static String newRoomCode() {
        return String.format(java.util.Locale.US, "%06d", 100000 + SECURE_RANDOM.nextInt(900000));
    }

    synchronized void startHost(final int port, final String roomCode) {
        close();
        closed = false;
        listener.onStatus("СЕРВЕР ЗАПУЩЕН • ЖДУ ИГРОКА");
        worker = new Thread(() -> {
            try {
                serverSocket = new ServerSocket();
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress(port));
                startDiscoveryResponder(port, roomCode);
                Socket accepted = serverSocket.accept();
                if (closed) { accepted.close(); return; }
                accepted.setTcpNoDelay(true);
                accepted.setKeepAlive(true);
                accepted.setSoTimeout(HANDSHAKE_TIMEOUT_MS);

                BufferedReader reader = new BufferedReader(new InputStreamReader(accepted.getInputStream(), "UTF-8"));
                BufferedWriter preparedWriter = new BufferedWriter(new OutputStreamWriter(accepted.getOutputStream(), "UTF-8"));
                String hello = readLineLimited(reader);
                String expected = "HELLO " + normalizeCode(roomCode);
                if (!expected.equals(hello)) {
                    preparedWriter.write("DENY\n");
                    preparedWriter.flush();
                    accepted.close();
                    listener.onStatus("НЕВЕРНЫЙ КОД • ЖДУ СНОВА");
                    if (!closed) startHost(port, roomCode);
                    return;
                }
                preparedWriter.write("OK\n");
                preparedWriter.flush();
                attachPrepared(accepted, true, reader, preparedWriter);
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-phone-host");
        worker.start();
    }

    synchronized void join(final String host, final int port, final String roomCode) {
        close();
        closed = false;
        listener.onStatus("ПОДКЛЮЧЕНИЕ К " + host);
        worker = new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(cleanHost(host), port), 9000);
                if (closed) { s.close(); return; }
                s.setTcpNoDelay(true);
                s.setKeepAlive(true);
                s.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
                BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                BufferedWriter preparedWriter = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));
                preparedWriter.write("HELLO " + normalizeCode(roomCode));
                preparedWriter.write('\n');
                preparedWriter.flush();
                String reply = readLineLimited(reader);
                if (!"OK".equals(reply)) throw new IOException("НЕВЕРНЫЙ КОД КОМНАТЫ");
                attachPrepared(s, false, reader, preparedWriter);
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-phone-join");
        worker.start();
    }

    synchronized void startRelayHost(final String relayHost, final int relayPort, final String roomCode) {
        close(); closed=false; listener.onStatus("GLOBAL RELAY • ПОДКЛЮЧЕНИЕ");
        worker=new Thread(() -> {
            try {
                Socket s=new Socket();s.connect(new InetSocketAddress(cleanHost(relayHost),relayPort),10000);if(closed){s.close();return;}
                s.setTcpNoDelay(true);s.setKeepAlive(true);s.setSoTimeout(180000);
                BufferedReader reader=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8"));
                BufferedWriter preparedWriter=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8"));
                preparedWriter.write("HOST "+normalizeCode(roomCode)+"\n");preparedWriter.flush();
                String reply=readLineLimited(reader);
                if("WAIT".equals(reply)){listener.onStatus("GLOBAL КОМНАТА "+normalizeCode(roomCode)+" • ЖДУ ИГРОКА");reply=readLineLimited(reader);}
                if(!"OK".equals(reply))throw new IOException(reply==null?"RELAY ЗАКРЫЛ СОЕДИНЕНИЕ":reply);
                attachPrepared(s,true,reader,preparedWriter);
            } catch(Exception e){if(!closed)listener.onDisconnected(shortReason(e));closeQuietly();}
        },"sca-relay-host");worker.start();
    }

    synchronized void joinRelay(final String relayHost, final int relayPort, final String roomCode) {
        close(); closed=false; listener.onStatus("GLOBAL RELAY • ВХОД В "+normalizeCode(roomCode));
        worker=new Thread(() -> {
            try {
                Socket s=new Socket();s.connect(new InetSocketAddress(cleanHost(relayHost),relayPort),10000);if(closed){s.close();return;}
                s.setTcpNoDelay(true);s.setKeepAlive(true);s.setSoTimeout(30000);
                BufferedReader reader=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8"));
                BufferedWriter preparedWriter=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8"));
                preparedWriter.write("JOIN "+normalizeCode(roomCode)+"\n");preparedWriter.flush();
                String reply=readLineLimited(reader);if(!"OK".equals(reply))throw new IOException(reply==null?"КОМНАТА НЕ НАЙДЕНА":reply);
                attachPrepared(s,false,reader,preparedWriter);
            } catch(Exception e){if(!closed)listener.onDisconnected(shortReason(e));closeQuietly();}
        },"sca-relay-join");worker.start();
    }

    private void attachPrepared(Socket s, boolean host, BufferedReader reader, BufferedWriter preparedWriter) throws Exception {
        socket = s;
        socket.setSoTimeout(GAME_TIMEOUT_MS);
        writer = preparedWriter;
        connected = true;
        outgoing.clear();

        sender = new Thread(() -> {
            try {
                while (!closed && connected) {
                    String message = outgoing.poll(1, TimeUnit.SECONDS);
                    if (message == null) continue;
                    if (message.length() > MAX_LINE) continue;
                    synchronized (OnlinePeer.this) {
                        if (writer == null) continue;
                        writer.write(message);
                        writer.write('\n');
                        writer.flush();
                    }
                }
            } catch (Exception e) {
                if (!closed) listener.onDisconnected(shortReason(e));
                closeQuietly();
            }
        }, "sca-online-send");
        sender.start();

        listener.onConnected(host);
        long rateWindow = System.currentTimeMillis();
        int rateCount = 0;
        try {
            while (!closed) {
                String line = readLineLimited(reader);
                if (line == null) break;
                long now = System.currentTimeMillis();
                if (now - rateWindow >= 1000L) { rateWindow = now; rateCount = 0; }
                if (++rateCount > MAX_MESSAGES_PER_SECOND) throw new IOException("СЛИШКОМ МНОГО ПАКЕТОВ");
                if (!line.isEmpty()) listener.onMessage(line);
            }
        } catch (SocketTimeoutException e) {
            if (!closed) listener.onDisconnected("ТАЙМАУТ СОЕДИНЕНИЯ");
        }
        if (!closed) listener.onDisconnected("СОЕДИНЕНИЕ ЗАКРЫТО");
        closeQuietly();
    }

    private synchronized void startDiscoveryResponder(final int gamePort, final String roomCode) {
        try { if (discoverySocket != null) discoverySocket.close(); } catch (Exception ignored) {}
        discoveryWorker = new Thread(() -> {
            try {
                discoverySocket = new DatagramSocket(DISCOVERY_PORT);
                discoverySocket.setBroadcast(true);
                discoverySocket.setSoTimeout(1000);
                byte[] buf = new byte[256];
                while (!closed) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    try {
                        discoverySocket.receive(packet);
                    } catch (java.net.SocketTimeoutException e) {
                        continue;
                    }
                    String msg = new String(packet.getData(), 0, packet.getLength(), java.nio.charset.StandardCharsets.UTF_8).trim();
                    if (!msg.startsWith("SCA_DISCOVER")) continue;
                    String title = "Stick Clash Arena • " + roomCode;
                    String reply = "SCA_ROOM|" + normalizeCode(roomCode) + "|" + title + "|" + gamePort;
                    byte[] out = reply.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    DatagramPacket response = new DatagramPacket(out, out.length, packet.getAddress(), packet.getPort());
                    discoverySocket.send(response);
                }
            } catch (SocketException ignored) {
            } catch (Exception ignored) {
            } finally {
                try { if (discoverySocket != null) discoverySocket.close(); } catch (Exception ignored) {}
            }
        }, "sca-discovery-host");
        discoveryWorker.start();
    }

    static List<DiscoveredRoom> discoverLan(int timeoutMs) {
        List<DiscoveredRoom> result = new ArrayList<>();
        DatagramSocket ds = null;
        try {
            ds = new DatagramSocket();
            ds.setBroadcast(true);
            ds.setSoTimeout(Math.max(250, timeoutMs));
            byte[] query = "SCA_DISCOVER".getBytes(java.nio.charset.StandardCharsets.UTF_8);
            DatagramPacket packet = new DatagramPacket(query, query.length, java.net.InetAddress.getByName("255.255.255.255"), DISCOVERY_PORT);
            ds.send(packet);
            long end = System.currentTimeMillis() + timeoutMs;
            byte[] buf = new byte[512];
            while (System.currentTimeMillis() < end) {
                DatagramPacket reply = new DatagramPacket(buf, buf.length);
                try {
                    ds.receive(reply);
                } catch (java.net.SocketTimeoutException e) {
                    break;
                }
                String line = new String(reply.getData(), 0, reply.getLength(), java.nio.charset.StandardCharsets.UTF_8).trim();
                if (!line.startsWith("SCA_ROOM|")) continue;
                String[] parts = line.split("\\|", 4);
                if (parts.length < 4) continue;
                String code = normalizeCode(parts[1]);
                String title = parts[2];
                String host = reply.getAddress().getHostAddress();
                boolean exists = false;
                for (DiscoveredRoom r : result) { if (r.host.equals(host) && r.code.equals(code)) { exists = true; break; } }
                if (!exists) result.add(new DiscoveredRoom(host, code, title));
            }
        } catch (Exception ignored) {
        } finally {
            if (ds != null) ds.close();
        }
        return result;
    }

    void send(String message) {
        if (!connected || message == null || message.length() > MAX_LINE) return;
        if (!outgoing.offer(message)) {
            outgoing.poll();
            outgoing.offer(message);
        }
    }

    synchronized void close() {
        closed = true;
        connected = false;
        closeQuietly();
    }

    private synchronized void closeQuietly() {
        connected = false;
        try { if (writer != null) writer.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        try { if (discoverySocket != null) discoverySocket.close(); } catch (Exception ignored) {}
        writer = null;
        socket = null;
        serverSocket = null;
        discoverySocket = null;
        outgoing.clear();
    }

    static String localIpv4Address() {
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                for (InetAddress address : Collections.list(nif.getInetAddresses())) {
                    if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                        String ip = address.getHostAddress();
                        if (ip != null && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) return ip;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "IP НЕ НАЙДЕН";
    }

    static String globalIpv6Address() {
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                for (InetAddress address : Collections.list(nif.getInetAddresses())) {
                    if (address instanceof Inet6Address && !address.isLoopbackAddress()
                            && !address.isLinkLocalAddress() && !address.isSiteLocalAddress()
                            && !address.isMulticastAddress()) {
                        String ip = address.getHostAddress();
                        if (ip != null) {
                            int scope = ip.indexOf('%');
                            return scope > 0 ? ip.substring(0, scope) : ip;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return "НЕТ";
    }

    private static String normalizeCode(String code) {
        if (code == null) return "";
        return code.replaceAll("[^0-9A-Za-z]", "").toUpperCase(java.util.Locale.US);
    }

    private static String cleanHost(String host) {
        if (host == null) return "";
        String h = host.trim();
        if (h.startsWith("[") && h.endsWith("]") && h.length() > 2) h = h.substring(1, h.length()-1);
        return h;
    }

    private static String readLineLimited(BufferedReader reader) throws IOException {
        StringBuilder b = new StringBuilder(256);
        while (true) {
            int ch = reader.read();
            if (ch < 0) return b.length() == 0 ? null : b.toString();
            if (ch == '\n') return b.toString();
            if (ch == '\r') continue;
            if (b.length() >= MAX_LINE) throw new IOException("ПАКЕТ СЛИШКОМ БОЛЬШОЙ");
            b.append((char) ch);
        }
    }

    private static String shortReason(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return "ОШИБКА СЕТИ";
        m = m.replace('\n', ' ').replace('\r', ' ');
        return m.length() > 64 ? m.substring(0, 64) : m;
    }
}
