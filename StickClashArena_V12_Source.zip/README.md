# Stick Clash Arena V11.0 — GLOBAL UPDATE

- Полностью переработанное асимметричное меню, функционал сохранён.
- 20 оружий: + Plasma Spear, Sonic Hammer, Void Chain, Meteor Cannon, Storm Ring.
- Для каждого нового оружия отдельная модель/иконка, параметры атаки и оригинальный WAV-звук.
- Онлайн разделён на LAN и GLOBAL Relay. LAN работает в одной Wi-Fi сети. GLOBAL не использует IP другого игрока, но требует внешний relay-сервер.
- В `relay-server/` лежит готовый Node.js TCP relay.
