# Stick Clash Arena V4

Global update:
- Main menu
- Persistent coins
- Bot difficulty: Easy / Medium / Hard
- Win rewards: 5 / 7 / 15 coins
- Armory before battle
- Random unlocked weapon button
- Shop
- 15 different weapons
- First 5 unlocked, 10 purchasable
- Right-side joystick
- No weapon switching during battle
- Performance optimizations preserved
