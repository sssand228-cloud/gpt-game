package com.openai.stickclasharena;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends View implements Runnable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final List<Shot> shots = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private static final int MAX_SHOTS = 56;
    private static final int MAX_PARTICLES = 110;

    private final SharedPreferences prefs;

    private Bitmap arenaBitmap;
    private float W, H, groundY;
    private boolean running;
    private long lastNs;
    private static final long UPDATE_STEP_NS = 16_000_000L;

    private enum Screen { HOME, ARMORY, SHOP, BATTLE }
    private Screen screen = Screen.HOME;

    private enum Difficulty {
        EASY("ЛЕГКО", 5),
        MEDIUM("СРЕДНЕ", 7),
        HARD("СЛОЖНО", 15);
        final String title;
        final int reward;
        Difficulty(String title, int reward) { this.title = title; this.reward = reward; }
    }

    enum Ability {
        ENERGY_ORB("ЭНЕРГОСФЕРА", "Быстрый энергетический шар", 0),
        BOUNCE_DISC("РИКОШЕТ-ДИСК", "Отскакивает от пола и стен", 0),
        HEAVY_GLOVE("ТЯЖЕЛЫЙ УДАР", "Мощная атака вблизи", 0),
        GRAVITY_BURST("ГРАВИ-ВЗРЫВ", "Отбрасывает врага вокруг тебя", 0),
        ARC_CORE("ДУГА-ЯДРО", "Тяжелый снаряд летит по дуге", 0),
        TRIPLE_SPARK("ТРОЙНАЯ ИСКРА", "Три быстрых снаряда веером", 25),
        SHIELD_PULSE("ИМПУЛЬС-ЩИТ", "Временно сильно снижает урон", 35),
        DASH_CORE("РЫВОК-ЯДРО", "Рывок вперед с ударом", 45),
        FROST_SHARD("ЛЕДЯНОЙ ОСКОЛОК", "Попадание замедляет врага", 60),
        LASER_BEAM("ЛАЗЕРНЫЙ ЛУЧ", "Мгновенный дальний луч", 75),
        MINE_CORE("МИНА-ЯДРО", "Оставляет мину на арене", 90),
        RETURN_BLADE("ВОЗВРАТНЫЙ КЛИНОК", "Летит вперед и возвращается", 110),
        SKY_DROP("НЕБЕСНЫЙ УДАР", "Снаряд падает сверху на цель", 130),
        VAMPIRE_BOLT("ПОГЛОТИТЕЛЬ", "Попадание лечит стрелка", 160),
        BLINK_STRIKE("ТЕЛЕПОРТ-УДАР", "Телепорт к врагу и удар", 200);

        final String title;
        final String desc;
        final int price;
        Ability(String title, String desc, int price) {
            this.title = title; this.desc = desc; this.price = price;
        }
    }

    static class Fighter {
        float x, y, vx, vy;
        float radius;
        float hp = 100f;
        float shield = 0f;
        float attackCd = 0f;
        float invuln = 0f;
        float slowTimer = 0f;
        boolean grounded = false;
        int facing = 1;
        Ability ability = Ability.ENERGY_ORB;
        final boolean isBot;
        Fighter(boolean isBot) { this.isBot = isBot; }
    }

    static class Shot {
        float x, y, vx, vy, radius, damage, knockback, life, maxLife;
        int owner;
        int bounces;
        boolean gravity;
        boolean frost;
        boolean healOnHit;
        boolean mine;
        boolean armed;
        float armTimer;
        boolean returning;
        boolean hasReturned;
        Ability source;
        Shot(float x, float y, float vx, float vy, float r, float d, float k, float life, int owner, Ability source) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.radius=r; this.damage=d; this.knockback=k;
            this.life=life; this.maxLife=life; this.owner=owner; this.source=source;
        }
    }

    static class Particle {
        float x, y, vx, vy, life, maxLife, size;
        int color;
        Particle(float x, float y, float vx, float vy, float life, float size, int color) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.life=life; this.maxLife=life; this.size=size; this.color=color;
        }
    }

    private Fighter player, bot;
    private int playerScore = 0, botScore = 0;
    private boolean roundOver = false, matchOver = false;
    private float roundResetTimer = 0f;
    private boolean rewardGranted = false;
    private int lastReward = 0;
    private float botBrainTimer = 0f;

    private int coins = 0;
    private final boolean[] unlocked = new boolean[Ability.values().length];
    private Ability selectedAbility = Ability.ENERGY_ORB;
    private Difficulty difficulty = Difficulty.EASY;

    // Right joystick controls move + aim + jump charge.
    private int joystickPointerId = -1;
    private float joyCx, joyCy, joyRadius, knobRadius;
    private float joyX = 0f, joyY = 0f;
    private float aimX = 1f, aimY = 0f;
    private float jumpCharge = 0f;
    private boolean jumpLatched = false;
    private final RectF jumpArcRect = new RectF();

    // Menu / overlay hitboxes.
    private final RectF playBtn = new RectF();
    private final RectF armoryBtn = new RectF();
    private final RectF randomBtn = new RectF();
    private final RectF shopBtn = new RectF();
    private final RectF backBtn = new RectF();
    private final RectF againBtn = new RectF();
    private final RectF menuBtn = new RectF();
    private final RectF[] difficultyBtns = { new RectF(), new RectF(), new RectF() };
    private final RectF[] itemRects = new RectF[Ability.values().length];

    private final float[] starX = new float[42];
    private final float[] starY = new float[42];
    private final float[] starR = new float[42];

    public GameView(Context context) {
        super(context);
        setKeepScreenOn(true);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setDither(true);
        setBackgroundColor(Color.rgb(8,12,24));
        prefs = context.getSharedPreferences("stick_clash_v4", Context.MODE_PRIVATE);
        loadProgress();
        for (int i=0;i<itemRects.length;i++) itemRects[i] = new RectF();
        for (int i=0;i<starX.length;i++) {
            starX[i]=rng.nextFloat(); starY[i]=rng.nextFloat()*0.58f; starR[i]=0.6f+rng.nextFloat()*1.8f;
        }
    }

    private void loadProgress() {
        coins = prefs.getInt("coins", 0);
        Ability[] a = Ability.values();
        for (int i=0;i<a.length;i++) unlocked[i] = prefs.getBoolean("unlock_"+i, i<5);
        int sel = prefs.getInt("selected", 0);
        if (sel < 0 || sel >= a.length || !unlocked[sel]) sel = 0;
        selectedAbility = a[sel];
        int d = prefs.getInt("difficulty", 0);
        if (d < 0 || d >= Difficulty.values().length) d = 0;
        difficulty = Difficulty.values()[d];
    }

    private void saveProgress() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("coins", coins);
        e.putInt("selected", selectedAbility.ordinal());
        e.putInt("difficulty", difficulty.ordinal());
        for (int i=0;i<unlocked.length;i++) e.putBoolean("unlock_"+i, unlocked[i]);
        e.apply();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        W=w; H=h; groundY=H*0.78f;
        float min=Math.min(W,H);
        joyRadius=min*0.115f; knobRadius=joyRadius*0.42f;
        joyCx=W*0.84f; joyCy=H*0.80f;
        jumpArcRect.set(joyCx-joyRadius*1.12f,joyCy-joyRadius*1.12f,joyCx+joyRadius*1.12f,joyCy+joyRadius*1.12f);
        layoutUi();
        rebuildArenaBitmap(w,h);
        invalidate();
    }

    private void layoutUi() {
        float center=W*0.5f;
        float bigW=W*0.31f, bigH=Math.max(H*0.105f,70f);
        playBtn.set(center-bigW*0.5f,H*0.71f,center+bigW*0.5f,H*0.71f+bigH);
        float smallW=W*0.24f, smallH=Math.max(H*0.087f,58f);
        armoryBtn.set(W*0.10f,H*0.53f,W*0.10f+smallW,H*0.53f+smallH);
        randomBtn.set(W*0.38f,H*0.53f,W*0.38f+smallW,H*0.53f+smallH);
        shopBtn.set(W*0.66f,H*0.53f,W*0.66f+smallW,H*0.53f+smallH);

        float diffW=W*0.20f, gap=W*0.025f, y=H*0.32f, diffH=H*0.12f;
        float total=diffW*3+gap*2;
        float x0=(W-total)*0.5f;
        for(int i=0;i<3;i++) difficultyBtns[i].set(x0+i*(diffW+gap),y,x0+i*(diffW+gap)+diffW,y+diffH);

        backBtn.set(W*0.025f,H*0.035f,W*0.15f,H*0.11f);
        againBtn.set(W*0.30f,H*0.61f,W*0.49f,H*0.71f);
        menuBtn.set(W*0.51f,H*0.61f,W*0.70f,H*0.71f);

        int cols=3, rows=5;
        float left=W*0.08f, right=W*0.92f, top=H*0.20f, bottom=H*0.91f;
        float gapX=W*0.018f, gapY=H*0.018f;
        float cellW=(right-left-gapX*(cols-1))/cols;
        float cellH=(bottom-top-gapY*(rows-1))/rows;
        for(int i=0;i<itemRects.length;i++) {
            int row=i/cols, col=i%cols;
            float x=left+col*(cellW+gapX), yy=top+row*(cellH+gapY);
            itemRects[i].set(x,yy,x+cellW,yy+cellH);
        }
    }

    public void resume() {
        if (running) return;
        running=true; lastNs=System.nanoTime(); postOnAnimation(this);
    }

    public void pause() {
        running=false; removeCallbacks(this);
    }

    @Override public void run() {
        if (!running) return;
        if (screen != Screen.BATTLE) {
            postDelayed(this, 120);
            return;
        }
        long now=System.nanoTime(); long elapsed=now-lastNs;
        if (elapsed>=UPDATE_STEP_NS) {
            float dt=Math.min(0.033f,elapsed/1_000_000_000f);
            lastNs=now; update(dt); invalidate();
        }
        postOnAnimation(this);
    }

    private void startBattle() {
        screen=Screen.BATTLE;
        playerScore=0; botScore=0; matchOver=false; rewardGranted=false; lastReward=0;
        startRound();
        lastNs=System.nanoTime();
        invalidate();
    }

    private void startRound() {
        if(W<=0||H<=0)return;
        float r=Math.max(26f,Math.min(W,H)*0.048f);
        player=new Fighter(false); bot=new Fighter(true);
        player.radius=bot.radius=r;
        player.x=W*0.24f; player.y=groundY-r*1.1f;
        bot.x=W*0.76f; bot.y=groundY-r*1.1f;
        player.facing=1; bot.facing=-1;
        player.ability=selectedAbility;
        bot.ability=randomBotAbility();
        shots.clear(); particles.clear();
        roundOver=false; roundResetTimer=0f; botBrainTimer=0f;
        jumpCharge=0f; jumpLatched=false; resetJoystick();
    }

    private Ability randomBotAbility() {
        int cap = difficulty==Difficulty.EASY ? 5 : difficulty==Difficulty.MEDIUM ? 10 : Ability.values().length;
        return Ability.values()[rng.nextInt(cap)];
    }

    private void update(float dt) {
        if(player==null||bot==null)return;
        updateParticles(dt);
        if(matchOver)return;
        if(roundOver){ roundResetTimer-=dt; if(roundResetTimer<=0f)startRound(); return; }

        updateCooldowns(player,dt); updateCooldowns(bot,dt);

        float slowFactor=player.slowTimer>0?0.58f:1f;
        float dead=0.12f;
        float move=Math.abs(joyX)>dead?joyX:0f;
        float accel=W*1.35f*slowFactor;
        if(move!=0f){
            player.vx+=move*accel*dt;
            if(Math.abs(joyX)>0.18f)player.facing=joyX>=0?1:-1;
        } else player.vx*=Math.max(0f,1f-6.2f*dt);

        float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY);
        if(mag>0.22f){
            aimX=joyX/mag; aimY=joyY/mag;
            if(Math.abs(aimX)>0.16f)player.facing=aimX>=0?1:-1;
            if(player.attackCd<=0f)attack(player,0,aimX,aimY);
        }

        boolean chargingJump=joyY<-0.68f&&mag>0.72f;
        if(chargingJump&&player.grounded&&!jumpLatched){
            jumpCharge+=dt;
            if(jumpCharge>=0.50f){
                player.vy=-H*0.88f; player.grounded=false; jumpCharge=0f; jumpLatched=true;
                burst(player.x,player.y+player.radius,Color.rgb(100,210,255),8,0.5f);
            }
        } else if(!chargingJump){ jumpCharge=0f; jumpLatched=false; }

        updateBot(dt);
        physics(player,dt); physics(bot,dt);
        resolveFighterCollision(); updateShots(dt);
        if(player.hp<=0||bot.hp<=0)endRound();
    }

    private void updateCooldowns(Fighter f,float dt){
        f.attackCd=Math.max(0,f.attackCd-dt); f.shield=Math.max(0,f.shield-dt);
        f.invuln=Math.max(0,f.invuln-dt); f.slowTimer=Math.max(0,f.slowTimer-dt);
    }

    private void physics(Fighter f,float dt){
        f.vy+=H*2.15f*dt;
        float speedCap=W*(f.slowTimer>0?0.32f:0.52f);
        f.vx=clamp(f.vx,-speedCap,speedCap);
        f.x+=f.vx*dt; f.y+=f.vy*dt;
        float r=f.radius;
        if(f.y+r*1.10f>=groundY){f.y=groundY-r*1.10f;if(f.vy>0)f.vy=0;f.grounded=true;}else f.grounded=false;
        if(f.x-r<0){f.x=r;f.vx=Math.abs(f.vx)*0.25f;}
        if(f.x+r>W){f.x=W-r;f.vx=-Math.abs(f.vx)*0.25f;}
    }

    private void resolveFighterCollision(){
        float dx=bot.x-player.x,dy=bot.y-player.y,dist=(float)Math.sqrt(dx*dx+dy*dy),min=player.radius+bot.radius;
        if(dist>0&&dist<min){float nx=dx/dist,ov=min-dist;player.x-=nx*ov*0.5f;bot.x+=nx*ov*0.5f;}
    }

    private void updateBot(float dt){
        botBrainTimer-=dt;
        if(botBrainTimer>0)return;
        float reaction=difficulty==Difficulty.EASY?0.28f:difficulty==Difficulty.MEDIUM?0.13f:0.055f;
        botBrainTimer=reaction*(0.8f+rng.nextFloat()*0.4f);

        float dx=player.x-bot.x,dy=player.y-bot.y,adx=Math.abs(dx);
        bot.facing=dx>=0?1:-1;
        boolean danger=false;
        for(Shot s:shots){
            if(s.owner==1)continue;
            float sx=s.x-bot.x,sy=s.y-bot.y;
            if(Math.abs(sy)<bot.radius*2.8f&&Math.abs(sx)<W*0.24f){danger=true;break;}
        }

        float dodgeChance=difficulty==Difficulty.EASY?0.10f:difficulty==Difficulty.MEDIUM?0.36f:0.78f;
        if(danger&&bot.grounded&&rng.nextFloat()<dodgeChance)bot.vy=-H*(difficulty==Difficulty.HARD?0.88f:0.78f);

        float movePower=difficulty==Difficulty.EASY?0.65f:difficulty==Difficulty.MEDIUM?0.92f:1.18f;
        float desiredMin=W*(difficulty==Difficulty.HARD?0.16f:0.19f), desiredMax=W*0.34f;
        float slow=bot.slowTimer>0?0.58f:1f;
        if(adx>desiredMax)bot.vx+=Math.signum(dx)*W*movePower*slow*reaction;
        else if(adx<desiredMin)bot.vx-=Math.signum(dx)*W*movePower*0.85f*slow*reaction;
        else bot.vx*=0.72f;

        if(bot.attackCd<=0f){
            if(rng.nextFloat()<(difficulty==Difficulty.EASY?0.50f:difficulty==Difficulty.MEDIUM?0.80f:0.98f)){
                if(difficulty==Difficulty.HARD&&danger&&rng.nextFloat()<0.30f)bot.ability=Ability.SHIELD_PULSE;
                else if(rng.nextFloat()<0.22f)bot.ability=randomBotAbility();
                float len=(float)Math.sqrt(dx*dx+dy*dy);if(len<1)len=1;
                float ax=dx/len,ay=dy/len;
                float err=difficulty==Difficulty.EASY?0.20f:difficulty==Difficulty.MEDIUM?0.075f:0.022f;
                float angle=(float)Math.atan2(ay,ax)+(rng.nextFloat()*2f-1f)*err;
                attack(bot,1,(float)Math.cos(angle),(float)Math.sin(angle));
            }
        }
        if(bot.grounded&&adx<W*0.22f&&rng.nextFloat()<(difficulty==Difficulty.HARD?0.16f:0.05f))bot.vy=-H*0.75f;
    }

    private void attack(Fighter f,int owner,float ax,float ay){
        if(f.attackCd>0||roundOver)return;
        Fighter target=owner==0?bot:player;
        float len=(float)Math.sqrt(ax*ax+ay*ay);if(len<0.001f){ax=f.facing;ay=0;len=1;}ax/=len;ay/=len;
        if(Math.abs(ax)>0.12f)f.facing=ax>=0?1:-1;
        float baseSpeed=W*0.64f, sx=f.x+ax*f.radius*1.35f, sy=f.y+ay*f.radius*0.9f-f.radius*0.12f;
        int fx=owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135);

        switch(f.ability){
            case ENERGY_ORB:{addShot(new Shot(sx,sy,ax*baseSpeed,ay*baseSpeed,f.radius*0.33f,14,0.32f,2.2f,owner,f.ability));f.attackCd=0.38f;break;}
            case BOUNCE_DISC:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.78f,ay*baseSpeed*0.78f,f.radius*0.42f,12,0.42f,3.2f,owner,f.ability);s.bounces=4;s.gravity=true;addShot(s);f.attackCd=0.55f;break;}
            case HEAVY_GLOVE:{float reach=f.radius*2.8f;float tx=target.x-f.x,ty=target.y-f.y,tlen=(float)Math.sqrt(tx*tx+ty*ty);if(tlen<1)tlen=1;float dot=(tx/tlen)*ax+(ty/tlen)*ay;if(tlen<reach&&dot>0.35f)damage(target,26,ax*W*0.42f,ay*H*0.20f-H*0.10f,fx);f.attackCd=0.72f;break;}
            case GRAVITY_BURST:{if(distance(f,target)<f.radius*4.2f){float d=Math.signum(target.x-f.x);if(d==0)d=1;damage(target,18,d*W*0.55f,-H*0.32f,fx);}burst(f.x,f.y,fx,16,0.75f);f.attackCd=0.95f;break;}
            case ARC_CORE:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.90f,ay*baseSpeed*0.90f,f.radius*0.31f,17,0.38f,2.2f,owner,f.ability);s.gravity=true;addShot(s);f.attackCd=0.66f;break;}
            case TRIPLE_SPARK:{float angle=(float)Math.atan2(ay,ax);for(int i=-1;i<=1;i++){float a=angle+i*0.13f,dx=(float)Math.cos(a),dy=(float)Math.sin(a);addShot(new Shot(f.x+dx*f.radius*1.3f,f.y+dy*f.radius*0.9f,dx*baseSpeed*0.84f,dy*baseSpeed*0.84f,f.radius*0.22f,8,0.18f,1.8f,owner,f.ability));}f.attackCd=0.62f;break;}
            case SHIELD_PULSE:{f.shield=1.45f;f.attackCd=1.25f;burst(f.x,f.y,fx,12,0.55f);break;}
            case DASH_CORE:{f.vx=ax*W*0.72f;f.vy+=ay*H*0.35f;f.invuln=0.18f;if(distance(f,target)<f.radius*3.2f)damage(target,16,ax*W*0.48f,ay*H*0.22f-H*0.08f,fx);f.attackCd=0.82f;break;}
            case FROST_SHARD:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.72f,ay*baseSpeed*0.72f,f.radius*0.30f,11,0.20f,2.4f,owner,f.ability);s.frost=true;addShot(s);f.attackCd=0.58f;break;}
            case LASER_BEAM:{
                float tx=target.x-f.x,ty=target.y-f.y,tlen=(float)Math.sqrt(tx*tx+ty*ty);if(tlen<1)tlen=1;
                float dot=(tx/tlen)*ax+(ty/tlen)*ay;
                if(dot>0.94f&&tlen<W*0.78f)damage(target,19,ax*W*0.25f,ay*H*0.10f,fx);
                burst(f.x+ax*f.radius*1.5f,f.y+ay*f.radius,fx,7,0.35f);f.attackCd=0.82f;break;
            }
            case MINE_CORE:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.44f,ay*baseSpeed*0.44f-H*0.08f,f.radius*0.42f,24,0.60f,5.5f,owner,f.ability);s.gravity=true;s.mine=true;s.armTimer=0.55f;addShot(s);f.attackCd=1.15f;break;}
            case RETURN_BLADE:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.75f,ay*baseSpeed*0.75f,f.radius*0.36f,13,0.30f,2.6f,owner,f.ability);s.returning=true;addShot(s);f.attackCd=0.70f;break;}
            case SKY_DROP:{float dropX=clamp(target.x+ax*target.radius*0.4f,target.radius,W-target.radius);Shot s=new Shot(dropX,-f.radius*2f,0,H*0.82f,f.radius*0.40f,23,0.45f,2.2f,owner,f.ability);addShot(s);f.attackCd=1.05f;break;}
            case VAMPIRE_BOLT:{Shot s=new Shot(sx,sy,ax*baseSpeed*0.66f,ay*baseSpeed*0.66f,f.radius*0.30f,12,0.20f,2.5f,owner,f.ability);s.healOnHit=true;addShot(s);f.attackCd=0.62f;break;}
            case BLINK_STRIKE:{
                float oldX=f.x,oldY=f.y;
                float dir=Math.abs(ax)>0.15f?Math.signum(ax):f.facing;
                f.x=clamp(target.x-dir*f.radius*1.6f,f.radius,W-f.radius);f.y=target.y;f.invuln=0.22f;
                if(distance(f,target)<f.radius*2.4f)damage(target,21,dir*W*0.46f,-H*0.12f,fx);
                burst(oldX,oldY,fx,8,0.4f);burst(f.x,f.y,fx,10,0.5f);f.attackCd=1.08f;break;
            }
        }
    }

    private void addShot(Shot shot){if(shots.size()>=MAX_SHOTS)shots.remove(0);shots.add(shot);}

    private void updateShots(float dt){
        Iterator<Shot> it=shots.iterator();
        while(it.hasNext()){
            Shot s=it.next();s.life-=dt;
            if(s.returning&&!s.hasReturned&&s.life<s.maxLife*0.48f){s.vx*=-1f;s.vy*=-1f;s.hasReturned=true;}
            if(s.mine){
                s.armTimer-=dt;if(s.armTimer<=0)s.armed=true;
                if(!s.armed&&s.gravity)s.vy+=H*1.22f*dt;
                if(s.y+s.radius>=groundY){s.y=groundY-s.radius;s.vx*=0.45f;s.vy=0;s.gravity=false;}
            } else if(s.gravity)s.vy+=H*1.22f*dt;
            s.x+=s.vx*dt;s.y+=s.vy*dt;

            if(s.bounces>0){
                boolean bounced=false;
                if(s.x-s.radius<0||s.x+s.radius>W){s.vx*=-0.82f;s.x=clamp(s.x,s.radius,W-s.radius);bounced=true;}
                if(s.y+s.radius>groundY){s.vy=-Math.abs(s.vy)*0.72f;s.y=groundY-s.radius;bounced=true;}
                if(bounced){s.bounces--;burst(s.x,s.y,s.owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135),4,0.28f);}
            }

            Fighter target=s.owner==0?bot:player;
            float dx=s.x-target.x,dy=s.y-target.y;
            float hitR=s.radius+target.radius;
            boolean hit=dx*dx+dy*dy<hitR*hitR;
            if(s.mine&&s.armed){
                float trigger=target.radius*2.7f+s.radius;
                hit=dx*dx+dy*dy<trigger*trigger;
            }
            if(hit){
                float speed=(float)Math.sqrt(s.vx*s.vx+s.vy*s.vy);if(speed<1)speed=1;
                float nx=s.vx/speed,ny=s.vy/speed;if(s.mine){nx=Math.signum(target.x-s.x);ny=-0.6f;}
                damage(target,s.damage,nx*W*s.knockback,ny*H*0.18f-H*0.06f,s.owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135));
                if(s.frost)target.slowTimer=Math.max(target.slowTimer,1.8f);
                if(s.healOnHit){Fighter shooter=s.owner==0?player:bot;shooter.hp=Math.min(100f,shooter.hp+9f);}
                if(s.mine)burst(s.x,s.y,s.owner==0?Color.rgb(105,210,255):Color.rgb(255,100,135),18,0.85f);
                it.remove();continue;
            }
            if(s.life<=0||s.x<-140||s.x>W+140||s.y<-220||s.y>H+180)it.remove();
        }
    }

    private void damage(Fighter target,float amount,float kbX,float kbY,int fxColor){
        if(target.invuln>0)return;float factor=target.shield>0?0.28f:1f;
        target.hp-=amount*factor;target.vx+=kbX*factor;target.vy+=kbY*factor;target.invuln=0.08f;
        burst(target.x,target.y,fxColor,10,0.5f);
    }

    private void burst(float x,float y,int color,int count,float speedScale){
        int room=Math.max(0,MAX_PARTICLES-particles.size());count=Math.min(count,room);
        for(int i=0;i<count;i++){float a=rng.nextFloat()*(float)Math.PI*2f;float sp=(0.25f+rng.nextFloat()*0.75f)*Math.min(W,H)*speedScale;particles.add(new Particle(x,y,(float)Math.cos(a)*sp,(float)Math.sin(a)*sp,0.20f+rng.nextFloat()*0.22f,2f+rng.nextFloat()*4.5f,color));}
    }

    private void updateParticles(float dt){Iterator<Particle>it=particles.iterator();while(it.hasNext()){Particle p=it.next();p.life-=dt;p.vx*=Math.max(0f,1f-7f*dt);p.vy*=Math.max(0f,1f-6f*dt);p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.life<=0)it.remove();}}

    private void endRound(){
        roundOver=true;roundResetTimer=1.55f;
        if(player.hp<=0)botScore++;else playerScore++;
        if(playerScore>=3||botScore>=3){
            matchOver=true;
            if(playerScore>botScore&&!rewardGranted){lastReward=difficulty.reward;coins+=lastReward;rewardGranted=true;saveProgress();}
        }
    }

    private static float distance(Fighter a,Fighter b){float dx=a.x-b.x,dy=a.y-b.y;return(float)Math.sqrt(dx*dx+dy*dy);}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); if(W<=0||H<=0)return;
        drawArena(c);
        if(screen==Screen.HOME)drawHome(c);
        else if(screen==Screen.ARMORY)drawArmory(c,false);
        else if(screen==Screen.SHOP)drawArmory(c,true);
        else drawBattle(c);
    }

    private void drawHome(Canvas c){
        drawPanel(c,W*0.06f,H*0.055f,W*0.94f,H*0.92f,0xBB0D1728,30f);
        drawCenterText(c,"STICK CLASH ARENA",H*0.16f,H*0.070f,Color.WHITE);
        drawCenterText(c,"ГЛОБАЛЬНОЕ ОБНОВЛЕНИЕ",H*0.215f,H*0.027f,Color.rgb(135,205,255));
        drawCoinPill(c,W*0.80f,H*0.075f);

        drawCenterText(c,"СЛОЖНОСТЬ БОТА",H*0.285f,H*0.030f,Color.rgb(220,232,245));
        Difficulty[] ds=Difficulty.values();
        for(int i=0;i<3;i++){
            boolean selected=ds[i]==difficulty;
            drawButton(c,difficultyBtns[i],ds[i].title,"+"+ds[i].reward+" монет",selected?Color.rgb(45,145,220):Color.rgb(32,50,76));
        }

        drawButton(c,armoryBtn,"ОРУЖИЕ",selectedAbility.title,Color.rgb(42,72,105));
        drawButton(c,randomBtn,"СЛУЧАЙНОЕ","из открытых",Color.rgb(68,60,112));
        drawButton(c,shopBtn,"МАГАЗИН","купить оружие",Color.rgb(88,66,42));
        drawButton(c,playBtn,"ИГРАТЬ",difficulty.title+" • "+selectedAbility.title,Color.rgb(32,132,96));
    }

    private void drawArmory(Canvas c,boolean shop){
        drawPanel(c,W*0.045f,H*0.035f,W*0.955f,H*0.96f,0xC20D1728,28f);
        drawButton(c,backBtn,"НАЗАД","",Color.rgb(38,55,80));
        drawCoinPill(c,W*0.80f,H*0.065f);
        drawCenterText(c,shop?"МАГАЗИН":"ВЫБОР ОРУЖИЯ",H*0.12f,H*0.055f,Color.WHITE);
        drawCenterText(c,shop?"Первые 5 открыты сразу • остальные покупаются":"Нажми на открытое оружие, чтобы выбрать",H*0.165f,H*0.024f,Color.rgb(170,205,230));

        Ability[] a=Ability.values();
        for(int i=0;i<a.length;i++){
            RectF r=itemRects[i];boolean open=unlocked[i];boolean selected=a[i]==selectedAbility;
            int bg=selected?Color.rgb(35,120,168):(open?Color.rgb(31,52,78):Color.rgb(45,39,52));
            drawPanel(c,r.left,r.top,r.right,r.bottom,bg,20f);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(selected?4f:2f);paint.setColor(selected?Color.rgb(130,230,255):(open?0x665AC8FF:0x665B5364));c.drawRoundRect(r,20f,20f,paint);paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(open?Color.WHITE:Color.rgb(190,190,200));paint.setTextSize(Math.min(H*0.025f,r.height()*0.20f));
            c.drawText(a[i].title,r.centerX(),r.top+r.height()*0.34f,paint);
            paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(Math.min(H*0.018f,r.height()*0.14f));paint.setColor(Color.rgb(165,192,215));
            c.drawText(shorten(a[i].desc,34),r.centerX(),r.top+r.height()*0.56f,paint);
            paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(Math.min(H*0.021f,r.height()*0.16f));
            if(open){paint.setColor(selected?Color.rgb(165,245,255):Color.rgb(120,220,170));c.drawText(selected?"ВЫБРАНО":"ОТКРЫТО",r.centerX(),r.top+r.height()*0.80f,paint);}else{paint.setColor(Color.rgb(255,211,90));c.drawText(a[i].price+" МОНЕТ",r.centerX(),r.top+r.height()*0.80f,paint);}
        }
    }

    private String shorten(String s,int max){return s.length()<=max?s:s.substring(0,max-1)+"…";}

    private void drawBattle(Canvas c){
        if(player==null||bot==null)return;
        drawFighter(c,player,Color.rgb(82,183,255),Color.rgb(170,230,255));
        drawFighter(c,bot,Color.rgb(255,82,115),Color.rgb(255,180,195));
        for(Shot s:shots)drawShot(c,s);
        drawParticles(c);drawHud(c);drawJoystick(c);
        drawWeaponLabel(c);
        if(roundOver&&!matchOver)drawCenterText(c,player.hp<=0?"БОТ ВЫИГРАЛ РАУНД":"ТЫ ВЫИГРАЛ РАУНД",H*0.43f,H*0.048f,Color.WHITE);
        if(matchOver)drawMatchOver(c);
    }

    private void drawMatchOver(Canvas c){
        paint.setColor(0xE710182B);c.drawRect(0,0,W,H,paint);
        boolean win=playerScore>botScore;
        drawCenterText(c,win?"ПОБЕДА!":"ПОРАЖЕНИЕ",H*0.31f,H*0.090f,win?Color.rgb(115,235,180):Color.rgb(255,125,145));
        drawCenterText(c,win?"Награда: +"+lastReward+" монет":"Попробуй другую сложность или оружие",H*0.42f,H*0.036f,Color.WHITE);
        drawCenterText(c,"Баланс: "+coins+" монет",H*0.49f,H*0.028f,Color.rgb(255,215,95));
        drawButton(c,againBtn,"ЕЩЕ РАЗ",difficulty.title,Color.rgb(34,125,92));
        drawButton(c,menuBtn,"В МЕНЮ","магазин и оружие",Color.rgb(45,70,105));
    }

    private void drawCoinPill(Canvas c,float cx,float cy){
        float w=W*0.15f,h=H*0.065f;RectF r=new RectF(cx-w*0.5f,cy-h*0.5f,cx+w*0.5f,cy+h*0.5f);
        drawPanel(c,r.left,r.top,r.right,r.bottom,0xDD2A2516,h*0.5f);
        paint.setColor(Color.rgb(255,210,70));c.drawCircle(r.left+h*0.55f,cy,h*0.22f,paint);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.027f);paint.setColor(Color.WHITE);c.drawText(String.valueOf(coins),r.centerX()+h*0.12f,cy+paint.getTextSize()*0.34f,paint);
    }

    private void drawButton(Canvas c,RectF r,String title,String sub,int color){
        drawPanel(c,r.left,r.top,r.right,r.bottom,color,22f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2f);paint.setColor(0x66FFFFFF);c.drawRoundRect(r,22f,22f,paint);paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(Color.WHITE);paint.setTextSize(Math.min(H*0.030f,r.height()*0.31f));
        float base=r.centerY()+(sub.isEmpty()?paint.getTextSize()*0.32f:-r.height()*0.05f);c.drawText(title,r.centerX(),base,paint);
        if(!sub.isEmpty()){paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(Math.min(H*0.019f,r.height()*0.19f));paint.setColor(Color.rgb(190,215,235));c.drawText(shorten(sub,32),r.centerX(),r.centerY()+r.height()*0.28f,paint);}
    }

    private void drawPanel(Canvas c,float l,float t,float r,float b,int color,float radius){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRoundRect(l,t,r,b,radius,radius,paint);}

    private void rebuildArenaBitmap(int width,int height){
        if(width<=0||height<=0)return;if(arenaBitmap!=null&&!arenaBitmap.isRecycled())arenaBitmap.recycle();
        arenaBitmap=Bitmap.createBitmap(width,height,Bitmap.Config.RGB_565);Canvas c=new Canvas(arenaBitmap);
        paint.setStyle(Paint.Style.FILL);paint.setShader(new LinearGradient(0,0,0,H,new int[]{Color.rgb(7,12,28),Color.rgb(18,29,55),Color.rgb(31,39,63)},null,Shader.TileMode.CLAMP));c.drawRect(0,0,W,H,paint);paint.setShader(null);
        float moonX=W*0.78f,moonY=H*0.19f,moonR=Math.min(W,H)*0.075f;
        paint.setShader(new RadialGradient(moonX,moonY,moonR*2.8f,new int[]{0x667AD8FF,0x227AD8FF,0x007AD8FF},null,Shader.TileMode.CLAMP));c.drawCircle(moonX,moonY,moonR*2.8f,paint);paint.setShader(null);paint.setColor(Color.rgb(205,235,255));c.drawCircle(moonX,moonY,moonR,paint);
        paint.setColor(0xCCFFFFFF);for(int i=0;i<starX.length;i++)c.drawCircle(starX[i]*W,starY[i]*H,starR[i]*Math.max(1f,H/720f),paint);
        paint.setColor(Color.rgb(18,27,48));for(int i=0;i<14;i++){float bw=W/14f,bh=H*(0.08f+(i%5)*0.018f);c.drawRect(i*bw,groundY-bh,i*bw+bw*0.82f,groundY,paint);}
        paint.setShader(new LinearGradient(0,groundY,0,H,Color.rgb(38,52,76),Color.rgb(13,19,34),Shader.TileMode.CLAMP));c.drawRect(0,groundY,W,H,paint);paint.setShader(null);paint.setColor(Color.rgb(91,170,220));c.drawRect(0,groundY,W,groundY+Math.max(4f,H*0.006f),paint);
    }

    private void drawArena(Canvas c){if(arenaBitmap!=null&&!arenaBitmap.isRecycled())c.drawBitmap(arenaBitmap,0,0,paint);else c.drawColor(Color.rgb(8,12,24));}

    private void drawFighter(Canvas c,Fighter f,int color,int lightColor){
        float r=f.radius,bodyTop=f.y-r*0.23f,bodyBottom=f.y+r*0.62f,headY=f.y-r*0.78f,headR=r*0.48f;
        paint.setStyle(Paint.Style.FILL);paint.setColor((color&0x00FFFFFF)|0x22000000);c.drawCircle(f.x,f.y,r*1.75f,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(11f,r*0.34f));paint.setColor(0xAA050810);drawStick(c,f,bodyTop,bodyBottom,headY,headR);
        paint.setStrokeWidth(Math.max(7f,r*0.24f));paint.setColor(color);drawStick(c,f,bodyTop,bodyBottom,headY,headR);
        paint.setStyle(Paint.Style.FILL);paint.setColor(lightColor);c.drawCircle(f.x+f.facing*headR*0.34f,headY-headR*0.08f,headR*0.10f,paint);
        if(f.shield>0){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,r*0.10f));paint.setColor(lightColor);c.drawCircle(f.x,f.y,r*1.58f,paint);}
        if(f.slowTimer>0){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,r*0.08f));paint.setColor(Color.rgb(150,235,255));c.drawCircle(f.x,f.y,r*1.35f,paint);}
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawStick(Canvas c,Fighter f,float bodyTop,float bodyBottom,float headY,float headR){float r=f.radius;c.drawLine(f.x,bodyTop,f.x,bodyBottom,paint);c.drawLine(f.x,f.y+r*0.02f,f.x-r*0.72f*f.facing,f.y+r*0.36f,paint);c.drawLine(f.x,f.y+r*0.02f,f.x+r*0.83f*f.facing,f.y-r*0.10f,paint);c.drawLine(f.x,bodyBottom,f.x-r*0.56f,f.y+r*1.10f,paint);c.drawLine(f.x,bodyBottom,f.x+r*0.56f,f.y+r*1.10f,paint);c.drawCircle(f.x,headY,headR,paint);}

    private void drawShot(Canvas c,Shot s){
        int core=s.owner==0?Color.rgb(105,220,255):Color.rgb(255,105,140);if(s.frost)core=Color.rgb(170,245,255);if(s.healOnHit)core=Color.rgb(130,255,180);if(s.mine)core=Color.rgb(255,190,75);if(s.source==Ability.SKY_DROP)core=Color.rgb(255,235,130);
        paint.setStyle(Paint.Style.FILL);paint.setColor((core&0x00FFFFFF)|0x55000000);c.drawCircle(s.x,s.y,s.radius*1.7f,paint);paint.setColor(core);c.drawCircle(s.x,s.y,s.radius,paint);paint.setColor(Color.WHITE);c.drawCircle(s.x,s.y,s.radius*0.34f,paint);
        if(s.mine&&s.armed){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3f);paint.setColor(0xAAFFD45A);c.drawCircle(s.x,s.y,s.radius*1.55f,paint);paint.setStyle(Paint.Style.FILL);}
    }

    private void drawParticles(Canvas c){paint.setStyle(Paint.Style.FILL);for(Particle p:particles){int a=(int)(255f*clamp(p.life/p.maxLife,0,1));paint.setColor((p.color&0x00FFFFFF)|(a<<24));c.drawCircle(p.x,p.y,p.size*(0.5f+0.5f*p.life/p.maxLife),paint);}}

    private void drawHud(Canvas c){
        float barW=W*0.30f,barH=Math.max(16f,H*0.030f),y=H*0.045f;drawHealthBar(c,W*0.035f,y,barW,barH,player.hp,Color.rgb(82,183,255),false);drawHealthBar(c,W*0.965f-barW,y,barW,barH,bot.hp,Color.rgb(255,82,115),true);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(H*0.044f);paint.setColor(Color.WHITE);c.drawText(playerScore+"  :  "+botScore,W*0.5f,H*0.075f,paint);
        paint.setTextSize(H*0.020f);paint.setColor(Color.rgb(180,205,230));c.drawText(difficulty.title+" • победа +"+difficulty.reward+" монет",W*0.5f,H*0.110f,paint);
    }

    private void drawHealthBar(Canvas c,float x,float y,float w,float h,float hp,int color,boolean reverse){paint.setColor(0xAA111827);c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,paint);float fw=w*(clamp(hp,0,100)/100f);paint.setColor(color);if(reverse)c.drawRoundRect(x+w-fw,y,x+w,y+h,h/2,h/2,paint);else c.drawRoundRect(x,y,x+fw,y+h,h/2,h/2,paint);}

    private void drawWeaponLabel(Canvas c){
        RectF r=new RectF(W*0.025f,H*0.84f,W*0.34f,H*0.94f);drawPanel(c,r.left,r.top,r.right,r.bottom,0x8A132139,20f);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setColor(Color.WHITE);paint.setTextSize(H*0.024f);c.drawText(player.ability.title,r.centerX(),r.centerY()-H*0.006f,paint);paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(H*0.017f);paint.setColor(Color.rgb(165,205,230));c.drawText("оружие выбрано до боя",r.centerX(),r.centerY()+H*0.025f,paint);
    }

    private void drawJoystick(Canvas c){
        float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY),kx=joyCx+joyX*joyRadius*0.72f,ky=joyCy+joyY*joyRadius*0.72f;
        paint.setStyle(Paint.Style.FILL);paint.setColor(0x44233752);c.drawCircle(joyCx,joyCy,joyRadius,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(3f,H*0.004f));paint.setColor(0x7799CFFF);c.drawCircle(joyCx,joyCy,joyRadius,paint);
        if(jumpCharge>0f){paint.setStrokeWidth(Math.max(7f,H*0.009f));paint.setColor(Color.rgb(255,210,85));c.drawArc(jumpArcRect,-90,360f*clamp(jumpCharge/0.5f,0,1),false,paint);}
        paint.setStyle(Paint.Style.FILL);paint.setColor(0x665BBFFF);c.drawCircle(kx,ky,knobRadius*1.35f,paint);paint.setColor(0xEEC2ECFF);c.drawCircle(kx,ky,knobRadius,paint);paint.setColor(Color.rgb(235,250,255));c.drawCircle(kx,ky,knobRadius*0.50f,paint);
        if(mag>0.22f){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(4f,H*0.006f));paint.setColor(0xCCFFFFFF);c.drawLine(joyCx,joyCy,joyCx+aimX*joyRadius*1.35f,joyCy+aimY*joyRadius*1.35f,paint);paint.setStyle(Paint.Style.FILL);}
    }

    private void drawCenterText(Canvas c,String text,float y,float size,int color){paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(size);paint.setColor(color);c.drawText(text,W/2f,y,paint);}

    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked(),index=e.getActionIndex();float x=e.getX(index),y=e.getY(index);

        if(screen==Screen.HOME&&action==MotionEvent.ACTION_DOWN){
            for(int i=0;i<3;i++)if(difficultyBtns[i].contains(x,y)){difficulty=Difficulty.values()[i];saveProgress();invalidate();return true;}
            if(armoryBtn.contains(x,y)){screen=Screen.ARMORY;invalidate();return true;}
            if(shopBtn.contains(x,y)){screen=Screen.SHOP;invalidate();return true;}
            if(randomBtn.contains(x,y)){chooseRandomUnlocked();invalidate();return true;}
            if(playBtn.contains(x,y)){startBattle();return true;}
            return true;
        }

        if((screen==Screen.ARMORY||screen==Screen.SHOP)&&action==MotionEvent.ACTION_DOWN){
            if(backBtn.contains(x,y)){screen=Screen.HOME;invalidate();return true;}
            Ability[] a=Ability.values();
            for(int i=0;i<a.length;i++)if(itemRects[i].contains(x,y)){
                if(unlocked[i]){selectedAbility=a[i];saveProgress();if(screen==Screen.ARMORY){screen=Screen.HOME;}invalidate();return true;}
                if(screen==Screen.SHOP&&coins>=a[i].price){coins-=a[i].price;unlocked[i]=true;selectedAbility=a[i];saveProgress();invalidate();return true;}
                return true;
            }
            return true;
        }

        if(screen!=Screen.BATTLE)return true;
        if(matchOver&&action==MotionEvent.ACTION_DOWN){
            if(againBtn.contains(x,y)){playerScore=0;botScore=0;matchOver=false;rewardGranted=false;lastReward=0;startRound();invalidate();return true;}
            if(menuBtn.contains(x,y)){screen=Screen.HOME;resetJoystick();invalidate();return true;}
            return true;
        }

        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            if(joystickPointerId==-1&&x>W*0.52f&&y>H*0.42f){joystickPointerId=e.getPointerId(index);updateJoystick(x,y);}
        }else if(action==MotionEvent.ACTION_MOVE){
            if(joystickPointerId!=-1){int idx=e.findPointerIndex(joystickPointerId);if(idx>=0)updateJoystick(e.getX(idx),e.getY(idx));}
        }else if(action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_UP){int id=e.getPointerId(index);if(id==joystickPointerId)resetJoystick();}
        else if(action==MotionEvent.ACTION_CANCEL)resetJoystick();
        return true;
    }

    private void chooseRandomUnlocked(){
        List<Ability> pool=new ArrayList<>();Ability[] a=Ability.values();for(int i=0;i<a.length;i++)if(unlocked[i])pool.add(a[i]);
        if(!pool.isEmpty()){selectedAbility=pool.get(rng.nextInt(pool.size()));saveProgress();}
    }

    private void updateJoystick(float x,float y){float dx=x-joyCx,dy=y-joyCy,len=(float)Math.sqrt(dx*dx+dy*dy);if(len>joyRadius&&len>0){dx=dx/len*joyRadius;dy=dy/len*joyRadius;}joyX=clamp(dx/joyRadius,-1,1);joyY=clamp(dy/joyRadius,-1,1);}
    private void resetJoystick(){joystickPointerId=-1;joyX=0f;joyY=0f;jumpCharge=0f;jumpLatched=false;}
}
