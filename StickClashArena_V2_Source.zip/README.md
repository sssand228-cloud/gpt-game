# Stick Clash Arena

An original Android 2D stick-figure duel prototype. No ads, no analytics, and no Internet permission.

## Included
- Landscape mobile controls with multi-touch
- 1v1 against a strong bot
- 8 fictional abilities: Energy Orb, Bounce Disc, Heavy Glove, Gravity Burst, Arc Core, Triple Spark, Shield Pulse, Dash Core
- Health bars, knockback physics, rounds, first-to-3 match
- Bot dodging, spacing, jumping, ability selection and predictive arc shots
- Single custom Java View, no external game engine or third-party libraries

## Build
Open this folder in Android Studio, let Gradle sync, then choose **Build > Build APK(s)**.
Debug APK will normally appear under `app/build/outputs/apk/debug/`.

Package: `com.openai.stickclasharena`
Minimum Android: 7.0 (API 24)

This project intentionally uses original names/visuals and does not copy assets from other games.
