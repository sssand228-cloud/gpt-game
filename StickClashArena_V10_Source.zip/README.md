# Stick Clash Arena V10 — Phone Server Beta

V10 upgrades the Online Alpha into a phone-hosted server mode while preserving the offline game, permanent purchases, customization, and Creator/Admin systems from V8/V9.

## Phone-hosted online
- The Android phone that creates the room becomes the authoritative TCP game server.
- Server port: `27654`.
- A random 6-digit room code is generated for every hosted session.
- Guests must enter both the host address and the room code before gameplay packets are accepted.
- The join field accepts a LAN IPv4 address, a public IPv6 address, or a tunnel/domain hostname.
- Host state snapshots keep movement, health and projectiles synchronized.
- Each player keeps the ability selected on their own device; the host selects the arena.
- Creator/Admin combat advantages remain disabled in online matches.
- Online matches do not award coins yet, to prevent easy farming while the network mode is in beta.

## Android host service
- Hosting starts a foreground `GameHostService` so the match server is less likely to be killed when the app is briefly backgrounded.
- A partial wake lock is used only while hosting and is released when the host service stops.
- The service stops when the room/server is closed.

## Internet limitation
The game can truly host on the phone, but most home/mobile connections are behind NAT/CGNAT. That means players on a different Internet connection usually cannot reach the phone through its private IPv4 address.

Internet play works when at least one of these is available:
1. a reachable public IPv6 address on the host phone/network;
2. router port forwarding/public IPv4;
3. an external TCP tunnel/relay that forwards a public hostname to the phone's port `27654`.

The game already accepts a domain/tunnel hostname, so a later update can add an automatic relay without redesigning the battle protocol.

## Existing systems kept
- 15 permanent unlockable abilities and permanent purchases.
- Solo Easy/Medium/Hard and local 2-player modes.
- Coins, shop, weapon selection, random selection, multiple arenas.
- Graphics quality, color customization and joystick settings.
- Improved physics, particles, camera feedback and bot behavior.
- Creator/Admin panel for the owner's whitelisted installation.

Version: 1.0.0 (`versionCode 11`).
